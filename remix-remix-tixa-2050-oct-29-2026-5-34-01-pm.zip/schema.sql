-- TIXAPAY Cloudflare D1 Relational Schema

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  country_code TEXT,
  country_name TEXT,
  calling_code TEXT,
  currency_code TEXT,
  password_hash TEXT NOT NULL,
  secret_phrase_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  wallet_address TEXT UNIQUE NOT NULL,
  created_at INTEGER NOT NULL,
  last_login_at INTEGER NOT NULL,
  is_frozen INTEGER DEFAULT 0,
  status TEXT DEFAULT 'ACTIVE',
  registration_status TEXT DEFAULT 'APPROVED',
  passkey_enrolled INTEGER DEFAULT 0,
  affiliate_code TEXT UNIQUE,
  referred_by_code TEXT,
  affiliate_balance_usd REAL DEFAULT 0,
  affiliate_total_earned_usd REAL DEFAULT 0,
  affiliate_withdrawn_usd REAL DEFAULT 0,
  affiliate_total_referrals INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS trades (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  pair_id TEXT NOT NULL,
  side TEXT NOT NULL,
  amount REAL NOT NULL,
  price REAL NOT NULL,
  total REAL NOT NULL,
  status TEXT DEFAULT 'EXECUTED',
  timestamp INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  asset TEXT NOT NULL,
  status TEXT DEFAULT 'COMPLETED',
  timestamp INTEGER NOT NULL,
  memo TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL,
  actor_email TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  target_id TEXT,
  details TEXT,
  status TEXT DEFAULT 'SUCCESS',
  timestamp INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_wallet ON users(wallet_address);
CREATE INDEX IF NOT EXISTS idx_trades_user ON trades(user_id);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id);
