import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Plus, Trash2, RefreshCw, CheckCircle, AlertTriangle, ShieldCheck, ExternalLink } from 'lucide-react';
import { GoogleAuthProvider, signInWithPopup, onAuthStateChanged, User } from 'firebase/auth';
import { auth } from '../../lib/firebase';

interface CalendarEvent {
  id: string;
  summary: string;
  description?: string;
  start: { dateTime?: string; date?: string };
  end: { dateTime?: string; date?: string };
  htmlLink?: string;
}

export const GoogleCalendarView: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // New Event Form State
  const [summary, setSummary] = useState('');
  const [description, setDescription] = useState('');
  const [startDateTime, setStartDateTime] = useState('');
  const [endDateTime, setEndDateTime] = useState('');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (!currentUser) {
        setAccessToken(null);
        setEvents([]);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      setError(null);
      const provider = new GoogleAuthProvider();
      provider.addScope('https://www.googleapis.com/auth/calendar');
      provider.addScope('https://www.googleapis.com/auth/calendar.events');

      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setAccessToken(credential.accessToken);
        fetchEvents(credential.accessToken);
      } else {
        throw new Error('Failed to retrieve Google OAuth access token.');
      }
    } catch (err: any) {
      if (err.code === 'auth/popup-closed-by-user' || (err.message && err.message.includes('popup-closed-by-user'))) {
        setError('Google Sign-In popup was closed before completing authentication. Please try again when ready.');
      } else {
        console.error('Calendar auth error:', err);
        setError(err.message || 'Authentication failed');
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchEvents = async (token: string) => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?maxResults=20&orderBy=startTime&singleEvents=true', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      if (!res.ok) {
        throw new Error(`Failed to fetch calendar events (${res.status})`);
      }
      const data = await res.json();
      setEvents(data.items || []);
    } catch (err: any) {
      console.error('Fetch events error:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken) return;

    // MANDATORY User Confirmation for destructive/mutating operations
    const confirmed = window.confirm(`Create Google Calendar event: "${summary}"?`);
    if (!confirmed) return;

    try {
      setLoading(true);
      const newEvent = {
        summary,
        description,
        start: { dateTime: startDateTime ? new Date(startDateTime).toISOString() : new Date().toISOString() },
        end: { dateTime: endDateTime ? new Date(endDateTime).toISOString() : new Date(Date.now() + 3600000).toISOString() }
      };

      const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(newEvent)
      });

      if (!res.ok) {
        throw new Error('Failed to create calendar event');
      }

      setSummary('');
      setDescription('');
      setStartDateTime('');
      setEndDateTime('');
      fetchEvents(accessToken);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteEvent = async (eventId: string, eventTitle: string) => {
    // MANDATORY User Confirmation
    const confirmed = window.confirm(`Are you sure you want to delete calendar event "${eventTitle}"? This action cannot be undone.`);
    if (!confirmed || !accessToken) return;

    try {
      setLoading(true);
      const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events/${eventId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      });

      if (!res.ok && res.status !== 204) {
        throw new Error('Failed to delete event');
      }

      fetchEvents(accessToken);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-950/80 via-indigo-950/80 to-slate-900 border border-blue-500/30 rounded-2xl p-6 sm:p-8 mb-8 shadow-2xl backdrop-blur-md relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 text-2xl shadow-lg">
              📅
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-mono uppercase px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" /> Google Workspace Integration
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-mono tracking-tight">
                Google Calendar Scheduler
              </h1>
              <p className="text-sm text-slate-400 mt-1">
                Manage your trading sessions, financial appointments, and reminders directly synchronized with Google Calendar.
              </p>
            </div>
          </div>

          {!accessToken ? (
            <button
              onClick={handleGoogleSignIn}
              disabled={loading}
              className="gsi-material-button px-6 py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-medium text-sm flex items-center gap-3 shadow-lg transition-all border border-slate-300 disabled:opacity-50"
            >
              <div className="gsi-material-button-icon">
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="w-5 h-5">
                  <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                  <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                  <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                  <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                </svg>
              </div>
              <span className="gsi-material-button-contents font-semibold">Sign in with Google Calendar</span>
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1.5 rounded-lg flex items-center gap-2">
                <CheckCircle className="w-4 h-4" /> Connected as {user?.email}
              </span>
              <button
                onClick={() => fetchEvents(accessToken)}
                disabled={loading}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-bold transition-all shadow-md flex items-center gap-2"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
              </button>
            </div>
          )}
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 rounded-xl bg-rose-950/50 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Content */}
      {!accessToken ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center backdrop-blur-md">
          <div className="w-16 h-16 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-3xl mx-auto mb-4">
            🔒
          </div>
          <h3 className="text-lg font-bold text-white font-mono mb-2">Google Calendar Authorization Required</h3>
          <p className="text-sm text-slate-400 max-w-md mx-auto mb-6">
            Please sign in with your Google account using the button above to view and manage your calendar events securely with user permission.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Create Event Form */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md shadow-xl h-fit">
            <h2 className="text-lg font-bold text-white font-mono mb-4 flex items-center gap-2">
              <Plus className="w-5 h-5 text-blue-400" /> Schedule Event
            </h2>
            <form onSubmit={handleCreateEvent} className="space-y-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">Event Summary / Title</label>
                <input
                  type="text"
                  required
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  placeholder="e.g. TIXA Staking Review"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">Description (Optional)</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Meeting notes or trading details..."
                  rows={3}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">Start Date & Time</label>
                <input
                  type="datetime-local"
                  required
                  value={startDateTime}
                  onChange={(e) => setStartDateTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-slate-400 mb-1">End Date & Time</label>
                <input
                  type="datetime-local"
                  required
                  value={endDateTime}
                  onChange={(e) => setEndDateTime(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 font-mono"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-mono text-xs font-bold transition-all shadow-lg shadow-blue-600/20 flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Plus className="w-4 h-4" /> Create Calendar Event
              </button>
            </form>
          </div>

          {/* Events List */}
          <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md shadow-xl">
            <h2 className="text-lg font-bold text-white font-mono mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-400" /> Upcoming Google Calendar Events ({events.length})
            </h2>

            {events.length === 0 ? (
              <div className="text-center py-12 text-slate-500 font-mono text-sm">
                No calendar events found. Create one using the form on the left!
              </div>
            ) : (
              <div className="space-y-4">
                {events.map((ev) => {
                  const startTime = ev.start.dateTime || ev.start.date;
                  return (
                    <div
                      key={ev.id}
                      className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-blue-500/40 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <h3 className="text-white font-bold text-sm sm:text-base font-mono flex items-center gap-2">
                          {ev.summary}
                          {ev.htmlLink && (
                            <a
                              href={ev.htmlLink}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-400 hover:text-blue-300 text-xs flex items-center gap-1 font-normal"
                            >
                              <ExternalLink className="w-3 h-3" /> Open in Google
                            </a>
                          )}
                        </h3>
                        {ev.description && (
                          <p className="text-xs text-slate-400">{ev.description}</p>
                        )}
                        <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                          <Clock className="w-3.5 h-3.5 text-blue-400" />
                          <span>{startTime ? new Date(startTime).toLocaleString() : 'All day'}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => handleDeleteEvent(ev.id, ev.summary || 'Event')}
                        className="p-2 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 border border-rose-500/30 text-rose-400 transition-all"
                        title="Delete Event"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
