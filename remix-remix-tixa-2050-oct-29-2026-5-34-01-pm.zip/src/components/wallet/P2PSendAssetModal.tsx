import React, { useState, useEffect } from 'react';
import { 
  X, 
  Send, 
  ArrowUpRight, 
  ArrowDownLeft, 
  CheckCircle2, 
  AlertCircle, 
  ShieldCheck, 
  Calculator, 
  History, 
  Copy, 
  Check, 
  RefreshCw, 
  Zap, 
  Sparkles,
  ArrowRightLeft,
  UserCheck
} from 'lucide-react';
import { p2pTransferService, P2PTransactionRecord, P2PTransferResult } from '../../core/p2pTransferService';
import { authEngine } from '../../core/authEngine';
import { HashBadge } from '../common/HashBadge';
import confetti from 'canvas-confetti';

interface P2PSendAssetModalProps {
  isOpen: boolean;
  onClose: () => void;
  userBalance: number;
  tixaPrice?: number;
  onSuccess?: () => void;
  defaultActiveTab?: 'transfer' | 'history';
}

export const P2PSendAssetModal: React.FC<P2PSendAssetModalProps> = ({
  isOpen,
  onClose,
  userBalance,
  tixaPrice = 990000.00,
  onSuccess,
  defaultActiveTab = 'transfer'
}) => {
  const [activeTab, setActiveTab] = useState<'transfer' | 'history'>(defaultActiveTab);
  
  // Interactive Live Calculator Inputs
  const [usdInput, setUsdInput] = useState<string>('5');
  const [tixaInput, setTixaInput] = useState<string>(() => {
    const initialTixa = 5 / tixaPrice;
    return initialTixa.toFixed(8);
  });
  
  // Recipient and Form State
  const [recipientAddress, setRecipientAddress] = useState<string>('');
  const [memo, setMemo] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verifiedRecipient, setVerifiedRecipient] = useState<{ uid: string; identifier: string } | null>(null);
  const [verifyError, setVerifyError] = useState<string | null>(null);
  
  // Action State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [transferResult, setTransferResult] = useState<P2PTransferResult | null>(null);

  // Transaction History State
  const [historyList, setHistoryList] = useState<P2PTransactionRecord[]>([]);
  const [isLoadingHistory, setIsLoadingHistory] = useState(false);
  const [historyFilter, setHistoryFilter] = useState<'ALL' | 'SENT' | 'RECEIVED'>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const currentUser = authEngine.getCurrentUser();
  const session = authEngine.getSession();

  // Keep dual inputs synchronized
  const handleUsdChange = (val: string) => {
    setUsdInput(val);
    setErrorMessage(null);
    const num = parseFloat(val);
    if (!isNaN(num) && num >= 0) {
      const computedTixa = num / tixaPrice;
      // Show high precision without trailing garbage
      setTixaInput(computedTixa >= 1 ? computedTixa.toFixed(4) : computedTixa.toFixed(8));
    } else if (val === '') {
      setTixaInput('');
    }
  };

  const handleTixaChange = (val: string) => {
    setTixaInput(val);
    setErrorMessage(null);
    const num = parseFloat(val);
    if (!isNaN(num) && num >= 0) {
      const computedUsd = num * tixaPrice;
      setUsdInput(computedUsd >= 1000 ? Math.round(computedUsd).toString() : computedUsd.toFixed(2));
    } else if (val === '') {
      setUsdInput('');
    }
  };

  // Quick preset amount buttons
  const applyPresetUsd = (usd: number) => {
    handleUsdChange(usd.toString());
  };

  const applyMaxBalance = () => {
    if (userBalance <= 0) return;
    const computedUsd = userBalance * tixaPrice;
    setTixaInput(userBalance.toFixed(8));
    setUsdInput(computedUsd.toFixed(2));
  };

  // Verification
  const handleVerifyRecipient = async () => {
    const trimmed = recipientAddress.trim();
    if (!trimmed.startsWith('tx1')) {
      setVerifyError('Invalid wallet address. Address must start with "tx1".');
      setVerifiedRecipient(null);
      return;
    }

    setIsVerifying(true);
    setVerifyError(null);
    try {
      const result = await p2pTransferService.lookupRecipient(trimmed);
      if (result) {
        setVerifiedRecipient(result);
      } else {
        setVerifyError('This wallet address was not found in any registered user account.');
        setVerifiedRecipient(null);
      }
    } catch (err: any) {
      setVerifyError(err.message || 'Verification failed.');
      setVerifiedRecipient(null);
    } finally {
      setIsVerifying(false);
    }
  };

  // Load P2P History
  const loadHistory = async () => {
    setIsLoadingHistory(true);
    try {
      const list = await p2pTransferService.getP2PHistory(currentUser?.id || session?.userId);
      setHistoryList(list);
    } catch (err) {
      console.warn('Failed to load P2P history:', err);
    } finally {
      setIsLoadingHistory(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadHistory();
    }
  }, [isOpen]);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Execute P2P Transfer (Direct User-to-User, Zero Admin Intervention)
  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const numericUsd = parseFloat(usdInput);
    const numericTixa = parseFloat(tixaInput);

    if (isNaN(numericUsd) || numericUsd < 4.999) {
      setErrorMessage(`Minimum transfer is $5 USD worth of TIXA Coin. Your current amount is $${isNaN(numericUsd) ? '0.00' : numericUsd.toFixed(2)} USD.`);
      return;
    }

    if (isNaN(numericTixa) || numericTixa <= 0) {
      setErrorMessage('Please provide a valid TIXA coin amount.');
      return;
    }

    if (numericTixa > userBalance) {
      setErrorMessage(`Insufficient balance! You have ${userBalance.toFixed(8)} TIXA (${(userBalance * tixaPrice).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}) in your wallet.`);
      return;
    }

    if (!recipientAddress.trim().startsWith('tx1')) {
      setErrorMessage('Please provide a valid TIXA wallet address for the recipient (must start with tx1).');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await p2pTransferService.executeTransfer(
        recipientAddress.trim(),
        numericTixa,
        memo.trim(),
        tixaPrice
      );

      setTransferResult(res);
      confetti({ particleCount: 75, spread: 70, origin: { y: 0.6 } });
      
      // Reload history and notify parent
      await loadHistory();
      if (onSuccess) {
        onSuccess();
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to complete P2P transfer.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Reset transfer form for another transfer
  const handleResetForAnother = () => {
    setTransferResult(null);
    setRecipientAddress('');
    setMemo('');
    setVerifiedRecipient(null);
    setVerifyError(null);
    setErrorMessage(null);
    applyPresetUsd(5);
  };

  if (!isOpen) return null;

  const numericUsd = parseFloat(usdInput) || 0;
  const numericTixa = parseFloat(tixaInput) || 0;
  const isMinAmountValid = numericUsd >= 4.999;
  const isBalanceSufficient = userBalance >= numericTixa;

  // Filtered history
  const filteredHistory = historyList.filter(item => {
    if (historyFilter === 'SENT') return item.type === 'P2P_SEND';
    if (historyFilter === 'RECEIVED') return item.type === 'P2P_RECEIVE';
    return true;
  });

  const totalSentTixa = historyList
    .filter(i => i.type === 'P2P_SEND')
    .reduce((sum, i) => sum + i.amount, 0);

  const totalReceivedTixa = historyList
    .filter(i => i.type === 'P2P_RECEIVE')
    .reduce((sum, i) => sum + i.amount, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#080d1e] border border-cyan-500/40 shadow-2xl p-5 sm:p-7 text-slate-100 my-auto">
        
        {/* Modal Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4 mb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-400 to-blue-500 flex items-center justify-center text-black font-extrabold text-sm shadow-md shadow-cyan-500/30">
                TX
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-extrabold text-white font-heading tracking-wide flex items-center gap-2">
                  <span>Send Asset P2P (Only TIXA Coin)</span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-950/90 border border-emerald-600 text-emerald-300 text-[10px] font-mono font-bold">
                    0% FREE
                  </span>
                </h3>
              </div>
            </div>
            <p className="text-xs text-slate-400 font-mono">
              Direct User-to-User Transfer • No Admin Approval Required • Instant Deposit to Wallet
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation: Transfer & Calculator VS Transaction History */}
        <div className="flex items-center gap-2 p-1 rounded-xl bg-slate-900/90 border border-slate-800 mb-5 font-mono text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('transfer')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg font-bold transition-all ${
              activeTab === 'transfer'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>P2P Transfer & Calculator</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('history');
              loadHistory();
            }}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg font-bold transition-all ${
              activeTab === 'history'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <History className="w-4 h-4" />
            <span>P2P Transaction History</span>
            {historyList.length > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                activeTab === 'history' ? 'bg-black text-cyan-300' : 'bg-slate-800 text-slate-300'
              }`}>
                {historyList.length}
              </span>
            )}
          </button>
        </div>

        {/* TAB 1: P2P TRANSFER & LIVE CALCULATOR */}
        {activeTab === 'transfer' && (
          <div className="space-y-5">
            {/* Success Celebration Screen */}
            {transferResult ? (
              <div className="p-6 rounded-2xl bg-[#051424] border border-emerald-500/40 text-center space-y-4 animate-in zoom-in-95 duration-200">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20 animate-bounce">
                  <CheckCircle2 className="w-9 h-9" />
                </div>

                <div className="space-y-1">
                  <h4 className="text-xl font-bold text-white font-heading">
                    P2P Transfer Successful!
                  </h4>
                  <p className="text-xs text-slate-300 font-mono">
                    TIXA coin transfer completed instantly to user wallet without any admin intervention.
                  </p>
                </div>

                {/* Receipt Details Card */}
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-left font-mono text-xs space-y-2">
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Sent Amount:</span>
                    <span className="text-white font-bold text-sm">
                      {transferResult.amount.toFixed(8)} TIXA
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>USD Equivalent:</span>
                    <span className="text-emerald-400 font-bold">
                      ${transferResult.usdValue.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Recipient User:</span>
                    <span className="text-cyan-400">{transferResult.recipientIdentifier}</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Transaction Fee (Gas Fee):</span>
                    <span className="text-emerald-400 font-bold">$0.00 (100% Free)</span>
                  </div>
                  <div className="flex justify-between items-center text-slate-400">
                    <span>Transaction ID:</span>
                    <span className="text-slate-300 text-[11px] truncate max-w-[200px]">
                      {transferResult.transferId}
                    </span>
                  </div>
                </div>

                {/* Post-transfer Action Buttons */}
                <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setActiveTab('history')}
                    className="w-full flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 text-cyan-300 font-bold text-xs font-mono transition-all flex items-center justify-center gap-2"
                  >
                    <History className="w-4 h-4" />
                    <span>View Transaction History</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleResetForAnother}
                    className="w-full flex-1 py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-bold text-xs font-mono transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20"
                  >
                    <Send className="w-4 h-4" />
                    <span>Make Another Transfer</span>
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleExecuteTransfer} className="space-y-4">
                {/* Available Balance & Live TIXA Price Header */}
                <div className="p-3.5 rounded-2xl bg-cyan-950/30 border border-cyan-500/30 flex flex-wrap items-center justify-between gap-3 font-mono">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 font-bold text-xs">
                      TIXA
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                        <span>TIXA COIN NATIVE PRICE:</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        <span className="text-emerald-400 font-bold">LIVE</span>
                      </div>
                      <div className="text-sm font-extrabold text-white">
                        1 TIXA = ${tixaPrice.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[11px] text-slate-400">Your Available Balance</div>
                    <div className="text-sm font-bold text-cyan-300">
                      {userBalance.toFixed(8)} TIXA
                    </div>
                    <div className="text-[10px] text-slate-400">
                      ≈ ${(userBalance * tixaPrice).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                    </div>
                  </div>
                </div>

                {/* Error Banner */}
                {errorMessage && (
                  <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-800 text-rose-300 text-xs font-mono flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* DUAL LIVE CALCULATOR SECTION */}
                <div className="p-4 rounded-2xl bg-[#060c1d] border border-cyan-500/35 space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                      <Calculator className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Live Calculator (USD ⇄ TIXA Coin)</span>
                    </label>
                    <span className="text-[11px] font-mono text-slate-400">
                      Minimum: <strong className="text-emerald-400">$5 USD</strong>
                    </span>
                  </div>

                  {/* Dual Input Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                    {/* Dollar Box ($ USD) */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[11px] font-mono text-slate-400">
                        <span>1. Dollar Box ($ USD)</span>
                        <span className="text-slate-500">Enter amount</span>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-400 font-mono font-bold text-sm">
                          $
                        </span>
                        <input
                          type="number"
                          step="any"
                          min="0"
                          required
                          value={usdInput}
                          onChange={(e) => handleUsdChange(e.target.value)}
                          placeholder="e.g. 5 or 990000"
                          className="w-full pl-8 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-white font-mono text-sm focus:outline-none transition-colors"
                        />
                      </div>
                    </div>

                    {/* TIXA Coin Box */}
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-[11px] font-mono text-slate-400">
                        <span>2. TIXA Coin Box</span>
                        <span className="text-slate-500">Auto Calculated</span>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-emerald-400 font-mono font-bold text-xs">
                          TX
                        </span>
                        <input
                          type="number"
                          step="any"
                          min="0"
                          required
                          value={tixaInput}
                          onChange={(e) => handleTixaChange(e.target.value)}
                          placeholder="e.g. 1 or 0.00000505"
                          className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-400 text-white font-mono text-sm focus:outline-none transition-colors"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Quick Preset Buttons */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    <span className="text-[10px] text-slate-400 font-mono mr-1">Quick Selection:</span>
                    <button
                      type="button"
                      onClick={() => applyPresetUsd(5)}
                      className="px-2.5 py-1 rounded-lg bg-emerald-950/70 hover:bg-emerald-900/80 border border-emerald-500/50 text-emerald-300 text-[11px] font-mono font-bold transition-colors"
                    >
                      $5 (Min)
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPresetUsd(10)}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-mono transition-colors"
                    >
                      $10
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPresetUsd(50)}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-mono transition-colors"
                    >
                      $50
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPresetUsd(100)}
                      className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-mono transition-colors"
                    >
                      $100
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPresetUsd(990000)}
                      className="px-2.5 py-1 rounded-lg bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-500/50 text-cyan-300 text-[11px] font-mono font-bold transition-colors"
                    >
                      $990,000 (1 TIXA)
                    </button>
                    <button
                      type="button"
                      onClick={applyMaxBalance}
                      className="px-2.5 py-1 rounded-lg bg-purple-950/70 hover:bg-purple-900/80 border border-purple-500/50 text-purple-300 text-[11px] font-mono font-bold transition-colors"
                    >
                      MAX Balance
                    </button>
                  </div>

                  {/* Real-time Validation Status Strip */}
                  <div className="pt-2 border-t border-slate-800 text-xs font-mono">
                    {!isMinAmountValid ? (
                      <div className="text-amber-400 flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>⚠️ Minimum transfer is $5 USD ($5 USD = {(5 / tixaPrice).toFixed(8)} TIXA). Please increase the amount.</span>
                      </div>
                    ) : !isBalanceSufficient ? (
                      <div className="text-rose-400 flex items-center gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>⚠️ Insufficient TIXA Balance! You need {numericTixa.toFixed(8)} TIXA in your wallet.</span>
                      </div>
                    ) : (
                      <div className="text-emerald-400 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                        <span>✓ Amount is correct: ${numericUsd.toLocaleString('en-US', { minimumFractionDigits: 2 })} USD = {numericTixa.toFixed(8)} TIXA will be deducted from wallet.</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Recipient Address Input */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-mono text-slate-300 font-bold">
                      Recipient TIXA Wallet Address
                    </label>
                    <button
                      type="button"
                      onClick={handleVerifyRecipient}
                      disabled={isVerifying || !recipientAddress.trim()}
                      className="text-[11px] text-cyan-400 hover:text-cyan-300 hover:underline font-mono disabled:opacity-50 flex items-center gap-1"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>{isVerifying ? 'Verifying...' : 'Verify Recipient'}</span>
                    </button>
                  </div>

                  <input
                    type="text"
                    required
                    placeholder="tx1..."
                    value={recipientAddress}
                    onChange={(e) => {
                      setRecipientAddress(e.target.value);
                      setVerifiedRecipient(null);
                      setVerifyError(null);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 focus:border-cyan-500 text-white placeholder-slate-600 font-mono text-xs focus:outline-none transition-colors"
                  />

                  {verifyError && (
                    <div className="text-rose-400 text-[11px] font-mono flex items-center gap-1 mt-1">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>{verifyError}</span>
                    </div>
                  )}

                  {verifiedRecipient && (
                    <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 text-xs font-mono flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>Verified Registered Recipient: <strong>{verifiedRecipient.identifier}</strong></span>
                    </div>
                  )}
                </div>

                {/* Optional Memo / Reference */}
                <div className="space-y-1">
                  <label className="block text-xs font-mono text-slate-300">
                    Reference / Note (Memo - Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Payment, Gift, or Note..."
                    value={memo}
                    onChange={(e) => setMemo(e.target.value)}
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white placeholder-slate-600 font-mono text-xs focus:outline-none focus:border-cyan-500 transition-colors"
                  />
                </div>

                {/* Direct P2P Guarantee Strip */}
                <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/30 font-mono text-[11px] text-slate-300 space-y-1.5">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Transaction Fee (Network Fee):</span>
                    <span className="text-emerald-400 font-bold px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-[10px]">
                      0.0000 TIXA (100% Free - No Charges)
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Admin Intervention:</span>
                    <span className="text-cyan-300 font-bold">
                      0% (No admin approval, direct user-to-user)
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Settlement Speed:</span>
                    <span className="text-emerald-400 font-bold">Instant (0 Seconds)</span>
                  </div>
                </div>

                {/* Submit Send Button */}
                <button
                  type="submit"
                  disabled={isSubmitting || !isMinAmountValid || !isBalanceSufficient || !recipientAddress.trim()}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:from-cyan-300 hover:to-blue-400 text-black font-extrabold text-sm tracking-wide font-mono transition-all shadow-lg shadow-cyan-500/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>
                    {isSubmitting 
                      ? 'Transferring...' 
                      : `Send TIXA Coin P2P (${numericTixa.toFixed(8)} TIXA / $${numericUsd.toFixed(2)} USD)`}
                  </span>
                </button>
              </form>
            )}
          </div>
        )}

        {/* TAB 2: P2P TRANSACTION HISTORY & STATEMENT (লেনদেন হিসাব পেইজ) */}
        {activeTab === 'history' && (
          <div className="space-y-4">
            {/* History Summary Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center gap-1">
                  <ArrowUpRight className="w-3.5 h-3.5 text-rose-400" />
                  <span>Total P2P Sent</span>
                </div>
                <div className="text-sm font-bold text-white">
                  {totalSentTixa.toFixed(8)} TIXA
                </div>
                <div className="text-[10px] text-slate-400">
                  ≈ ${(totalSentTixa * tixaPrice).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center gap-1">
                  <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Total P2P Received</span>
                </div>
                <div className="text-sm font-bold text-white">
                  {totalReceivedTixa.toFixed(8)} TIXA
                </div>
                <div className="text-[10px] text-slate-400">
                  ≈ ${(totalReceivedTixa * tixaPrice).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1">
                <div className="text-[11px] text-slate-400 flex items-center gap-1">
                  <History className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Total P2P Records</span>
                </div>
                <div className="text-sm font-bold text-cyan-400">
                  {historyList.length} Transactions
                </div>
                <div className="text-[10px] text-emerald-400 font-bold">
                  All transfers are 100% Free (0 Fee)
                </div>
              </div>
            </div>

            {/* Filter and Refresh Bar */}
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2">
              <div className="flex items-center gap-1.5 font-mono text-xs">
                <button
                  type="button"
                  onClick={() => setHistoryFilter('ALL')}
                  className={`px-3 py-1 rounded-lg transition-colors ${
                    historyFilter === 'ALL'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  All ({historyList.length})
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryFilter('SENT')}
                  className={`px-3 py-1 rounded-lg transition-colors ${
                    historyFilter === 'SENT'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/50 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Sent ({historyList.filter(i => i.type === 'P2P_SEND').length})
                </button>
                <button
                  type="button"
                  onClick={() => setHistoryFilter('RECEIVED')}
                  className={`px-3 py-1 rounded-lg transition-colors ${
                    historyFilter === 'RECEIVED'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Received ({historyList.filter(i => i.type === 'P2P_RECEIVE').length})
                </button>
              </div>

              <button
                type="button"
                onClick={loadHistory}
                disabled={isLoadingHistory}
                className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors font-mono text-xs flex items-center gap-1"
                title="Refresh"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isLoadingHistory ? 'animate-spin' : ''}`} />
                <span className="hidden sm:inline">Refresh</span>
              </button>
            </div>

            {/* Transactions List Container */}
            <div className="space-y-2 max-h-[360px] overflow-y-auto pr-1">
              {isLoadingHistory ? (
                <div className="p-8 text-center text-slate-400 font-mono text-xs">
                  <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-cyan-400" />
                  <span>Loading P2P Transaction History...</span>
                </div>
              ) : filteredHistory.length === 0 ? (
                <div className="p-8 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-3 font-mono">
                  <div className="w-12 h-12 rounded-xl bg-slate-800/80 flex items-center justify-center mx-auto text-slate-500">
                    <History className="w-6 h-6" />
                  </div>
                  <div className="text-sm font-bold text-slate-300">
                    No P2P transactions found
                  </div>
                  <p className="text-xs text-slate-500">
                    You haven't sent or received any TIXA Coin P2P transfers yet.
                  </p>
                  <button
                    type="button"
                    onClick={() => setActiveTab('transfer')}
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 text-black font-bold text-xs"
                  >
                    Make a new P2P Transfer
                  </button>
                </div>
              ) : (
                filteredHistory.map((tx) => {
                  const isSent = tx.type === 'P2P_SEND';
                  const dateStr = new Date(tx.timestamp).toLocaleString('en-US', {
                    dateStyle: 'medium',
                    timeStyle: 'short'
                  });
                  const computedUsd = tx.usdValue || (tx.amount * tixaPrice);

                  return (
                    <div
                      key={tx.id}
                      className="p-3.5 rounded-2xl bg-slate-900/90 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all font-mono text-xs space-y-2"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                              isSent
                                ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            }`}
                          >
                            {isSent ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                          </div>

                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-white">
                                {isSent ? 'P2P Sent' : 'P2P Received'}
                              </span>
                              <span className="px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-800 text-[10px] text-emerald-300 font-bold">
                                {tx.status || 'COMPLETED'}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400">{dateStr}</div>
                          </div>
                        </div>

                        <div className="text-right">
                          <div
                            className={`font-extrabold text-sm ${
                              isSent ? 'text-rose-400' : 'text-emerald-400'
                            }`}
                          >
                            {isSent ? '-' : '+'}{tx.amount.toFixed(8)} TIXA
                          </div>
                          <div className="text-[11px] text-slate-400">
                            ≈ ${computedUsd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USD
                          </div>
                        </div>
                      </div>

                      {/* Counterparty & Memo details */}
                      <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                        <div className="flex items-center gap-1">
                          <span>{isSent ? 'Recipient:' : 'Sender:'}</span>
                          <span className="text-cyan-300">
                            {tx.recipientIdentifier || (isSent ? tx.recipientAddress : tx.senderAddress) || 'P2P User'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold">Fee: $0.00 (Free)</span>
                          <button
                            type="button"
                            onClick={() => handleCopy(tx.id, tx.id)}
                            className="flex items-center gap-1 text-slate-500 hover:text-white"
                            title="Copy Transaction ID"
                          >
                            {copiedId === tx.id ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                            <span className="text-[10px]">{tx.id.slice(0, 10)}...</span>
                          </button>
                        </div>
                      </div>

                      {tx.reference && (
                        <div className="text-[10px] text-slate-500 italic bg-black/40 px-2 py-1 rounded">
                          Note: {tx.reference}
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
