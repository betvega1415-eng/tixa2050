import React, { useState, useEffect } from 'react';
import { 
  User, 
  ShieldCheck, 
  Key, 
  Lock, 
  Unlock, 
  LogOut, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Globe, 
  Laptop, 
  Trash2, 
  ShieldAlert, 
  RefreshCw,
  ExternalLink,
  Sparkles,
  Zap,
  Edit3,
  Copy,
  Check,
  Eye,
  EyeOff,
  Phone,
  AlertCircle,
  Save,
  X
} from 'lucide-react';
import { authEngine } from '../../core/authEngine';
import { notificationEngine } from '../../core/notificationEngine';
import { HashBadge } from '../common/HashBadge';
import { ThemeSwitcher } from '../common/ThemeSwitcher';
import { ActiveTab } from '../common/Navbar';
import confetti from 'canvas-confetti';
import { useLanguage } from '../../context/LanguageContext';
import { AffiliateDashboard } from './AffiliateDashboard';
import { auth } from '../../lib/firebase';
import { linkWithCredential, EmailAuthProvider, updatePassword, sendPasswordResetEmail } from 'firebase/auth';
import { COUNTRIES, CountryData, getCountryByCode } from '../../data/countries';

interface UserProfileViewProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenAuth: (mode: 'login' | 'register' | 'admin') => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  setActiveTab,
  onOpenAuth
}) => {
  const { currentLanguage, openLanguageModal, t } = useLanguage();
  const [session, setSession] = useState(authEngine.getSession());
  const [account, setAccount] = useState(session ? authEngine.getUserById(session.userId) : null);

  // 9-Digit UID State
  const [copiedUid, setCopiedUid] = useState(false);

  // Name Editing & 90-Day Cooldown State
  const [isEditingName, setIsEditingName] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [nameSaving, setNameSaving] = useState(false);
  const [nameError, setNameError] = useState<string | null>(null);
  const [nameSuccess, setNameSuccess] = useState<string | null>(null);

  // Phone & Global Country Code State
  const [isEditingPhone, setIsEditingPhone] = useState(false);
  const [phoneCountryCode, setPhoneCountryCode] = useState(account?.countryCode || 'BD');
  const [selectedPhoneCountry, setSelectedPhoneCountry] = useState<CountryData>(getCountryByCode(account?.countryCode || 'BD'));
  const [phoneNumberInput, setPhoneNumberInput] = useState('');
  const [phoneSaving, setPhoneSaving] = useState(false);
  const [phoneError, setPhoneError] = useState<string | null>(null);
  const [phoneSuccess, setPhoneSuccess] = useState<string | null>(null);
  const [countrySearch, setCountrySearch] = useState('');

  // 12-Word Secret Recovery Seed Phrase State
  const [seedPhrase, setSeedPhrase] = useState<string>('');
  const [showSeedWords, setShowSeedWords] = useState(false);
  const [copiedSeed, setCopiedSeed] = useState(false);

  // Security Form States
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pwdMsg, setPwdMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // KYC / Verification State
  const [kycTier, setKycTier] = useState<'TIER_1_STANDARD' | 'TIER_2_INSTITUTIONAL'>('TIER_2_INSTITUTIONAL');
  const [kycStatus, setKycStatus] = useState<'VERIFIED' | 'PENDING' | 'UNVERIFIED'>('VERIFIED');

  // Active Sessions
  const [activeSessions, setActiveSessions] = useState([
    { id: 'sess_current', device: 'Chrome on macOS (Current)', ip: '142.250.190.46', location: 'San Jose, USA', lastActive: 'Active Now', current: true },
    { id: 'sess_mobile_02', device: 'TIXA Mobile App (iOS)', ip: '172.56.42.10', location: 'Tokyo, Japan', lastActive: '2 hours ago', current: false },
    { id: 'sess_terminal_03', device: 'Linux Node CLI v2.4', ip: '104.244.42.1', location: 'Frankfurt, Germany', lastActive: 'Yesterday', current: false }
  ]);

  useEffect(() => {
    const update = () => {
      const s = authEngine.getSession();
      setSession(s);
      if (s) {
        const u = authEngine.getUserById(s.userId);
        setAccount(u);
        if (u) {
          setNameInput(u.name || u.email.split('@')[0]);
          if (u.countryCode) {
            setPhoneCountryCode(u.countryCode);
            setSelectedPhoneCountry(getCountryByCode(u.countryCode));
          }
          if (u.phone) {
            // Strip calling code if included
            const cc = u.callingCode || '+880';
            const rawPhone = u.phone.startsWith(cc) ? u.phone.replace(cc, '').trim() : u.phone;
            setPhoneNumberInput(rawPhone);
          }
          if (u.secretPhrase) {
            setSeedPhrase(u.secretPhrase);
          } else {
            authEngine.getOrCreateUserSeedPhrase(u.id).then(p => setSeedPhrase(p));
          }
        }
      } else {
        setAccount(null);
      }
    };
    update();
    const unsub = authEngine.subscribe(update);
    return unsub;
  }, []);

  const [isLinking, setIsLinking] = useState(false);
  const currentUser = auth.currentUser;
  const linkedProviders = currentUser?.providerData?.map(p => p.providerId) || [];
  const isGoogleConnected = linkedProviders.includes('google.com');
  const isPasswordConnected = linkedProviders.includes('password') || Boolean(account?.hasCustomPassword);

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdMsg(null);

    if (!newPassword || newPassword.length < 8) {
      setPwdMsg({ type: 'error', text: 'New password must be at least 8 characters long.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setPwdMsg({ type: 'error', text: 'New password and confirm password do not match.' });
      return;
    }

    setIsLinking(true);
    try {
      if (!currentUser || !currentUser.email) {
        throw new Error('Please log in again.');
      }

      if (!isPasswordConnected) {
        try {
          const credential = EmailAuthProvider.credential(currentUser.email, newPassword);
          await linkWithCredential(currentUser, credential);
        } catch (linkErr: any) {
          console.warn('Firebase link credential note:', linkErr);
          if (linkErr.code === 'auth/provider-already-linked') {
            await updatePassword(currentUser, newPassword);
          }
        }
      } else {
        await updatePassword(currentUser, newPassword);
      }

      // Sync updated password hash to authEngine & Firestore user document (preserving Google UID)
      const targetUserId = session?.userId || currentUser.uid;
      const res = await authEngine.updateUserPassword(targetUserId, newPassword);
      setAccount(res.user);

      setPwdMsg({ 
        type: 'success', 
        text: '✅ Password saved successfully! You can now log in using your Gmail, registered mobile number, or 12-word seed phrase.' 
      });

      notificationEngine.addNotification(
        'SECURITY_ALERT',
        'Password Update Successful',
        'Your account security credentials have been updated successfully.'
      );

      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err: any) {
      console.error('Password linking error:', err);
      let errMsg = err?.message || 'Failed to set password.';
      if (err.code === 'auth/requires-recent-login') {
        errMsg = 'For security reasons, please log in again and retry.';
      } else if (err.code === 'auth/credential-already-in-use') {
        errMsg = 'This email is already in use by another account.';
      }
      setPwdMsg({ type: 'error', text: errMsg });
    } finally {
      setIsLinking(false);
    }
  };

  const handleForgotPassword = async () => {
    setPwdMsg(null);
    try {
      const email = currentUser?.email || account?.email;
      if (!email) {
        setPwdMsg({ type: 'error', text: 'No email address found.' });
        return;
      }
      await sendPasswordResetEmail(auth, email);
      setPwdMsg({ type: 'success', text: `Password reset link has been sent to ${email}. Please check your inbox.` });
      notificationEngine.addNotification(
        'SECURITY_ALERT',
        'Password Reset Email',
        'Password reset instructions have been sent to your email.'
      );
    } catch (err: any) {
      setPwdMsg({ type: 'error', text: 'Failed to send password reset email: ' + (err?.message || '') });
    }
  };

  // Cooldown calculation for 90 days (7,776,000,000 ms)
  const NINETY_DAYS_MS = 90 * 24 * 60 * 60 * 1000;
  const isNameChangeLocked = Boolean(account?.lastNameChangeAt && (Date.now() - account.lastNameChangeAt < NINETY_DAYS_MS));
  const remainingDaysForName = account?.lastNameChangeAt 
    ? Math.max(1, Math.ceil((account.lastNameChangeAt + NINETY_DAYS_MS - Date.now()) / (24 * 60 * 60 * 1000))) 
    : 0;

  const handleCopyUid = (uidStr: string) => {
    navigator.clipboard.writeText(uidStr);
    setCopiedUid(true);
    setTimeout(() => setCopiedUid(false), 2000);
  };

  const handleCopySeed = (words: string) => {
    navigator.clipboard.writeText(words);
    setCopiedSeed(true);
    setTimeout(() => setCopiedSeed(false), 2000);
  };

  const handleSaveName = async (e: React.FormEvent) => {
    e.preventDefault();
    setNameError(null);
    setNameSuccess(null);
    if (!nameInput.trim()) {
      setNameError('Please enter a display name.');
      return;
    }
    if (isNameChangeLocked) {
      setNameError(`Name update is locked. You can change it again in ${remainingDaysForName} day(s).`);
      return;
    }
    setNameSaving(true);
    try {
      if (!session) throw new Error('Session not found. Please log in.');
      const res = await authEngine.updateUserName(session.userId, nameInput.trim());
      setAccount(res.user);
      setNameSuccess('✅ Your name was updated successfully and locked for the next 90 days.');
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      setIsEditingName(false);
      setTimeout(() => setNameSuccess(null), 5000);
    } catch (err: any) {
      setNameError(err.message || 'Failed to update name.');
    } finally {
      setNameSaving(false);
    }
  };

  const handleSavePhone = async (e: React.FormEvent) => {
    e.preventDefault();
    setPhoneError(null);
    setPhoneSuccess(null);
    if (!phoneNumberInput.trim()) {
      setPhoneError('Please enter a valid phone number.');
      return;
    }
    setPhoneSaving(true);
    try {
      if (!session) throw new Error('Session not found. Please log in.');
      const res = await authEngine.updateUserPhone(session.userId, {
        phone: phoneNumberInput.trim(),
        countryCode: selectedPhoneCountry.code,
        countryName: selectedPhoneCountry.name,
        callingCode: selectedPhoneCountry.callingCode
      });
      setAccount(res.user);
      setPhoneSuccess(`✅ Phone number updated successfully: ${res.user.phone}`);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      setIsEditingPhone(false);
      setTimeout(() => setPhoneSuccess(null), 5000);
    } catch (err: any) {
      setPhoneError(err.message || 'Failed to update phone number.');
    } finally {
      setPhoneSaving(false);
    }
  };

  const handleLogoutAll = () => {
    setActiveSessions(activeSessions.filter(s => s.current));
    notificationEngine.addNotification(
      'SECURITY_ALERT',
      'Sessions Terminated',
      'All other active mobile and desktop sessions were invalidated.'
    );
  };

  if (!session) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-slate-900 border border-cyan-500/30 mx-auto flex items-center justify-center">
          <Lock className="w-8 h-8 text-cyan-400" />
        </div>
        <h2 className="text-2xl font-bold text-white font-heading">
          Authentication Required
        </h2>
        <p className="text-sm text-slate-400">
          Please log in or register to access your personalized Profile & Security settings.
        </p>
        <div className="flex justify-center gap-4">
          <button
            type="button"
            onClick={() => onOpenAuth('login')}
            className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs shadow-lg"
          >
            Login to Vault
          </button>
          <button
            type="button"
            onClick={() => onOpenAuth('register')}
            className="px-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs"
          >
            Register
          </button>
        </div>
      </div>
    );
  }

  const userNumericUid = account?.numericUid || (account?.id ? account.id.slice(-9).replace(/\D/g, '') || '984210357' : '984210357');
  const seedWordsList = (seedPhrase || 'quantum orbit matrix nexus cyber solar element horizon beacon forge logic vector').split(' ');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8 animate-in fade-in duration-300">
      {/* Profile Header with 9-digit UID and 90-day Name Editing */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#09122a] via-[#091938] to-[#07132a] border border-cyan-500/30 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-start sm:items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-black font-black text-2xl shadow-xl shadow-cyan-500/25 shrink-0">
            TX
          </div>
          <div className="space-y-1.5 flex-1">
            {/* User Name with 90-Day Edit Flow */}
            <div className="flex flex-wrap items-center gap-2.5">
              {isEditingName ? (
                <form onSubmit={handleSaveName} className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    value={nameInput}
                    onChange={(e) => setNameInput(e.target.value)}
                    placeholder="Enter full name"
                    className="px-3 py-1.5 rounded-xl bg-slate-900 border border-cyan-500 text-white font-bold text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-cyan-500/30"
                  />
                  <button
                    type="submit"
                    disabled={nameSaving}
                    className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-black font-bold text-xs shadow-md transition-all flex items-center gap-1"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{nameSaving ? 'Saving...' : 'Save'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsEditingName(false);
                      setNameError(null);
                    }}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </form>
              ) : (
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-bold text-white font-heading">
                    {account?.name || session.email.split('@')[0]}
                  </h1>
                  {isNameChangeLocked ? (
                    <span 
                      title={`Name change is locked. You can change it again in ${remainingDaysForName} day(s).`}
                      className="px-2 py-0.5 rounded-full bg-slate-800 text-amber-300 border border-amber-500/30 text-[10px] font-mono flex items-center gap-1 cursor-help"
                    >
                      <Lock className="w-3 h-3 text-amber-400" />
                      <span>{remainingDaysForName}d Locked</span>
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditingName(true);
                        setNameInput(account?.name || session.email.split('@')[0]);
                        setNameError(null);
                      }}
                      className="p-1 rounded-lg bg-slate-800/80 hover:bg-cyan-950 text-cyan-400 hover:text-cyan-300 transition-colors border border-cyan-500/20"
                      title="Edit Name (Allowed once every 90 days)"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              )}

              {/* 9-Digit Unique UID Badge */}
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-950/80 border border-cyan-500/50 shadow-inner">
                <span className="text-[10px] font-mono font-bold text-cyan-400">UID:</span>
                <span className="text-xs font-mono font-black text-white tracking-widest">{userNumericUid}</span>
                <button
                  type="button"
                  onClick={() => handleCopyUid(userNumericUid)}
                  className="p-0.5 hover:text-cyan-300 text-slate-400 transition-colors"
                  title="Copy 9-Digit UID"
                >
                  {copiedUid ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 text-cyan-400" />}
                </button>
              </div>

              {/* KYC Status Badge */}
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold">
                <CheckCircle2 className="w-3 h-3" />
                <span>KYC VERIFIED TIER 2</span>
              </span>
            </div>

            {nameError && (
              <p className="text-xs text-rose-400 font-mono flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{nameError}</span>
              </p>
            )}
            {nameSuccess && (
              <p className="text-xs text-emerald-400 font-mono flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                <span>{nameSuccess}</span>
              </p>
            )}

            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 font-mono">
              <span>{session.email}</span>
              <span>•</span>
              <span className="text-slate-400 flex items-center gap-1">
                <Phone className="w-3 h-3 text-cyan-400" />
                <span>{account?.phone || 'No phone number linked'}</span>
              </span>
            </div>

            <div className="pt-1">
              <HashBadge hash={session.walletAddress} type="address" />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => {
              authEngine.logoutUser();
              setActiveTab('home');
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/60 border border-rose-500/30 text-rose-300 text-xs font-semibold transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* DEDICATED AFFILIATE DASHBOARD (LIVE STATISTICS, REFERRAL CONTRIBUTIONS & UNMERGED BALANCE) */}
      {account && (
        <AffiliateDashboard
          account={account}
          onRefreshAccount={() => {
            const s = authEngine.getSession();
            if (s) setAccount(authEngine.getUserById(s.userId));
          }}
        />
      )}

      {/* 2 NEW CORE CARDS: 12-Word Seed Recovery Phrase & Mobile Phone with Global Country Codes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* CARD 1: 12-Word Secret Recovery Seed Phrase Box */}
        <div className="p-6 rounded-3xl bg-[#060b1b] border border-cyan-500/30 shadow-2xl space-y-4 relative overflow-hidden">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-heading flex items-center gap-2">
                  <span>12-Word Secret Recovery Seed Phrase</span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-mono font-bold">12 Words</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Your primary master recovery key for Google or email accounts. Keep it secure and private.
                </p>
              </div>
            </div>

            {/* Action Buttons: Eye (Toggle visibility) & Copy */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setShowSeedWords(!showSeedWords)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all border ${
                  showSeedWords
                    ? 'bg-amber-950/70 border-amber-500/50 text-amber-300 hover:bg-amber-900/80'
                    : 'bg-cyan-950/70 border-cyan-500/50 text-cyan-300 hover:bg-cyan-900/80'
                }`}
                title={showSeedWords ? 'Hide seed words' : 'Click to reveal seed words'}
              >
                {showSeedWords ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                <span>{showSeedWords ? 'Hide Words' : 'Show Seed'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleCopySeed(seedPhrase || seedWordsList.join(' '))}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-mono font-bold transition-all shadow-md"
                title="Copy all 12 words"
              >
                {copiedSeed ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-cyan-400" />}
                <span>{copiedSeed ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Seed Words 12-Box Grid */}
          <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800/80">
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
              {seedWordsList.slice(0, 12).map((word, idx) => (
                <div
                  key={idx}
                  className="px-3 py-2 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs font-mono"
                >
                  <span className="text-[10px] text-slate-500 font-bold select-none">#{idx + 1}</span>
                  <span className={`font-bold transition-all tracking-wide ${showSeedWords ? 'text-white' : 'text-slate-600 select-none blur-[3px]'}`}>
                    {showSeedWords ? word : '•••••••'}
                  </span>
                </div>
              ))}
            </div>

            <div className="mt-3.5 pt-3 border-t border-slate-800/80 flex items-start gap-2 text-[11px] text-slate-400 font-sans">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <span>
                <strong>Security Notice:</strong> Write down these 12 words and store them in a secure offline location. Even if you lose your password or access, this seed phrase allows you to restore your wallet and funds on any device.
              </span>
            </div>
          </div>
        </div>

        {/* CARD 2: Mobile Phone & Global Country Code Addition */}
        <div className="p-6 rounded-3xl bg-[#060b1b] border border-cyan-500/30 shadow-2xl space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-blue-950 text-blue-400 border border-blue-800">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-heading">
                  Mobile Phone & Global Country Code
                </h3>
                <p className="text-xs text-slate-400">
                  Add or update your phone number with your country calling code for dual-factor security and account access.
                </p>
              </div>
            </div>

            {!isEditingPhone && (
              <button
                type="button"
                onClick={() => {
                  setIsEditingPhone(true);
                  setPhoneError(null);
                  setPhoneSuccess(null);
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/40 text-cyan-300 text-xs font-mono font-bold transition-all flex items-center gap-1.5"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{account?.phone ? 'Update Phone' : 'Add Phone'}</span>
              </button>
            )}
          </div>

          {phoneError && (
            <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs font-mono flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{phoneError}</span>
            </div>
          )}
          {phoneSuccess && (
            <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{phoneSuccess}</span>
            </div>
          )}

          {isEditingPhone ? (
            <form onSubmit={handleSavePhone} className="space-y-3.5 p-4 rounded-2xl bg-slate-950/90 border border-slate-800 text-xs font-mono">
              <div>
                <label className="block text-slate-400 mb-1.5 font-bold">1. Select Global Country & Code</label>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-2xl">{selectedPhoneCountry.flag}</span>
                  <select
                    value={phoneCountryCode}
                    onChange={(e) => {
                      const code = e.target.value;
                      setPhoneCountryCode(code);
                      const c = getCountryByCode(code);
                      setSelectedPhoneCountry(c);
                    }}
                    className="flex-1 px-3 py-2 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs focus:border-cyan-400 focus:outline-none"
                  >
                    {COUNTRIES.map(c => (
                      <option key={c.code} value={c.code}>
                        {c.flag} {c.name} ({c.callingCode})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1.5 font-bold">2. Phone Number</label>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-cyan-300 font-bold shrink-0">
                    {selectedPhoneCountry.callingCode}
                  </span>
                  <input
                    type="tel"
                    required
                    value={phoneNumberInput}
                    onChange={(e) => setPhoneNumberInput(e.target.value)}
                    placeholder={selectedPhoneCountry.phonePlaceholder || '1712-345678'}
                    className="flex-1 px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditingPhone(false);
                    setPhoneError(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={phoneSaving}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-1.5 disabled:opacity-50"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{phoneSaving ? 'Saving...' : 'Save Phone Number'}</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs font-mono">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{selectedPhoneCountry.flag}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white font-sans">{selectedPhoneCountry.name}</span>
                    <span className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 text-[10px] border border-blue-800">
                      {selectedPhoneCountry.callingCode}
                    </span>
                  </div>
                  <p className="text-cyan-300 font-mono text-sm mt-0.5">
                    {account?.phone || 'No phone number attached yet'}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold border inline-flex items-center gap-1 ${
                  account?.phone
                    ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                    : 'bg-amber-950/60 text-amber-300 border-amber-800'
                }`}>
                  {account?.phone ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <AlertCircle className="w-3 h-3 text-amber-400" />}
                  <span>{account?.phone ? 'Linked' : 'Not Linked'}</span>
                </span>
              </div>
            </div>
          )}
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Security & Settings */}
        <div className="lg:col-span-2 space-y-6">
          {/* Language & Internationalization Settings (99 Countries) */}
          <div className="p-6 rounded-3xl bg-[#060b1b] border border-cyan-500/25 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-cyan-950 text-cyan-400 border border-cyan-800">
                  <Globe className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-heading">
                    {t('settings_language', 'Interface Language')}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Switch between 99 country languages. All menus, balances, and notifications translate instantly.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{currentLanguage.flag}</span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-white font-sans">{currentLanguage.nativeName}</span>
                    <span className="text-xs text-slate-400 font-mono">({currentLanguage.name})</span>
                    <span className="px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 text-[10px] font-mono border border-cyan-800">
                      {currentLanguage.code.toUpperCase()}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono">
                    Region: {currentLanguage.region} • Country: {currentLanguage.country}
                  </span>
                </div>
              </div>

              <button
                type="button"
                id="profile-open-language-modal-btn"
                onClick={openLanguageModal}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-md shadow-cyan-500/20 transition-all flex items-center gap-1.5 font-mono"
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{t('btn_select_language', 'Change Language (99 Available)')}</span>
              </button>
            </div>
          </div>

          {/* Change Password & Sign-In Methods Card */}
          <div className="p-6 rounded-3xl bg-[#060b1b] border border-cyan-500/25 space-y-4 shadow-xl">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-purple-950 text-purple-400 border border-purple-800">
                <Key className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-white font-heading">
                  {isPasswordConnected ? 'Change Password & Sign-In Methods' : 'Link Email & Password (Google Sign-In Linking)'}
                </h3>
                <p className="text-xs text-slate-400">
                  {isPasswordConnected 
                    ? 'Manage your master password and login credentials.' 
                    : 'Create a password for your Google-registered account to enable dual login (Google + Email/Password).'}
                </p>
              </div>
            </div>

            {/* Connected Sign-In Methods Badges */}
            <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs font-mono">
              <span className="text-slate-400">Connected Login Providers:</span>
              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border flex items-center gap-1.5 ${
                  isGoogleConnected ? 'bg-emerald-950 text-emerald-300 border-emerald-600/50' : 'bg-slate-900 text-slate-500 border-slate-800'
                }`}>
                  <Sparkles className="w-3 h-3 text-emerald-400" />
                  <span>Google Sign-In {isGoogleConnected ? '(Active)' : ''}</span>
                </span>
                <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold border flex items-center gap-1.5 ${
                  isPasswordConnected ? 'bg-cyan-950 text-cyan-300 border-cyan-600/50' : 'bg-amber-950/60 text-amber-300 border-amber-600/50'
                }`}>
                  <Lock className="w-3 h-3 text-cyan-400" />
                  <span>Email + Password {isPasswordConnected ? '(Linked)' : '(Not Linked)'}</span>
                </span>
              </div>
            </div>

            {pwdMsg && (
              <div className={`p-3 rounded-xl text-xs font-mono flex items-center gap-2 ${
                pwdMsg.type === 'success' 
                  ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-500/30' 
                  : 'bg-rose-950/60 text-rose-300 border border-rose-500/30'
              }`}>
                {pwdMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                <span>{pwdMsg.text}</span>
              </div>
            )}

            <form onSubmit={handlePasswordChange} className="space-y-4 text-xs font-mono">
              {isPasswordConnected && (
                <div>
                  <label className="block text-slate-400 mb-1">Current Password (optional if resetting)</label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">
                    {isPasswordConnected ? 'New Password' : 'Create Password'}
                  </label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Min 8 characters"
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Confirm Password</label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full px-3.5 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                {isPasswordConnected ? (
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    className="text-cyan-400 hover:text-cyan-300 font-mono text-xs underline"
                  >
                    Forgot Password? (Send Reset Email)
                  </button>
                ) : (
                  <span className="text-[11px] text-slate-400 font-sans">
                    💡 Linking a password allows signing in with your email & password instantly.
                  </span>
                )}

                <button
                  type="submit"
                  disabled={isLinking}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
                >
                  {isLinking ? 'Processing...' : (isPasswordConnected ? 'Update Password' : 'Create Password & Link')}
                </button>
              </div>
            </form>
          </div>

          {/* Interface Visual Theme Engine Card */}
          <ThemeSwitcher variant="card" />

          {/* Active Sessions Manager */}
          <div className="p-6 rounded-3xl bg-[#060b1b] border border-cyan-500/25 space-y-4 shadow-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-950 text-blue-400 border border-blue-800">
                  <Laptop className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white font-heading">
                    Active Devices & Sessions
                  </h3>
                  <p className="text-xs text-slate-400">
                    Devices currently authorized to access your non-custodial vault.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={handleLogoutAll}
                className="text-xs text-rose-400 hover:text-rose-300 font-mono underline"
              >
                Terminate Other Sessions
              </button>
            </div>

            <div className="space-y-2">
              {activeSessions.map((s) => (
                <div
                  key={s.id}
                  className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between text-xs font-mono"
                >
                  <div className="flex items-center gap-3">
                    <Laptop className="w-4 h-4 text-cyan-400" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white font-sans">{s.device}</span>
                        {s.current && (
                          <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[9px] border border-emerald-800 font-bold">
                            THIS DEVICE
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-slate-400">
                        IP: {s.ip} • {s.location}
                      </span>
                    </div>
                  </div>

                  <span className="text-slate-400 text-[11px]">{s.lastActive}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right 1 Col: Account Status & KYC */}
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-[#060b1b] border border-cyan-500/25 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-white font-heading flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <span>Identity Verification (KYC)</span>
            </h3>

            <div className="p-4 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Level:</span>
                <span className="text-emerald-400 font-bold">Tier 2 Institutional</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Daily Limit:</span>
                <span className="text-white font-bold">$10,000,000 USD</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-300">Withdrawal Speed:</span>
                <span className="text-cyan-300 font-bold">Instant BFT 3.0s</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              Your account identity has passed cryptographic AML and zero-knowledge identity proofs. No further verification required.
            </p>
          </div>

          <div className="p-6 rounded-3xl bg-[#060b1b] border border-cyan-500/25 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-white font-heading flex items-center gap-2">
              <Zap className="w-5 h-5 text-cyan-400" />
              <span>Connected Web3 Keys</span>
            </h3>

            <div className="space-y-2 text-xs font-mono">
              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-white font-bold block">TIXA Local Vault</span>
                  <span className="text-[10px] text-slate-500">Ed25519 Native</span>
                </div>
                <span className="text-emerald-400 text-[10px]">CONNECTED</span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-white font-bold block">Hardware Ledger Nano</span>
                  <span className="text-[10px] text-slate-500">FIDO2 / U2F Security</span>
                </div>
                <span className="text-cyan-400 text-[10px]">ENROLLED</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
