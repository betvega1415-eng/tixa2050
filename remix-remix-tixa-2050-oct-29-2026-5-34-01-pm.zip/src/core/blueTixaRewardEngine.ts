import { 
  BlueTixaAdminConfig, 
  BlueTixaRewardLedgerEvent, 
  BlueTixaWithdrawal, 
  BlueTixaCreatorStats, 
  BlueTixaViewerStats,
  SupportedWithdrawalNetwork,
  WithdrawalStatus
} from '../types/blueTixa';
import { blockchainEngine } from './blockchainEngine';
import { auditEngine } from './auditEngine';

const STORAGE_KEY_REWARDS = 'tixa_blue_rewards_ledger_v1';
const STORAGE_KEY_WITHDRAWALS = 'tixa_blue_withdrawals_v1';
const STORAGE_KEY_ADMIN_CONFIG = 'tixa_blue_admin_config_v1';

export const DEFAULT_ADMIN_CONFIG: BlueTixaAdminConfig = {
  viewerRewardPointsPerMin: 20, // 20 pts/min of active watch
  creatorRewardPointsPer1kEligibleViews: 200, // 200 pts ($2.00) per 1k eligible views
  minEligibleWatchSeconds: 5, // minimum 5 seconds continuous watch
  viewerDailyMaxPoints: 200, // max 200 pts ($2.00) / day per viewer
  minWithdrawalPoints: 500, // STRICT REQUIREMENT: 500 Points = $5 USD
  pointsPerUsd: 100, // STRICT REQUIREMENT: 100 Points = $1 USD
  supportedNetworks: [
    { id: 'TIXA_MAINNET', name: 'TIXA Native Mainnet v2.4', asset: 'TIXA', feeUsd: 0.00, enabled: true },
    { id: 'USDT_TRC20', name: 'Tether USDT (TRC-20)', asset: 'USDT', feeUsd: 0.00, enabled: true },
    { id: 'USDT_BEP20', name: 'Tether USDT (BNB Chain BEP-20)', asset: 'USDT', feeUsd: 0.00, enabled: true },
    { id: 'USDT_ERC20', name: 'Tether USDT (Ethereum ERC-20)', asset: 'USDT', feeUsd: 1.00, enabled: true }
  ],
  fraudDetectionLevel: 'STRICT',
  autoApproveThresholdUsd: 25.00
};

class BlueTixaRewardEngine {
  private events: BlueTixaRewardLedgerEvent[] = [];
  private withdrawals: BlueTixaWithdrawal[] = [];
  private adminConfig: BlueTixaAdminConfig = DEFAULT_ADMIN_CONFIG;
  private listeners: Set<() => void> = new Set();

  // In-memory anti-fraud view tracking: key = `${viewerUserId}_${videoId}`
  private viewCache: Map<string, { lastViewedAt: number; totalSeconds: number; isEligible: boolean }> = new Map();
  // Viewer daily counter: key = `${viewerUserId}_${YYYY-MM-DD}`
  private dailyViewerPoints: Map<string, number> = new Map();
  // Blocked / suspicious accounts
  private suspiciousAccounts: Set<string> = new Set();

  constructor() {
    this.loadState();
    this.seedInitialDataIfEmpty();
  }

  private loadState() {
    try {
      const savedConfig = localStorage.getItem(STORAGE_KEY_ADMIN_CONFIG);
      if (savedConfig) {
        this.adminConfig = { ...DEFAULT_ADMIN_CONFIG, ...JSON.parse(savedConfig) };
      }
      const savedEvents = localStorage.getItem(STORAGE_KEY_REWARDS);
      if (savedEvents) {
        this.events = JSON.parse(savedEvents);
      }
      const savedWd = localStorage.getItem(STORAGE_KEY_WITHDRAWALS);
      if (savedWd) {
        this.withdrawals = JSON.parse(savedWd);
      }
    } catch (e) {
      console.warn('Failed to load Blue Tixa reward state', e);
    }
  }

  private saveState() {
    try {
      localStorage.setItem(STORAGE_KEY_ADMIN_CONFIG, JSON.stringify(this.adminConfig));
      localStorage.setItem(STORAGE_KEY_REWARDS, JSON.stringify(this.events.slice(-500)));
      localStorage.setItem(STORAGE_KEY_WITHDRAWALS, JSON.stringify(this.withdrawals.slice(-200)));
    } catch (e) {
      console.warn('Failed to save Blue Tixa reward state', e);
    }
    this.notify();
  }

  private seedInitialDataIfEmpty() {
    if (this.events.length === 0) {
      const now = Date.now();
      // Seed historical verified events for demo creator Elena and demo viewer
      const sampleEvents: BlueTixaRewardLedgerEvent[] = [
        {
          id: 'bt_evt_genesis_01',
          userId: 'user_crypto_elena',
          type: 'CREATOR_ELIGIBLE_VIEW',
          videoId: 'bt_vid_002',
          points: 5580,
          usdValue: 55.80,
          status: 'AVAILABLE',
          description: 'Creator Video Engagement Reward (27,900 Eligible Views)',
          fingerprint: 'fp_batch_verified_mainnet_001',
          fraudScore: 2,
          createdAt: now - 1000 * 60 * 60 * 24,
          verifiedAt: now - 1000 * 60 * 60 * 24
        },
        {
          id: 'bt_evt_genesis_02',
          userId: 'user_tixa_whale',
          type: 'CREATOR_ELIGIBLE_VIEW',
          videoId: 'bt_vid_003',
          points: 11860,
          usdValue: 118.60,
          status: 'AVAILABLE',
          description: 'Creator Video Engagement Reward (59,300 Eligible Views)',
          fingerprint: 'fp_batch_verified_mainnet_002',
          fraudScore: 1,
          createdAt: now - 1000 * 60 * 60 * 48,
          verifiedAt: now - 1000 * 60 * 60 * 48
        },
        // Seed default current user welcome + watch points so user has a working balance (e.g. 1,250 points = $12.50)
        {
          id: 'bt_evt_user_welcome',
          userId: 'CURRENT_USER',
          type: 'DAILY_LOGIN_BONUS',
          points: 250,
          usdValue: 2.50,
          status: 'AVAILABLE',
          description: 'BLUE TIXA Welcome Genesis Creator Grant',
          fingerprint: 'fp_sys_welcome_grant',
          fraudScore: 0,
          createdAt: now - 1000 * 60 * 60 * 6,
          verifiedAt: now - 1000 * 60 * 60 * 6
        },
        {
          id: 'bt_evt_user_watch_01',
          userId: 'CURRENT_USER',
          type: 'VIEWER_WATCH_REWARD',
          videoId: 'bt_vid_001',
          points: 1000,
          usdValue: 10.00,
          status: 'AVAILABLE',
          description: 'Verified Short-Video Continuous Watch Reward (30 mins verified watch)',
          fingerprint: 'fp_watch_verified_bt001',
          fraudScore: 0,
          createdAt: now - 1000 * 60 * 60 * 3,
          verifiedAt: now - 1000 * 60 * 60 * 3
        }
      ];
      this.events = sampleEvents;

      // Sample completed withdrawal
      this.withdrawals = [
        {
          id: 'bt_wd_seed_987',
          userId: 'user_crypto_elena',
          userName: 'Elena Rostova',
          walletAddress: 'TXA77123aBc89ef45601234567890abcdef12345678',
          network: 'TIXA_MAINNET',
          asset: 'TIXA',
          requestedPoints: 2000,
          usdAmount: 20.00,
          assetPayoutAmount: 0.000020,
          feeUsd: 0,
          status: 'COMPLETED',
          txHash: '0x8f3c429a9971bc1829e2f9d8a391cb094892c901eef2a874b9281a947d519b7a',
          requestedAt: now - 1000 * 60 * 60 * 18,
          processedAt: now - 1000 * 60 * 60 * 17,
          adminNotes: 'Automated on-chain instant settlement'
        }
      ];

      this.saveState();
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    setTimeout(() => {
      this.listeners.forEach(l => {
        try {
          l();
        } catch (e) {
          console.error(e);
        }
      });
    }, 0);
  }

  // --- ANTI-FRAUD WATCH & REWARD PROCESSING ---

  /**
   * Records a user watching a video and verifies eligibility with anti-fraud controls.
   */
  public recordWatchSession(params: {
    videoId: string;
    creatorId: string;
    viewerUserId: string;
    watchDurationSeconds: number;
    completedLoop?: boolean;
    deviceFingerprint?: string;
  }): {
    eligibleForCreatorReward: boolean;
    eligibleForViewerReward: boolean;
    viewerPointsAwarded: number;
    creatorPointsAwarded: number;
    fraudReason?: string;
  } {
    const { videoId, creatorId, viewerUserId, watchDurationSeconds, deviceFingerprint = 'web_client_v1' } = params;
    const now = Date.now();
    const todayKey = `${viewerUserId}_${new Date().toISOString().split('T')[0]}`;

    // Anti-fraud: Suspicious account check
    if (this.suspiciousAccounts.has(viewerUserId) || this.suspiciousAccounts.has(creatorId)) {
      return {
        eligibleForCreatorReward: false,
        eligibleForViewerReward: false,
        viewerPointsAwarded: 0,
        creatorPointsAwarded: 0,
        fraudReason: 'Account flagged for suspicious velocity'
      };
    }

    // 1. Check Creator View Eligibility
    // Self-views do NOT generate creator rewards!
    const isSelfView = viewerUserId === creatorId || (viewerUserId === 'CURRENT_USER' && creatorId === 'CURRENT_USER');
    const viewKey = `${viewerUserId}_${videoId}`;
    const previousSession = this.viewCache.get(viewKey);

    let eligibleForCreatorReward = false;
    let creatorPointsAwarded = 0;

    // Must exceed minimum watch threshold (e.g. 5 seconds)
    const meetsMinDuration = watchDurationSeconds >= this.adminConfig.minEligibleWatchSeconds;

    // Cooldown rule: 1 eligible view per user per video per 30 minutes
    const isWithinCooldown = previousSession && (now - previousSession.lastViewedAt < 1000 * 60 * 30);

    if (!isSelfView && meetsMinDuration && !isWithinCooldown) {
      eligibleForCreatorReward = true;
      // Calculate creator points: 0.20 points per eligible view
      creatorPointsAwarded = Number((this.adminConfig.creatorRewardPointsPer1kEligibleViews / 1000).toFixed(2));

      // Record creator reward event in ledger
      const creatorEvent: BlueTixaRewardLedgerEvent = {
        id: `bt_evt_c_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        userId: creatorId,
        type: 'CREATOR_ELIGIBLE_VIEW',
        videoId: videoId,
        points: creatorPointsAwarded,
        usdValue: Number((creatorPointsAwarded / this.adminConfig.pointsPerUsd).toFixed(4)),
        status: 'AVAILABLE',
        description: `Verified Eligible View on Video #${videoId}`,
        fingerprint: `fp_${deviceFingerprint}_${videoId}`,
        fraudScore: 0,
        createdAt: now,
        verifiedAt: now
      };
      this.events.push(creatorEvent);
    }

    // 2. Check Viewer Watch Reward Eligibility
    let eligibleForViewerReward = false;
    let viewerPointsAwarded = 0;

    // Viewer gets points based on continuous watch time (e.g. 20 pts / min = 0.33 pts / sec)
    const todayEarned = this.dailyViewerPoints.get(todayKey) || 0;
    const dailyCap = this.adminConfig.viewerDailyMaxPoints;

    if (meetsMinDuration && todayEarned < dailyCap) {
      // Calculate watch points: capped at 60s per session chunk
      const creditedSeconds = Math.min(watchDurationSeconds, 60);
      const calculatedPoints = Math.round((creditedSeconds / 60) * this.adminConfig.viewerRewardPointsPerMin);
      
      const allowablePoints = Math.min(calculatedPoints, dailyCap - todayEarned);

      if (allowablePoints > 0) {
        eligibleForViewerReward = true;
        viewerPointsAwarded = allowablePoints;
        this.dailyViewerPoints.set(todayKey, todayEarned + allowablePoints);

        const viewerEvent: BlueTixaRewardLedgerEvent = {
          id: `bt_evt_v_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
          userId: viewerUserId,
          type: 'VIEWER_WATCH_REWARD',
          videoId: videoId,
          points: viewerPointsAwarded,
          usdValue: Number((viewerPointsAwarded / this.adminConfig.pointsPerUsd).toFixed(4)),
          status: 'AVAILABLE',
          description: `Watch Time Reward (${creditedSeconds}s continuous video view)`,
          fingerprint: `fp_v_${deviceFingerprint}_${now}`,
          fraudScore: 0,
          createdAt: now,
          verifiedAt: now
        };
        this.events.push(viewerEvent);
      }
    }

    // Update view cache
    this.viewCache.set(viewKey, {
      lastViewedAt: now,
      totalSeconds: (previousSession?.totalSeconds || 0) + watchDurationSeconds,
      isEligible: eligibleForCreatorReward
    });

    this.saveState();

    return {
      eligibleForCreatorReward,
      eligibleForViewerReward,
      viewerPointsAwarded,
      creatorPointsAwarded
    };
  }

  // --- USER BALANCE COMPUTATION & LEDGER INTEGRITY ---

  public getUserRewardSummary(userId: string): {
    totalPoints: number;
    availablePoints: number;
    pendingPoints: number;
    lifetimeEarned: number;
    todayEarned: number;
    videoEarningsPoints: number;
    watchEarningsPoints: number;
    bonusEarningsPoints: number;
    withdrawnPoints: number;
    usdValue: number;
    minWithdrawalPoints: number;
    canWithdraw: boolean;
  } {
    const userEvents = this.events.filter(e => e.userId === userId || (userId === 'CURRENT_USER' && (e.userId === 'CURRENT_USER' || e.userId === 'CURRENT_WALLET')));
    const userWithdrawals = this.withdrawals.filter(w => w.userId === userId || (userId === 'CURRENT_USER' && (w.userId === 'CURRENT_USER' || w.userId === 'CURRENT_WALLET')));

    let lifetimeEarned = 0;
    let pendingPoints = 0;
    let availablePoints = 0;
    let videoEarningsPoints = 0;
    let watchEarningsPoints = 0;
    let bonusEarningsPoints = 0;

    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const startOfTodayMs = startOfToday.getTime();
    let todayEarned = 0;

    for (const evt of userEvents) {
      if (evt.status === 'REVERSED') continue;

      if (evt.type === 'WITHDRAWAL_DEDUCTION') {
        availablePoints -= evt.points;
      } else {
        if (evt.status === 'AVAILABLE' || evt.status === 'VERIFIED') {
          availablePoints += evt.points;
          lifetimeEarned += evt.points;
        } else if (evt.status === 'PENDING') {
          pendingPoints += evt.points;
        }

        if (evt.createdAt >= startOfTodayMs) {
          todayEarned += evt.points;
        }

        if (evt.type === 'CREATOR_ELIGIBLE_VIEW' || evt.type === 'CREATOR_ENGAGEMENT_BONUS') {
          videoEarningsPoints += evt.points;
        } else if (evt.type === 'VIEWER_WATCH_REWARD') {
          watchEarningsPoints += evt.points;
        } else {
          bonusEarningsPoints += evt.points;
        }
      }
    }

    // Sum withdrawn
    const withdrawnPoints = userWithdrawals
      .filter(w => w.status === 'COMPLETED' || w.status === 'PROCESSING' || w.status === 'PENDING')
      .reduce((sum, w) => sum + w.requestedPoints, 0);

    // Prevent any artificial negative balance
    availablePoints = Math.max(0, availablePoints);
    const totalPoints = availablePoints + pendingPoints;
    const usdValue = Number((availablePoints / this.adminConfig.pointsPerUsd).toFixed(2));
    const canWithdraw = availablePoints >= this.adminConfig.minWithdrawalPoints;

    return {
      totalPoints,
      availablePoints,
      pendingPoints,
      lifetimeEarned,
      todayEarned,
      videoEarningsPoints,
      watchEarningsPoints,
      bonusEarningsPoints,
      withdrawnPoints,
      usdValue,
      minWithdrawalPoints: this.adminConfig.minWithdrawalPoints,
      canWithdraw
    };
  }

  // --- WITHDRAWAL EXECUTION FLOW ---

  /**
   * Initiates a withdrawal request following strict platform ledger rules:
   * 100 Points = $1 USD, Min 500 Points ($5 USD).
   */
  public requestWithdrawal(params: {
    userId: string;
    userName: string;
    walletAddress: string;
    network: SupportedWithdrawalNetwork;
    points: number;
  }): {
    success: boolean;
    withdrawal?: BlueTixaWithdrawal;
    error?: string;
  } {
    const { userId, userName, walletAddress, network, points } = params;

    // 1. Strict threshold check (Requirement 7)
    if (points < this.adminConfig.minWithdrawalPoints) {
      return {
        success: false,
        error: `Minimum withdrawal requirement is ${this.adminConfig.minWithdrawalPoints} Points ($${(this.adminConfig.minWithdrawalPoints / this.adminConfig.pointsPerUsd).toFixed(2)} USD).`
      };
    }

    // 2. Verified available balance check (Requirement 13)
    const summary = this.getUserRewardSummary(userId);
    if (summary.availablePoints < points) {
      return {
        success: false,
        error: `Insufficient verified points. Available: ${summary.availablePoints.toLocaleString()} Points ($${summary.usdValue.toFixed(2)} USD).`
      };
    }

    // 3. Validate wallet address
    if (!walletAddress || walletAddress.trim().length < 10) {
      return {
        success: false,
        error: 'Invalid public wallet address. Please provide a valid receiving address.'
      };
    }

    const usdAmount = Number((points / this.adminConfig.pointsPerUsd).toFixed(2));
    const networkConfig = this.adminConfig.supportedNetworks.find(n => n.id === network);
    const asset = networkConfig ? networkConfig.asset : 'USDT';
    const feeUsd = networkConfig ? networkConfig.feeUsd : 0;

    // For TIXA Native, calculate live TIXA coins using current market price
    let assetPayoutAmount = usdAmount;
    if (asset === 'TIXA') {
      const liveTixaPrice = 990000.00;
      assetPayoutAmount = Number((usdAmount / liveTixaPrice).toFixed(6));
    }

    const withdrawalId = `bt_wd_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const txHash = `0x${Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`;

    // 4. Create Withdrawal Record
    const withdrawal: BlueTixaWithdrawal = {
      id: withdrawalId,
      userId,
      userName: userName || 'TIXA Creator',
      walletAddress: walletAddress.trim(),
      network,
      asset,
      requestedPoints: points,
      usdAmount,
      assetPayoutAmount,
      feeUsd,
      status: 'PROCESSING',
      txHash,
      requestedAt: Date.now(),
      processedAt: Date.now() + 1200,
      adminNotes: 'Automated cryptographic batch dispatch'
    };

    // 5. Atomic Ledger Deduction Event
    const deductionEvent: BlueTixaRewardLedgerEvent = {
      id: `bt_evt_wd_${Date.now()}`,
      userId,
      type: 'WITHDRAWAL_DEDUCTION',
      points: points,
      usdValue: usdAmount,
      status: 'SETTLED',
      description: `Withdrawal #${withdrawalId} to ${network} (${walletAddress.slice(0, 8)}...${walletAddress.slice(-6)})`,
      fingerprint: `fp_wd_${txHash.slice(0, 16)}`,
      fraudScore: 0,
      createdAt: Date.now(),
      verifiedAt: Date.now()
    };

    this.events.push(deductionEvent);
    this.withdrawals.unshift(withdrawal);

    // If destination is on-chain TIXA Mainnet and matches a local account, credit directly!
    if (network === 'TIXA_MAINNET' || walletAddress.startsWith('TXA')) {
      try {
        const acc = blockchainEngine.getOrCreateAccount(walletAddress);
        if (asset === 'TIXA') {
          acc.balance += assetPayoutAmount;
        }
      } catch (err) {
        console.warn('Failed to auto-credit blockchain account', err);
      }
    }

    // Record system audit log
    auditEngine.logAction({
      userId: userId,
      action: 'BLUE_TIXA_WITHDRAWAL_SUBMITTED',
      details: `Withdrew ${points} points ($${usdAmount} USD) to ${network} wallet ${walletAddress}. TxHash: ${txHash}`,
      ip: '127.0.0.1',
      severity: 'MEDIUM'
    });

    // Auto mark as completed after 2.5 seconds to simulate real blockchain confirmation
    setTimeout(() => {
      withdrawal.status = 'COMPLETED';
      this.saveState();
    }, 2500);

    this.saveState();
    return {
      success: true,
      withdrawal
    };
  }

  // --- ADMIN MANAGEMENT & AUDITING (RBAC PROTECTED) ---

  public adminUpdateWithdrawalStatus(
    withdrawalId: string, 
    status: WithdrawalStatus, 
    adminUser: string,
    notes?: string
  ): boolean {
    const wd = this.withdrawals.find(w => w.id === withdrawalId);
    if (!wd) return false;

    const oldStatus = wd.status;
    wd.status = status;
    wd.processedAt = Date.now();
    if (notes) wd.adminNotes = notes;

    // If rejected, refund points to user
    if (status === 'REJECTED' && oldStatus !== 'REJECTED') {
      const refundEvent: BlueTixaRewardLedgerEvent = {
        id: `bt_evt_refund_${Date.now()}`,
        userId: wd.userId,
        type: 'REFERRAL_BONUS',
        points: wd.requestedPoints,
        usdValue: wd.usdAmount,
        status: 'AVAILABLE',
        description: `Refund for Rejected Withdrawal #${withdrawalId}: ${notes || 'Administrative Reversal'}`,
        fingerprint: `fp_refund_${withdrawalId}`,
        fraudScore: 0,
        createdAt: Date.now(),
        verifiedAt: Date.now()
      };
      this.events.push(refundEvent);
    }

    auditEngine.logAction({
      userId: adminUser,
      action: 'BLUE_TIXA_WITHDRAWAL_MODERATED',
      details: `Admin ${adminUser} updated withdrawal #${withdrawalId} from ${oldStatus} to ${status}. Notes: ${notes || 'None'}`,
      ip: '127.0.0.1',
      severity: 'HIGH'
    });

    this.saveState();
    return true;
  }

  public adminReverseRewardEvent(eventId: string, adminUser: string, reason: string): boolean {
    const evt = this.events.find(e => e.id === eventId);
    if (!evt || evt.status === 'REVERSED') return false;

    evt.status = 'REVERSED';
    
    // Deduct the points via reversal event
    const reversalEvent: BlueTixaRewardLedgerEvent = {
      id: `bt_evt_rev_${Date.now()}`,
      userId: evt.userId,
      type: 'REWARD_REVERSAL',
      points: evt.points,
      usdValue: evt.usdValue,
      status: 'SETTLED',
      description: `Reversal of Event #${eventId} by Admin ${adminUser}: ${reason}`,
      fingerprint: `fp_reversal_${eventId}`,
      fraudScore: 100,
      createdAt: Date.now(),
      verifiedAt: Date.now()
    };
    this.events.push(reversalEvent);

    auditEngine.logAction({
      userId: adminUser,
      action: 'BLUE_TIXA_REWARD_REVERSED',
      details: `Admin ${adminUser} reversed ${evt.points} points for user ${evt.userId}. Reason: ${reason}`,
      ip: '127.0.0.1',
      severity: 'HIGH'
    });

    this.saveState();
    return true;
  }

  public adminUpdateConfig(newConfig: Partial<BlueTixaAdminConfig>, adminUser: string) {
    this.adminConfig = { ...this.adminConfig, ...newConfig };
    auditEngine.logAction({
      userId: adminUser,
      action: 'BLUE_TIXA_CONFIG_UPDATED',
      details: `Admin ${adminUser} updated Blue Tixa reward config. Min Withdrawal: ${this.adminConfig.minWithdrawalPoints} pts. Points/USD: ${this.adminConfig.pointsPerUsd}.`,
      ip: '127.0.0.1',
      severity: 'HIGH'
    });
    this.saveState();
  }

  public getAdminConfig(): BlueTixaAdminConfig {
    return { ...this.adminConfig };
  }

  public getAllWithdrawals(): BlueTixaWithdrawal[] {
    return [...this.withdrawals];
  }

  public getAllLedgerEvents(): BlueTixaRewardLedgerEvent[] {
    return [...this.events];
  }

  public getSuspiciousAccounts(): string[] {
    return Array.from(this.suspiciousAccounts);
  }

  public toggleSuspiciousAccount(userId: string, adminUser: string): boolean {
    if (this.suspiciousAccounts.has(userId)) {
      this.suspiciousAccounts.delete(userId);
    } else {
      this.suspiciousAccounts.add(userId);
    }
    auditEngine.logAction({
      userId: adminUser,
      action: 'BLUE_TIXA_ACCOUNT_FLAGGED',
      details: `Admin ${adminUser} toggled fraud status for user ${userId}. Currently Flagged: ${this.suspiciousAccounts.has(userId)}`,
      ip: '127.0.0.1',
      severity: 'HIGH'
    });
    this.notify();
    return this.suspiciousAccounts.has(userId);
  }
}

export const blueTixaRewardEngine = new BlueTixaRewardEngine();
