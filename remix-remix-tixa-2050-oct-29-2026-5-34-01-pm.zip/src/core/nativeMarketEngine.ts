import { forexTradingEngine } from './forexTradingEngine';
import { ledgerEngine } from './ledgerEngine';

export interface NativeCoin {
  symbol: string;
  name: string;
  startingPrice: number;
  currentPrice: number;
  high24h: number;
  low24h: number;
  change24h: number;
  pulseCount: number;
  lastUpdate: number;
  status: 'LIVE' | 'PAUSED' | 'DISABLED';
  history: { timestamp: number; price: number; high: number; low: number; volume: number }[];
}

export interface MarketStateResponse {
  success: boolean;
  tixaCoin: NativeCoin;
  coins: Record<string, NativeCoin>;
  marketActive: boolean;
  volatilityMultiplier: number;
  totalPulses: number;
  lastPulseTime: number;
  pulsesPerSecond?: number;
  monthlyBasePrice?: number;
  monthlyGrowthUsd?: number;
  fluctuationRangeUsd?: number;
}

/**
 * TIXA / BTX Unified Price Engine:
 * Shares exact same live USD price source across Markets, Dashboard, Trading, Wallet, and FIXDIPOZ.
 */
export function getBlueCoinMonthlyBasePrice(targetDate: Date = new Date()): number {
  return forexTradingEngine.getPair('TIXA_USDT')?.currentPrice || ledgerEngine.getTixaUsdtPrice() || 990000.00;
}

export class NativeMarketEngine {
  private static instance: NativeMarketEngine;
  private tixaCoin: NativeCoin = {
    symbol: 'TIXA',
    name: 'TIXA NATIVE COIN',
    startingPrice: forexTradingEngine.getPair('TIXA_USDT')?.currentPrice || ledgerEngine.getTixaUsdtPrice() || 990000.00,
    currentPrice: forexTradingEngine.getPair('TIXA_USDT')?.currentPrice || ledgerEngine.getTixaUsdtPrice() || 990000.00,
    high24h: forexTradingEngine.getPair('TIXA_USDT')?.high24h || 1045000.00,
    low24h: forexTradingEngine.getPair('TIXA_USDT')?.low24h || 942000.00,
    change24h: forexTradingEngine.getPair('TIXA_USDT')?.change24h || 12.45,
    pulseCount: 0,
    lastUpdate: Date.now(),
    status: 'LIVE',
    history: []
  };
  private coins: Record<string, NativeCoin> = {};
  private marketActive: boolean = true;
  private volatilityMultiplier: number = 1.0;
  private totalPulses: number = 0;
  private lastPulseTime: number = Date.now();
  private listeners: Set<() => void> = new Set();
  private pollInterval: any = null;
  private highFreqInterval: any = null;

  /**
   * BTX Coin Selector:
   * BTX Coin's live price, 24-hour High, and 24-hour Low strictly mirror TIXA Coin.
   * (Requirements 1-4, 6, 8)
   */
  public getBtxCoin(): NativeCoin {
    return {
      symbol: 'BTX',
      name: 'BTX NATIVE BASE',
      startingPrice: this.tixaCoin.startingPrice,
      currentPrice: this.tixaCoin.currentPrice,
      high24h: this.tixaCoin.high24h,
      low24h: this.tixaCoin.low24h,
      change24h: this.tixaCoin.change24h,
      pulseCount: this.tixaCoin.pulseCount,
      lastUpdate: this.tixaCoin.lastUpdate,
      status: this.tixaCoin.status,
      history: this.tixaCoin.history
    };
  }

  private syncBtxCoin(): void {
    this.coins['BTX'] = this.getBtxCoin();
  }

  private constructor() {
    this.initEngines();
    this.syncBtxCoin();
    forexTradingEngine.subscribe(() => {
      const pair = forexTradingEngine.getPair('TIXA_USDT');
      const livePrice = pair?.currentPrice || ledgerEngine.getTixaUsdtPrice() || 990000.00;
      this.tixaCoin.startingPrice = pair ? pair.currentPrice : livePrice;
      this.tixaCoin.currentPrice = livePrice;
      if (pair) {
        this.tixaCoin.high24h = pair.high24h;
        this.tixaCoin.low24h = pair.low24h;
        this.tixaCoin.change24h = pair.change24h;
      } else {
        this.tixaCoin.high24h = Math.max(this.tixaCoin.high24h, livePrice);
        this.tixaCoin.low24h = Math.min(this.tixaCoin.low24h, livePrice);
      }
      this.tixaCoin.lastUpdate = Date.now();
      this.syncBtxCoin();
      this.notifyListeners();
    });
  }

  public static getInstance(): NativeMarketEngine {
    if (!NativeMarketEngine.instance) {
      NativeMarketEngine.instance = new NativeMarketEngine();
    }
    return NativeMarketEngine.instance;
  }

  private initEngines() {
    // 1. Initial server fetch
    this.fetchMarketState();

    if (typeof window !== 'undefined') {
      // 2. High frequency interval loop synchronizing with live shared price
      this.highFreqInterval = setInterval(() => {
        if (!this.marketActive) return;

        this.totalPulses++;
        const pair = forexTradingEngine.getPair('TIXA_USDT');
        const livePrice = pair?.currentPrice || ledgerEngine.getTixaUsdtPrice() || 990000.00;
        this.tixaCoin.startingPrice = pair ? pair.currentPrice : livePrice;
        this.tixaCoin.currentPrice = livePrice;
        if (pair) {
          this.tixaCoin.high24h = pair.high24h;
          this.tixaCoin.low24h = pair.low24h;
          this.tixaCoin.change24h = pair.change24h;
        } else {
          this.tixaCoin.high24h = Math.max(this.tixaCoin.high24h, livePrice);
          this.tixaCoin.low24h = Math.min(this.tixaCoin.low24h, livePrice);
        }
        this.tixaCoin.pulseCount++;
        this.tixaCoin.lastUpdate = Date.now();

        this.syncBtxCoin();
        this.notifyListeners();
      }, Math.round(30000 / 39));

      // 3. Periodic synchronization with server state (every 4000ms)
      this.pollInterval = setInterval(() => {
        this.fetchMarketState();
      }, 4000);
    }
  }

  public getMonthlyBasePrice(): number {
    return getBlueCoinMonthlyBasePrice();
  }

  public getFluctuationRange(): number {
    return 0.05;
  }

  public getPulsesPerSecond(): number {
    return 39;
  }

  public async fetchMarketState(): Promise<MarketStateResponse | null> {
    try {
      const res = await fetch('/api/market/state');
      if (!res.ok) return null;
      const data: MarketStateResponse = await res.json();
      if (data && data.success) {
        if (data.tixaCoin) {
          const pair = forexTradingEngine.getPair('TIXA_USDT');
          if (pair) {
            this.tixaCoin.currentPrice = pair.currentPrice;
            this.tixaCoin.high24h = pair.high24h;
            this.tixaCoin.low24h = pair.low24h;
            this.tixaCoin.change24h = pair.change24h;
          } else if (data.tixaCoin.currentPrice > 100) {
            this.tixaCoin.currentPrice = data.tixaCoin.currentPrice;
            this.tixaCoin.high24h = data.tixaCoin.high24h;
            this.tixaCoin.low24h = data.tixaCoin.low24h;
            this.tixaCoin.change24h = data.tixaCoin.change24h;
          }
          if (data.tixaCoin.history && data.tixaCoin.history.length > 0) {
            this.tixaCoin.history = data.tixaCoin.history;
          }
        }
        if (data.coins) {
          this.coins = { ...this.coins, ...data.coins };
        }
        this.syncBtxCoin();
        this.marketActive = data.marketActive ?? this.marketActive;
        this.volatilityMultiplier = data.volatilityMultiplier ?? this.volatilityMultiplier;
        this.totalPulses = data.totalPulses ?? this.totalPulses;
        this.lastPulseTime = data.lastPulseTime ?? this.lastPulseTime;
        this.notifyListeners();
        return data;
      }
    } catch (err) {
      // Silently fall back to local computation without throwing or logging error
    }
    return null;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners() {
    this.listeners.forEach(fn => {
      try {
        fn();
      } catch (e) {
        console.error(e);
      }
    });
  }

  public getTixaCoin(): NativeCoin {
    return this.tixaCoin;
  }

  public getCoins(): Record<string, NativeCoin> {
    this.syncBtxCoin();
    return this.coins;
  }

  public getCoinList(): NativeCoin[] {
    this.syncBtxCoin();
    return [this.tixaCoin, ...Object.values(this.coins).filter(c => c.symbol !== 'TIXA')];
  }

  public getCoin(symbol: string): NativeCoin | undefined {
    const clean = String(symbol || '').toUpperCase().trim();
    if (clean === 'TIXA') return this.tixaCoin;
    if (clean === 'BTX' || clean.includes('BTX')) return this.getBtxCoin();
    const found = this.coins[clean];
    if (found && (found.symbol === 'BTX' || found.symbol === 'TIXA')) {
      return found.symbol === 'BTX' ? this.getBtxCoin() : this.tixaCoin;
    }
    return found;
  }

  public isMarketActive(): boolean {
    return this.marketActive;
  }

  public getTotalPulses(): number {
    return this.totalPulses;
  }

  public async fetchHistory(symbol: string): Promise<{ timestamp: number; price: number; high: number; low: number; volume: number }[]> {
    try {
      const res = await fetch(`/api/market/history/${symbol}`);
      if (!res.ok) return [];
      const data = await res.json();
      if (data && data.success) {
        return data.history || [];
      }
    } catch (err) {
      console.error(err);
    }
    return [];
  }

  public async adminControl(action: string, payload?: { symbol?: string; startingPrice?: number; volatility?: number }) {
    try {
      const res = await fetch('/api/market/admin/control', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, ...payload })
      });
      const data = await res.json();
      if (data && data.success) {
        this.marketActive = data.marketActive;
        this.volatilityMultiplier = data.volatilityMultiplier;
        this.tixaCoin = data.tixaCoin;
        this.coins = data.coins;
        this.notifyListeners();
      }
      return data;
    } catch (err) {
      console.error(err);
      return { success: false, error: String(err) };
    }
  }
}

export const nativeMarketEngine = NativeMarketEngine.getInstance();
