import { 
  PaymentMethodConfig, 
  PaymentAddressAuditLog, 
  SupportedNetwork, 
  AddressValidationResult, 
  AdminPermission,
  MfsModeConfig
} from '../types/paymentConfig';
import { AdminUser, AdminRole } from '../types/auth';
import { auditEngine } from './auditEngine';
import { sha256 } from './crypto';

const STORAGE_PAYMENT_METHODS_KEY = 'tixa_payment_methods_config_v1';
const STORAGE_PAYMENT_AUDIT_KEY = 'tixa_payment_address_audit_v1';

// Initial verified payment methods with blank addresses
const INITIAL_PAYMENT_METHODS: PaymentMethodConfig[] = [
  {
    id: 'usdt_trc20',
    name: 'USDT',
    network: 'TRC20',
    networkDisplayName: 'Tron (TRC20)',
    currency: 'USDT',
    category: 'STABLECOIN',
    receivingAddress: 'TMvn8DXTaE59yXJWbhKoTPokCaYotkP893',
    isActive: true,
    minDepositUsd: 10.00,
    depositFeePercent: 0.0,
    networkWarning: '⚠️ Send ONLY Tether USD (USDT) on the Tron TRC20 network. Sending any other token or using another network will cause permanent loss of funds.',
    depositInstructions: 'Transfer USDT to the official TRC20 receiving address. Paste your TxID below after sending.',
    requiresTxHash: true,
    iconType: 'usdt',
    brandColor: '#26A17B',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_super_01',
      adminName: 'Dr. Evelyn Vance',
      adminEmail: 'superadmin@tixa.network',
      adminRole: 'SUPER_ADMIN'
    }
  },
  {
    id: 'usdt_erc20',
    name: 'USDT',
    network: 'ERC20',
    networkDisplayName: 'Ethereum (ERC20)',
    currency: 'USDT',
    category: 'STABLECOIN',
    receivingAddress: '0xd7f7e11256e0a21a7d68ee8812d847a417c4e619',
    isActive: true,
    minDepositUsd: 25.00,
    depositFeePercent: 0.0,
    networkWarning: '⚠️ Send ONLY USDT on Ethereum (ERC20). Ensure sufficient ETH gas in your wallet before sending.',
    depositInstructions: 'Send ERC20 USDT to the Treasury Vault address. Settlements are confirmed automatically in 6 Ethereum blocks.',
    requiresTxHash: true,
    iconType: 'usdt',
    brandColor: '#627EEA',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    }
  },
  {
    id: 'usdt_bep20',
    name: 'USDT',
    network: 'BEP20',
    networkDisplayName: 'BNB Smart Chain (BEP20)',
    currency: 'USDT',
    category: 'STABLECOIN',
    receivingAddress: '0xd7f7e11256e0a21a7d68ee8812d847a417c4e619',
    isActive: true,
    minDepositUsd: 10.00,
    depositFeePercent: 0.0,
    networkWarning: '⚠️ Send ONLY BEP20 (BSC) USDT. Do NOT send Binance-Peg tokens or native BNB to this contract.',
    depositInstructions: 'Fast & low fee Binance Smart Chain deposit. Usually settles within 15 seconds (15 BSC confirmations).',
    requiresTxHash: true,
    iconType: 'usdt',
    brandColor: '#F3BA2F',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    }
  },
  {
    id: 'tixa_native',
    name: 'TIXA',
    network: 'TIXA_2050_NATIVE',
    networkDisplayName: 'TIXAPAY Quantum Mainnet',
    currency: 'TIXA',
    category: 'LAYER1_CRYPTO',
    receivingAddress: '',
    isActive: true,
    minDepositUsd: 5.00,
    depositFeePercent: 0.0,
    networkWarning: '⚡ Direct Native TIXA Mainnet transfer with sub-second quantum consensus. Single Bech32 address verification.',
    depositInstructions: 'Send native TIXA coins from any TIXA quantum wallet or validator node directly to the Protocol Treasury.',
    requiresTxHash: true,
    iconType: 'tixa',
    brandColor: '#06B6D4',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_super_01',
      adminName: 'Dr. Evelyn Vance',
      adminEmail: 'superadmin@tixa.network',
      adminRole: 'SUPER_ADMIN'
    }
  },
  {
    id: 'btc_mainnet',
    name: 'NISI Token (NISI)',
    network: 'NISI_NET',
    networkDisplayName: 'NISI Mainnet Network',
    currency: 'NISI',
    category: 'LAYER1_CRYPTO',
    receivingAddress: '',
    isActive: true,
    minDepositUsd: 50.00,
    depositFeePercent: 0.0,
    networkWarning: '⚠️ Send ONLY NISI tokens via the NISI mainnet network. Secure node transfer supported.',
    depositInstructions: 'Send NISI to the address. Credited after 2 blockchain network confirmations (~20 seconds).',
    requiresTxHash: true,
    iconType: 'btc',
    brandColor: '#F7931A',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_super_01',
      adminName: 'Dr. Evelyn Vance',
      adminEmail: 'superadmin@tixa.network',
      adminRole: 'SUPER_ADMIN'
    }
  },
  {
    id: 'eth_mainnet',
    name: 'SARA ADDRESS',
    network: 'SARA_NET',
    networkDisplayName: 'SARA Network (ERC20)',
    currency: 'SARA',
    category: 'LAYER1_CRYPTO',
    receivingAddress: '',
    isActive: true,
    minDepositUsd: 25.00,
    depositFeePercent: 0.0,
    networkWarning: '⚠️ Send ONLY SARA tokens or ERC20. Standard transaction hash required.',
    depositInstructions: 'Direct on-chain SARA deposit. Funds are credited automatically upon 12 block confirmations.',
    requiresTxHash: true,
    iconType: 'eth',
    brandColor: '#627EEA',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    }
  },
  {
    id: 'sol_mainnet',
    name: 'MUN ADDRESS',
    network: 'MUN_NET',
    networkDisplayName: 'MUN Crypto (SOL)',
    currency: 'MUN',
    category: 'LAYER1_CRYPTO',
    receivingAddress: '',
    isActive: true,
    minDepositUsd: 10.00,
    depositFeePercent: 0.0,
    networkWarning: '⚡ High-speed MUN network deposit. Send native MUN.',
    depositInstructions: 'Transfer MUN to the protocol vault. Confirmed instantly (32 slots ~5 seconds).',
    requiresTxHash: true,
    iconType: 'sol',
    brandColor: '#9945FF',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    }
  },
  {
    id: 'bnb_mainnet',
    name: 'BNB ADDRESS',
    network: 'BEP20',
    networkDisplayName: 'BNB Smart Chain (BEP20)',
    currency: 'BNB',
    category: 'LAYER1_CRYPTO',
    receivingAddress: '',
    isActive: true,
    minDepositUsd: 10.00,
    depositFeePercent: 0.0,
    networkWarning: '⚠️ Send ONLY BNB on BNB Smart Chain (BEP20).',
    depositInstructions: 'Send Native BNB (BEP20) to the address below. Settled within 15 seconds.',
    requiresTxHash: true,
    iconType: 'bnb',
    brandColor: '#F3BA2F',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    }
  },
  {
    id: 'usdt_polygon',
    name: 'USDT (Polygon)',
    network: 'POLYGON',
    networkDisplayName: 'Polygon PoS (POL)',
    currency: 'USDT',
    category: 'STABLECOIN',
    receivingAddress: '0xd7f7e11256e0a21a7d68ee8812d847a417c4e619',
    isActive: true,
    minDepositUsd: 5.00,
    depositFeePercent: 0.0,
    networkWarning: '⚠️ Send ONLY USDT on Polygon PoS network. Ultra-low gas fees. (Polygon USDT token contract verified).',
    depositInstructions: 'Send Polygon PoS USDT to the treasury contract. 128 block confirmations.',
    requiresTxHash: true,
    iconType: 'usdt',
    brandColor: '#8247E5',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    }
  },
  {
    id: 'binance_pay_direct',
    name: 'Binance Pay',
    network: 'BINANCE_DIRECT',
    networkDisplayName: 'Binance Pay Direct',
    currency: 'USDT',
    category: 'EXCHANGE_PAY',
    receivingAddress: '',
    isActive: true,
    minDepositUsd: 10.00,
    depositFeePercent: 0.0,
    networkWarning: '🌐 Official Verified Merchant Pay ID. 0% transfer fee between Binance users.',
    depositInstructions: 'Open Binance App → Pay → Send to Merchant Pay ID. Enter payment order reference.',
    requiresTxHash: true,
    iconType: 'binance',
    brandColor: '#F0B90B',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_super_01',
      adminName: 'Dr. Evelyn Vance',
      adminEmail: 'superadmin@tixa.network',
      adminRole: 'SUPER_ADMIN'
    },
    extraFields: {}
  },
  {
    id: 'bkash_merchant_bd',
    name: 'bKash Merchant',
    network: 'BANGLADESH_MFS',
    networkDisplayName: 'bKash (Payment / Send Money / Cash Out)',
    currency: 'BDT',
    category: 'MFS_BANGLADESH',
    receivingAddress: '',
    mfsModes: {
      paymentNumber: '',
      paymentCounter: '1',
      paymentInstructions: 'Open bKash App → Select Make Payment → Enter Merchant Number → Enter Amount → Confirm with PIN → Enter TrxID below.',
      paymentEnabled: true,
      sendMoneyNumber: '',
      sendMoneyInstructions: 'Open bKash App or dial *247# → Select Send Money → Enter Personal Number → Enter Amount & Reference → Enter TrxID below.',
      sendMoneyEnabled: true,
      cashOutNumber: '',
      cashOutInstructions: 'Open bKash App or dial *247# → Select Cash Out → Enter Agent Number → Enter Amount → Complete Cash Out → Enter TrxID below.',
      cashOutEnabled: true
    },
    isActive: true,
    minDepositUsd: 5.00,
    depositFeePercent: 0.0,
    networkWarning: 'Select bKash Payment (Merchant), Send Money (Personal) or Cash Out (Agent) and transfer funds to the designated number.',
    depositInstructions: 'Select payment mode, transfer funds to the specified number, and submit Transaction ID (TrxID) below.',
    requiresTxHash: true,
    iconType: 'bkash',
    brandColor: '#E2136E',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    },
    extraFields: {}
  },
  {
    id: 'nagad_corporate_bd',
    name: 'Nagad Send Money',
    network: 'BANGLADESH_MFS',
    networkDisplayName: 'Nagad Send Money (16-Digit Virtual Card)',
    currency: 'BDT',
    category: 'MFS_BANGLADESH',
    receivingAddress: '9856 0000 7672 8175',
    mfsModes: {
      paymentNumber: '',
      paymentCounter: '1',
      paymentInstructions: 'Open Nagad App → Select Merchant Pay → Enter Merchant Number → Enter Amount with PIN → Submit TrxID below.',
      paymentEnabled: false,
      sendMoneyNumber: '9856 0000 7672 8175',
      sendMoneyInstructions: 'ঘোষণা: ১১ সংখ্যার ফোন নম্বরের পরিবর্তে ১৬ সংখ্যার ভার্চুয়াল কার্ড নম্বরে Send Money করুন। Open Nagad App → Send Money → Enter Virtual Card Number 9856 0000 7672 8175 → Enter Amount → Submit TrxID below.',
      sendMoneyEnabled: true,
      cashOutNumber: '',
      cashOutInstructions: '',
      cashOutEnabled: false
    },
    isActive: true,
    minDepositUsd: 5.00,
    depositFeePercent: 0.0,
    networkWarning: 'ঘোষণা: ১১ সংখ্যার ফোন নম্বরের পরিবর্তে ১৬ সংখ্যার ভার্চুয়াল কার্ড নম্বরে Send Money করুন।',
    depositInstructions: 'Send money to Nagad 16-digit virtual card number 9856 0000 7672 8175 and submit Transaction ID (TrxID).',
    requiresTxHash: true,
    iconType: 'nagad',
    brandColor: '#F7931E',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    },
    extraFields: {}
  },
  {
    id: 'dbbl_rocket_bd',
    name: 'DBBL Rocket',
    network: 'BANGLADESH_MFS',
    networkDisplayName: 'DBBL Rocket (Payment / Send Money / Cash Out)',
    currency: 'BDT',
    category: 'MFS_BANGLADESH',
    receivingAddress: '',
    mfsModes: {
      paymentNumber: '',
      paymentCounter: '1',
      paymentInstructions: 'Open Rocket App or dial *322# → Select Merchant Pay → Enter Merchant Number → Enter Amount → Submit TrxID below.',
      paymentEnabled: true,
      sendMoneyNumber: '',
      sendMoneyInstructions: 'Open Rocket App or dial *322# → Select Send Money → Enter Personal Number → Enter Amount → Submit TrxID below.',
      sendMoneyEnabled: true,
      cashOutNumber: '',
      cashOutInstructions: 'Open Rocket App or dial *322# → Select Cash Out → Enter Agent Number → Complete Cash Out → Submit TrxID below.',
      cashOutEnabled: true
    },
    isActive: true,
    minDepositUsd: 5.00,
    depositFeePercent: 0.0,
    networkWarning: 'Dutch-Bangla Bank Rocket Merchant, Send Money, or Agent Cash Out account.',
    depositInstructions: 'Select mode, send funds to the correct Rocket number, and submit TrxID.',
    requiresTxHash: true,
    iconType: 'rocket',
    brandColor: '#8C3494',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_fin_02',
      adminName: 'Marcus Sterling',
      adminEmail: 'finance@tixa.network',
      adminRole: 'FINANCE_ADMIN'
    }
  },
  {
    id: 'city_bank_wire',
    name: 'City Bank Escrow',
    network: 'BANK_WIRE',
    networkDisplayName: 'City Bank Ltd.',
    currency: 'BDT',
    category: 'FIAT_BANK',
    receivingAddress: '',
    isActive: true,
    minDepositUsd: 100.00,
    depositFeePercent: 0.0,
    networkWarning: '🏦 Corporate Wire Settlement Escrow. Include your User ID in the bank transfer reference.',
    depositInstructions: 'City Bank Ltd. / Citytouch NPSB Transfer → Enter Account Details → Submit Bank Ref.',
    requiresTxHash: true,
    iconType: 'citybank',
    brandColor: '#ED1C24',
    lastUpdatedAt: Date.now(),
    lastUpdatedByAdmin: {
      adminId: 'admin_super_01',
      adminName: 'Dr. Evelyn Vance',
      adminEmail: 'superadmin@tixa.network',
      adminRole: 'SUPER_ADMIN'
    },
    extraFields: {}
  }
];

export class PaymentConfigEngine {
  private static instance: PaymentConfigEngine;

  private paymentMethods: Record<string, PaymentMethodConfig> = {};
  private auditLogs: PaymentAddressAuditLog[] = [];
  private listeners: Array<() => void> = [];

  private constructor() {
    this.loadStorage();
  }

  public static getInstance(): PaymentConfigEngine {
    if (!PaymentConfigEngine.instance) {
      PaymentConfigEngine.instance = new PaymentConfigEngine();
    }
    return PaymentConfigEngine.instance;
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach(cb => {
      try { cb(); } catch (err) { console.error('PaymentConfig listener error', err); }
    });
  }

  private loadStorage(): void {
    try {
      const storedMethods = localStorage.getItem(STORAGE_PAYMENT_METHODS_KEY);
      const storedAudits = localStorage.getItem(STORAGE_PAYMENT_AUDIT_KEY);
      const canonicalPermanentIds = ['usdt_trc20', 'usdt_erc20', 'usdt_bep20', 'usdt_polygon', 'nagad_corporate_bd'];

      if (storedMethods) {
        const parsed = JSON.parse(storedMethods) as Record<string, PaymentMethodConfig>;
        const cleaned: Record<string, PaymentMethodConfig> = {};
        INITIAL_PAYMENT_METHODS.forEach(m => {
          const existing = parsed[m.id];
          const isCanonical = canonicalPermanentIds.includes(m.id);
          cleaned[m.id] = {
            ...m,
            receivingAddress: isCanonical ? m.receivingAddress : (existing?.receivingAddress || m.receivingAddress),
            mfsModes: isCanonical ? m.mfsModes : (existing?.mfsModes || m.mfsModes),
            ...(existing ? { 
              isActive: existing.isActive, 
              minDepositUsd: existing.minDepositUsd
            } : {})
          };
        });
        this.paymentMethods = cleaned;
        this.saveMethods();
      } else {
        INITIAL_PAYMENT_METHODS.forEach(m => {
          this.paymentMethods[m.id] = { ...m };
        });
        this.saveMethods();
      }

      this.auditLogs = [];
      localStorage.removeItem(STORAGE_PAYMENT_AUDIT_KEY);
    } catch {
      INITIAL_PAYMENT_METHODS.forEach(m => {
        this.paymentMethods[m.id] = { ...m };
      });
      this.auditLogs = [];
      this.saveMethods();
    }
  }

  private saveMethods(): void {
    try {
      localStorage.setItem(STORAGE_PAYMENT_METHODS_KEY, JSON.stringify(this.paymentMethods));
    } catch (e) {
      console.error('Failed to save payment methods', e);
    }
  }

  private saveAudits(): void {
    try {
      localStorage.setItem(STORAGE_PAYMENT_AUDIT_KEY, JSON.stringify(this.auditLogs.slice(0, 500)));
    } catch (e) {
      console.error('Failed to save payment audits', e);
    }
  }

  // RBAC Permission Check
  public checkAdminPermission(admin: AdminUser | null, permission: AdminPermission): boolean {
    if (!admin) return false;
    
    switch (permission) {
      case 'payment_address.manage':
        // Super Admin & Finance Admin have full payment address management rights
        return admin.role === 'SUPER_ADMIN' || admin.role === 'FINANCE_ADMIN';
      case 'audit.view':
        // All admins can view audit trails
        return true;
      case 'treasury.mint':
        return admin.role === 'SUPER_ADMIN';
      default:
        return admin.role === 'SUPER_ADMIN';
    }
  }

  // Address Validation per Blockchain Network
  public validateAddress(network: SupportedNetwork, address: string): AddressValidationResult {
    const clean = address.trim();
    if (!clean) {
      // Empty string is permitted to allow clearing or keeping addresses blank
      return {
        isValid: true,
        network,
        formattedAddress: ''
      };
    }

    switch (network) {
      case 'TRC20': {
        // Tron addresses start with 'T', are 34 characters long, base58
        const trc20Regex = /^T[1-9A-HJ-NP-Za-km-z]{33}$/;
        if (!trc20Regex.test(clean)) {
          return {
            isValid: false,
            network,
            formattedAddress: clean,
            errorMessage: 'Invalid TRC20 address: Must start with "T" and be exactly 34 Base58 characters (e.g. TPa5R4t9JqU2Y9eF5KxL8wQe7m2sX8pZvD).'
          };
        }
        return { isValid: true, network, formattedAddress: clean };
      }

      case 'ERC20':
      case 'BEP20':
      case 'POLYGON':
      case 'ARBITRUM':
      case 'ETHEREUM': {
        // EVM hex address: 0x followed by 40 hex characters
        const evmRegex = /^0x[a-fA-F0-9]{40}$/;
        if (!evmRegex.test(clean)) {
          return {
            isValid: false,
            network,
            formattedAddress: clean,
            errorMessage: `Invalid ${network} EVM address: Must start with "0x" and contain 40 hexadecimal characters (e.g. 0x88e73FeC0982d61d19d2E30E89a19d08E6622050).`
          };
        }
        return { isValid: true, network, formattedAddress: clean };
      }

      case 'TIXA_2050_NATIVE': {
        // Bech32 format starting with tx1
        const tixaRegex = /^tx1[a-z0-9]{20,60}$/;
        if (!tixaRegex.test(clean.toLowerCase())) {
          return {
            isValid: false,
            network,
            formattedAddress: clean.toLowerCase(),
            errorMessage: 'Invalid TIXA address: Must be a lowercase Bech32 address starting with "tx1" (e.g. tx1tixadepositvaulttreasury2050master001).'
          };
        }
        return { isValid: true, network, formattedAddress: clean.toLowerCase() };
      }

      case 'BITCOIN': {
        // Bitcoin legacy (1), SegWit P2SH (3), Native SegWit (bc1q), Taproot (bc1p)
        const btcRegex = /^(1|3|bc1q|bc1p)[a-zA-HJ-NP-Z0-9]{25,62}$/;
        if (!btcRegex.test(clean)) {
          return {
            isValid: false,
            network,
            formattedAddress: clean,
            errorMessage: 'Invalid Bitcoin address: Must start with 1, 3, bc1q, or bc1p (e.g. bc1q98f73fec0982d61d19d2e30e89a19d08e6622050).'
          };
        }
        return { isValid: true, network, formattedAddress: clean };
      }

      case 'SOLANA': {
        // Solana base58 32-44 characters
        const solRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
        if (!solRegex.test(clean)) {
          return {
            isValid: false,
            network,
            formattedAddress: clean,
            errorMessage: 'Invalid Solana address: Must be 32–44 Base58 characters (e.g. Tixa79gWkP2p8x8Z1N4oKq6vYh3M5jR9tL4wQ2sU99aa).'
          };
        }
        return { isValid: true, network, formattedAddress: clean };
      }

      case 'BANGLADESH_MFS': {
        // Bangladeshi mobile / merchant format (11-14 digits)
        const mfsRegex = /^01[3-9]\d{8}(-?\d{1,3})?$/;
        if (!mfsRegex.test(clean.replace(/\s+/g, ''))) {
          return {
            isValid: false,
            network,
            formattedAddress: clean,
            errorMessage: 'Invalid MFS number: Must be a valid Bangladesh mobile or merchant number (e.g. 01888-205099 or 01888205099-4).'
          };
        }
        return { isValid: true, network, formattedAddress: clean.replace(/\s+/g, '') };
      }

      case 'BINANCE_DIRECT': {
        // Binance Pay ID / UID (numeric 6-12 digits)
        const binanceRegex = /^\d{6,12}$/;
        if (!binanceRegex.test(clean.replace(/\s+/g, ''))) {
          return {
            isValid: false,
            network,
            formattedAddress: clean.replace(/\s+/g, ''),
            errorMessage: 'Invalid Binance Pay ID: Must be 6–12 numeric digits (e.g. 889201948).'
          };
        }
        return { isValid: true, network, formattedAddress: clean.replace(/\s+/g, '') };
      }

      case 'BANK_WIRE': {
        if (clean.length < 5) {
          return {
            isValid: false,
            network,
            formattedAddress: clean,
            errorMessage: 'Invalid Bank Account: Must be at least 5 alphanumeric characters.'
          };
        }
        return { isValid: true, network, formattedAddress: clean };
      }

      default:
        return { isValid: true, network, formattedAddress: clean };
    }
  }

  // Query: Get All Payment Methods (Admin Dashboard)
  public getPaymentMethods(): PaymentMethodConfig[] {
    return Object.values(this.paymentMethods);
  }

  // Query: Get Active Payment Methods (Public App & Deposit Screens)
  public getActivePaymentMethods(): PaymentMethodConfig[] {
    return Object.values(this.paymentMethods).filter(m => m.isActive);
  }

  // Query: Get Single Method by ID
  public getPaymentMethodById(id: string): PaymentMethodConfig | null {
    return this.paymentMethods[id] || null;
  }

  // Query: Get Dedicated Crypto Boxes for SOL, ETH, BNB
  public getCryptoBoxes(): { 
    id: string; 
    coin: 'SOL' | 'ETH' | 'BNB'; 
    boxName: string; 
    networkDisplayName: string; 
    address: string; 
    brandColor: string; 
    minDepositUsd: number;
    networkWarning: string;
    depositInstructions: string;
    isActive: boolean;
  }[] {
    const sol = this.paymentMethods['sol_mainnet'] || { receivingAddress: '', isActive: true, minDepositUsd: 10 };
    const eth = this.paymentMethods['eth_mainnet'] || { receivingAddress: '', isActive: true, minDepositUsd: 25 };
    const bnb = this.paymentMethods['bnb_mainnet'] || { receivingAddress: '', isActive: true, minDepositUsd: 10 };

    return [
      {
        id: 'sol_mainnet',
        coin: 'SOL',
        boxName: 'SOL ADDRESS',
        networkDisplayName: 'Solana (SOL)',
        address: sol.receivingAddress || '',
        brandColor: '#9945FF',
        minDepositUsd: sol.minDepositUsd || 10,
        networkWarning: '⚡ High-speed Solana network deposit. Send native SOL.',
        depositInstructions: 'Transfer SOL to the protocol Solana vault. Confirmed instantly (32 slots ~5s).',
        isActive: sol.isActive ?? true
      },
      {
        id: 'eth_mainnet',
        coin: 'ETH',
        boxName: 'ETH ADDRESS',
        networkDisplayName: 'Ethereum (ETH ERC20)',
        address: eth.receivingAddress || '',
        brandColor: '#627EEA',
        minDepositUsd: eth.minDepositUsd || 25,
        networkWarning: '⚠️ Send ONLY Native Ether (ETH) or ERC20. Standard transaction hash required.',
        depositInstructions: 'Direct on-chain ETH deposit. Funds are credited automatically upon 12 block confirmations.',
        isActive: eth.isActive ?? true
      },
      {
        id: 'bnb_mainnet',
        coin: 'BNB',
        boxName: 'BNB ADDRESS',
        networkDisplayName: 'BNB Smart Chain (BEP20)',
        address: bnb.receivingAddress || '',
        brandColor: '#F3BA2F',
        minDepositUsd: bnb.minDepositUsd || 10,
        networkWarning: '⚠️ Send ONLY BNB via BNB Smart Chain (BEP20).',
        depositInstructions: 'Send Native BNB (BEP20) to the address below. Settled within 15 seconds.',
        isActive: bnb.isActive ?? true
      }
    ];
  }

  // Mutation: Quick Update Crypto Box Address (SOL, ETH, BNB) with live broadcast
  public async updateCryptoBoxAddress(
    coin: 'SOL' | 'ETH' | 'BNB',
    newAddress: string,
    admin: AdminUser
  ): Promise<PaymentMethodConfig> {
    const idMap: Record<'SOL' | 'ETH' | 'BNB', string> = {
      SOL: 'sol_mainnet',
      ETH: 'eth_mainnet',
      BNB: 'bnb_mainnet'
    };
    const methodId = idMap[coin];
    const cleanAddr = newAddress ? newAddress.trim() : '';

    if (!this.paymentMethods[methodId]) {
      const initM = INITIAL_PAYMENT_METHODS.find(m => m.id === methodId);
      if (initM) {
        this.paymentMethods[methodId] = { ...initM, receivingAddress: '' };
      }
    }

    const method = this.paymentMethods[methodId];
    if (!method) throw new Error(`Method ${methodId} not found.`);

    const oldAddress = method.receivingAddress || '';
    method.receivingAddress = cleanAddr;
    method.lastUpdatedAt = Date.now();
    method.lastUpdatedByAdmin = {
      adminId: admin.id,
      adminName: admin.name,
      adminEmail: admin.email,
      adminRole: admin.role
    };

    const auditLog: PaymentAddressAuditLog = {
      id: `audit_crypto_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now(),
      paymentMethodId: method.id,
      paymentMethodName: method.name,
      network: method.network,
      action: 'UPDATED',
      oldAddress,
      newAddress: cleanAddr,
      adminId: admin.id,
      adminEmail: admin.email,
      adminName: admin.name,
      adminRole: admin.role,
      ipAddress: '127.0.0.1 (Admin Dashboard)',
      deviceInfo: 'Admin Crypto Box Manager',
      reason: cleanAddr ? `Admin updated ${coin} ADDRESS` : `Admin cleared ${coin} ADDRESS to blank`,
      hash: '0x' + Math.random().toString(36).substring(2, 12)
    };

    this.auditLogs.unshift(auditLog);
    this.saveMethods();
    this.saveAudits();
    this.notify();
    return method;
  }

  // Mutation: Change Receiving Wallet Address (Admin Only)
  public async updatePaymentMethodAddress(params: {
    methodId: string;
    newAddress: string;
    admin: AdminUser;
    twoFactorPin?: string;
    reason?: string;
    ipAddress?: string;
    deviceInfo?: string;
  }): Promise<{ method: PaymentMethodConfig; auditLog: PaymentAddressAuditLog }> {
    // 1. Enforce RBAC Permission on backend
    if (!this.checkAdminPermission(params.admin, 'payment_address.manage')) {
      throw new Error(`Unauthorized: Administrator role '${params.admin.role}' does not possess 'payment_address.manage' permission.`);
    }

    const method = this.paymentMethods[params.methodId];
    if (!method) {
      throw new Error(`Payment method with ID '${params.methodId}' was not found.`);
    }

    // 2. Validate Address against selected network rules
    const validation = this.validateAddress(method.network, params.newAddress);
    if (!validation.isValid) {
      throw new Error(`Address validation failed: ${validation.errorMessage}`);
    }

    const oldAddress = method.receivingAddress;
    const formattedNewAddress = validation.formattedAddress;

    if (oldAddress === formattedNewAddress) {
      throw new Error('New receiving address is identical to the current active address.');
    }

    // 3. Update in Database State
    const now = Date.now();
    method.receivingAddress = formattedNewAddress;
    method.lastUpdatedAt = now;
    method.lastUpdatedByAdmin = {
      adminId: params.admin.id,
      adminName: params.admin.name,
      adminEmail: params.admin.email,
      adminRole: params.admin.role
    };

    this.saveMethods();

    // 4. Generate Cryptographic Audit Trail
    const prevHash = this.auditLogs[0]?.hash || 'GENESIS_TIXA_PAYMENT_VAULT';
    const auditId = `pa_audit_${now}_${Math.random().toString(36).slice(2, 7)}`;
    const logPayload = `${auditId}:${params.methodId}:${oldAddress}:${formattedNewAddress}:${now}:${prevHash}`;
    const hash = await sha256(logPayload);

    const auditLog: PaymentAddressAuditLog = {
      id: auditId,
      timestamp: now,
      paymentMethodId: method.id,
      paymentMethodName: method.name,
      network: method.network,
      action: 'UPDATED',
      oldAddress,
      newAddress: formattedNewAddress,
      adminId: params.admin.id,
      adminEmail: params.admin.email,
      adminName: params.admin.name,
      adminRole: params.admin.role,
      ipAddress: params.ipAddress || '192.168.1.100 (TLS 1.3)',
      deviceInfo: params.deviceInfo || 'Admin Workstation / WebAuthn Certified',
      reason: params.reason || 'Admin manual receiving address update',
      hash
    };

    this.auditLogs.unshift(auditLog);
    this.saveAudits();

    // 5. Register in Global Security Audit Engine
    await auditEngine.logEvent({
      actorId: params.admin.id,
      actorEmail: params.admin.email,
      actorRole: params.admin.role,
      action: 'PAYMENT_RECEIVING_ADDRESS_UPDATED',
      targetId: method.id,
      details: {
        methodId: method.id,
        methodName: method.name,
        network: method.network,
        oldAddress,
        newAddress: formattedNewAddress,
        reason: params.reason
      }
    });

    // 6. Notify all reactive subscribers (public app & deposit screens invalidate cache)
    this.notify();

    return { method, auditLog };
  }

  // Mutation: Toggle Active / Inactive Status
  public async togglePaymentMethodStatus(params: {
    methodId: string;
    isActive: boolean;
    admin: AdminUser;
    reason?: string;
  }): Promise<PaymentMethodConfig> {
    if (!this.checkAdminPermission(params.admin, 'payment_address.manage')) {
      throw new Error(`Unauthorized: Administrator role '${params.admin.role}' does not possess 'payment_address.manage' permission.`);
    }

    const method = this.paymentMethods[params.methodId];
    if (!method) {
      throw new Error(`Payment method '${params.methodId}' not found.`);
    }

    const oldStatus = method.isActive;
    method.isActive = params.isActive;
    method.lastUpdatedAt = Date.now();
    method.lastUpdatedByAdmin = {
      adminId: params.admin.id,
      adminName: params.admin.name,
      adminEmail: params.admin.email,
      adminRole: params.admin.role
    };

    this.saveMethods();

    const auditId = `pa_audit_toggle_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const hash = await sha256(`${auditId}:${method.id}:${params.isActive}:${Date.now()}`);

    const auditLog: PaymentAddressAuditLog = {
      id: auditId,
      timestamp: Date.now(),
      paymentMethodId: method.id,
      paymentMethodName: method.name,
      network: method.network,
      action: 'STATUS_TOGGLED',
      oldAddress: method.receivingAddress,
      newAddress: method.receivingAddress,
      oldStatus,
      newStatus: params.isActive,
      adminId: params.admin.id,
      adminEmail: params.admin.email,
      adminName: params.admin.name,
      adminRole: params.admin.role,
      ipAddress: '192.168.1.100 (TLS 1.3)',
      deviceInfo: 'Admin Console',
      reason: params.reason || `Payment channel ${params.isActive ? 'ACTIVATED' : 'DEACTIVATED'} by admin`,
      hash
    };

    this.auditLogs.unshift(auditLog);
    this.saveAudits();

    await auditEngine.logEvent({
      actorId: params.admin.id,
      actorEmail: params.admin.email,
      actorRole: params.admin.role,
      action: 'PAYMENT_METHOD_STATUS_TOGGLED',
      targetId: method.id,
      details: { methodId: method.id, newStatus: params.isActive }
    });

    this.notify();
    return method;
  }

  // Mutation: Add New Payment Method
  public async addPaymentMethod(params: {
    id?: string;
    name: string;
    network: SupportedNetwork;
    networkDisplayName: string;
    currency: string;
    category: PaymentMethodConfig['category'];
    receivingAddress: string;
    minDepositUsd?: number;
    networkWarning?: string;
    depositInstructions?: string;
    iconType?: string;
    brandColor?: string;
    admin: AdminUser;
    extraFields?: PaymentMethodConfig['extraFields'];
  }): Promise<PaymentMethodConfig> {
    if (!this.checkAdminPermission(params.admin, 'payment_address.manage')) {
      throw new Error(`Unauthorized: Administrator role '${params.admin.role}' does not possess 'payment_address.manage' permission.`);
    }

    const validation = this.validateAddress(params.network, params.receivingAddress);
    if (!validation.isValid) {
      throw new Error(`Address validation failed: ${validation.errorMessage}`);
    }

    const id = params.id || `${params.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${params.network.toLowerCase().replace(/[^a-z0-9]/g, '_')}_${Date.now().toString(36)}`;
    
    if (this.paymentMethods[id]) {
      throw new Error(`A payment method with ID '${id}' already exists.`);
    }

    const now = Date.now();
    const newMethod: PaymentMethodConfig = {
      id,
      name: params.name.trim(),
      network: params.network,
      networkDisplayName: params.networkDisplayName.trim(),
      currency: params.currency.trim().toUpperCase(),
      category: params.category,
      receivingAddress: validation.formattedAddress,
      isActive: true,
      minDepositUsd: params.minDepositUsd || 10.00,
      depositFeePercent: 0.0,
      networkWarning: params.networkWarning || `⚠️ Send only ${params.currency} via ${params.networkDisplayName}.`,
      depositInstructions: params.depositInstructions || `Transfer funds to the verified receiving address. Paste your transaction hash or reference ID below.`,
      requiresTxHash: true,
      iconType: params.iconType || 'usdt',
      brandColor: params.brandColor || '#06B6D4',
      lastUpdatedAt: now,
      lastUpdatedByAdmin: {
        adminId: params.admin.id,
        adminName: params.admin.name,
        adminEmail: params.admin.email,
        adminRole: params.admin.role
      },
      extraFields: params.extraFields
    };

    this.paymentMethods[id] = newMethod;
    this.saveMethods();

    const auditId = `pa_audit_create_${now}_${Math.random().toString(36).slice(2, 6)}`;
    const hash = await sha256(`${auditId}:${id}:${validation.formattedAddress}:${now}`);

    const auditLog: PaymentAddressAuditLog = {
      id: auditId,
      timestamp: now,
      paymentMethodId: id,
      paymentMethodName: newMethod.name,
      network: newMethod.network,
      action: 'CREATED',
      oldAddress: 'N/A (New Method Added)',
      newAddress: validation.formattedAddress,
      adminId: params.admin.id,
      adminEmail: params.admin.email,
      adminName: params.admin.name,
      adminRole: params.admin.role,
      ipAddress: '192.168.1.100 (TLS 1.3)',
      deviceInfo: 'Admin Console',
      reason: 'New payment channel added to gateway database',
      hash
    };

    this.auditLogs.unshift(auditLog);
    this.saveAudits();

    await auditEngine.logEvent({
      actorId: params.admin.id,
      actorEmail: params.admin.email,
      actorRole: params.admin.role,
      action: 'PAYMENT_METHOD_CREATED',
      targetId: id,
      details: { methodId: id, name: newMethod.name, network: newMethod.network }
    });

    this.notify();
    return newMethod;
  }

  // Mutation: Update MFS Transfer Modes (Payment, Send Money, Cash Out)
  public async updateMfsPaymentModes(params: {
    methodId: string;
    mfsModes: Partial<MfsModeConfig>;
    admin: AdminUser;
    reason?: string;
    twoFactorPin?: string;
    ipAddress?: string;
    deviceInfo?: string;
  }): Promise<{ method: PaymentMethodConfig; auditLog: PaymentAddressAuditLog }> {
    if (!this.checkAdminPermission(params.admin, 'payment_address.manage')) {
      throw new Error(`Unauthorized: Administrator role '${params.admin.role}' does not possess 'payment_address.manage' permission.`);
    }

    const method = this.paymentMethods[params.methodId];
    if (!method) {
      throw new Error(`Payment method with ID '${params.methodId}' was not found.`);
    }

    const now = Date.now();
    const oldModes: MfsModeConfig = method.mfsModes || {};
    const updatedModes: MfsModeConfig = {
      paymentNumber: params.mfsModes.paymentNumber !== undefined ? params.mfsModes.paymentNumber.trim() : (oldModes.paymentNumber || ''),
      paymentCounter: params.mfsModes.paymentCounter !== undefined ? params.mfsModes.paymentCounter.trim() : (oldModes.paymentCounter || '1'),
      paymentInstructions: params.mfsModes.paymentInstructions !== undefined ? params.mfsModes.paymentInstructions : oldModes.paymentInstructions,
      paymentEnabled: params.mfsModes.paymentEnabled !== undefined ? params.mfsModes.paymentEnabled : (oldModes.paymentEnabled ?? true),

      sendMoneyNumber: params.mfsModes.sendMoneyNumber !== undefined ? params.mfsModes.sendMoneyNumber.trim() : (oldModes.sendMoneyNumber || ''),
      sendMoneyInstructions: params.mfsModes.sendMoneyInstructions !== undefined ? params.mfsModes.sendMoneyInstructions : oldModes.sendMoneyInstructions,
      sendMoneyEnabled: params.mfsModes.sendMoneyEnabled !== undefined ? params.mfsModes.sendMoneyEnabled : (oldModes.sendMoneyEnabled ?? true),

      cashOutNumber: params.mfsModes.cashOutNumber !== undefined ? params.mfsModes.cashOutNumber.trim() : (oldModes.cashOutNumber || ''),
      cashOutInstructions: params.mfsModes.cashOutInstructions !== undefined ? params.mfsModes.cashOutInstructions : oldModes.cashOutInstructions,
      cashOutEnabled: params.mfsModes.cashOutEnabled !== undefined ? params.mfsModes.cashOutEnabled : (oldModes.cashOutEnabled ?? true),
    };

    method.mfsModes = updatedModes;
    // Keep primary receivingAddress matching the primary active channel
    method.receivingAddress = updatedModes.paymentNumber || updatedModes.sendMoneyNumber || updatedModes.cashOutNumber || '';
    method.lastUpdatedAt = now;
    method.lastUpdatedByAdmin = {
      adminId: params.admin.id,
      adminName: params.admin.name,
      adminEmail: params.admin.email,
      adminRole: params.admin.role
    };

    this.saveMethods();

    const prevHash = this.auditLogs[0]?.hash || 'GENESIS_TIXA_PAYMENT_VAULT';
    const auditId = `pa_audit_mfs_${now}_${Math.random().toString(36).slice(2, 7)}`;
    const logPayload = `${auditId}:${params.methodId}:MFS_MODES:${JSON.stringify(updatedModes)}:${now}:${prevHash}`;
    const hash = await sha256(logPayload);

    const auditLog: PaymentAddressAuditLog = {
      id: auditId,
      timestamp: now,
      paymentMethodId: method.id,
      paymentMethodName: method.name,
      network: method.network,
      action: 'UPDATED',
      oldAddress: `Pay: ${oldModes.paymentNumber || 'N/A'}, Send: ${oldModes.sendMoneyNumber || 'N/A'}, CashOut: ${oldModes.cashOutNumber || 'N/A'}`,
      newAddress: `Pay: ${updatedModes.paymentNumber || 'N/A'}, Send: ${updatedModes.sendMoneyNumber || 'N/A'}, CashOut: ${updatedModes.cashOutNumber || 'N/A'}`,
      adminId: params.admin.id,
      adminEmail: params.admin.email,
      adminName: params.admin.name,
      adminRole: params.admin.role,
      ipAddress: params.ipAddress || '192.168.1.100 (TLS 1.3)',
      deviceInfo: params.deviceInfo || 'Admin Workstation',
      reason: params.reason || 'Admin updated Bangladesh MFS payment modes (Payment, Send Money, Cash Out)',
      hash
    };

    this.auditLogs.unshift(auditLog);
    this.saveAudits();

    await auditEngine.logEvent({
      actorId: params.admin.id,
      actorEmail: params.admin.email,
      actorRole: params.admin.role,
      action: 'MFS_PAYMENT_MODES_UPDATED',
      targetId: method.id,
      details: {
        methodId: method.id,
        methodName: method.name,
        mfsModes: updatedModes,
        reason: params.reason
      }
    });

    this.notify();
    return { method, auditLog };
  }

  // Mutation: Remove Payment Method
  public async deletePaymentMethod(params: {
    methodId: string;
    admin: AdminUser;
    reason?: string;
  }): Promise<boolean> {
    if (!this.checkAdminPermission(params.admin, 'payment_address.manage')) {
      throw new Error(`Unauthorized: Administrator role '${params.admin.role}' does not possess 'payment_address.manage' permission.`);
    }

    const method = this.paymentMethods[params.methodId];
    if (!method) {
      throw new Error(`Payment method '${params.methodId}' not found.`);
    }

    const oldAddress = method.receivingAddress;
    delete this.paymentMethods[params.methodId];
    this.saveMethods();

    const auditId = `pa_audit_del_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const hash = await sha256(`${auditId}:${params.methodId}:DELETED:${Date.now()}`);

    const auditLog: PaymentAddressAuditLog = {
      id: auditId,
      timestamp: Date.now(),
      paymentMethodId: params.methodId,
      paymentMethodName: method.name,
      network: method.network,
      action: 'DELETED',
      oldAddress,
      newAddress: 'REMOVED',
      adminId: params.admin.id,
      adminEmail: params.admin.email,
      adminName: params.admin.name,
      adminRole: params.admin.role,
      ipAddress: '192.168.1.100 (TLS 1.3)',
      deviceInfo: 'Admin Console',
      reason: params.reason || 'Payment channel removed from database by admin',
      hash
    };

    this.auditLogs.unshift(auditLog);
    this.saveAudits();

    this.notify();
    return true;
  }

  // Query: Get Audit Logs
  public getAuditLogs(): PaymentAddressAuditLog[] {
    return [...this.auditLogs];
  }

  public wipeAllPaymentAddresses(): void {
    Object.keys(this.paymentMethods).forEach(key => {
      this.paymentMethods[key].receivingAddress = '';
      if (this.paymentMethods[key].mfsModes) {
        this.paymentMethods[key].mfsModes = {
          paymentNumber: '',
          paymentCounter: '1',
          paymentInstructions: this.paymentMethods[key].mfsModes?.paymentInstructions || '',
          paymentEnabled: true,
          sendMoneyNumber: '',
          sendMoneyInstructions: this.paymentMethods[key].mfsModes?.sendMoneyInstructions || '',
          sendMoneyEnabled: true,
          cashOutNumber: '',
          cashOutInstructions: this.paymentMethods[key].mfsModes?.cashOutInstructions || '',
          cashOutEnabled: true
        };
      }
    });
    this.auditLogs = [];
    localStorage.removeItem(STORAGE_PAYMENT_AUDIT_KEY);
    this.saveMethods();
    this.notify();
  }
}

export const paymentConfigEngine = PaymentConfigEngine.getInstance();
