import { COUNTRIES, CountryInfo } from '../data/countries';
import { forexTradingEngine } from './forexTradingEngine';
import { ledgerEngine } from './ledgerEngine';
import { languageEngine } from './languageEngine';
import { ForexPair } from '../types/forexTrading';

export interface CurrencyRateInfo {
  code: string;
  name: string;
  symbol: string;
  flag: string;
  type: 'FIAT' | 'CRYPTO';
  rateToUsd: number; // 1 USD = X Currency Units (for Fiat) or 1 Crypto = X USD (for Crypto)
  decimals: number;
}

export interface MarketBalanceValuation {
  tixaBalance: number;
  totalUsdValue: number;
  marketQuoteBalance: number;
  marketBaseBalance: number;
  quoteSymbol: string;
  baseSymbol: string;
  preferredCurrency: string;
  preferredCurrencySymbol: string;
  preferredCurrencyBalance: number;
  tixaPriceUsd: number;
  formattedTixa: string;
  formattedUsd: string;
  formattedMarketQuote: string;
  formattedPreferredFiat: string;
}

const STORAGE_PREFERRED_CURRENCY_KEY = 'tixa_preferred_view_currency_v1';

export class CurrencyConversionEngine {
  private static instance: CurrencyConversionEngine;

  private preferredCurrency: string = 'BDT'; // Default to BDT as requested in Bangladeshi community
  private cryptoRatesUsd: Record<string, number> = {
    USDT: 1.00,
    USDC: 1.00,
    NISI: 64280.50,
    SARA: 3485.20,
    MUN: 154.60
  };

  private listeners: Array<() => void> = [];

  private constructor() {
    this.loadPreferences();

    // Listen to forex engine ticks to trigger reactive price recalculations
    forexTradingEngine.subscribe(() => {
      this.syncCryptoRates();
      this.notify();
    });
  }

  public static getInstance(): CurrencyConversionEngine {
    if (!CurrencyConversionEngine.instance) {
      CurrencyConversionEngine.instance = new CurrencyConversionEngine();
    }
    return CurrencyConversionEngine.instance;
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach(cb => {
      try { cb(); } catch (err) { console.error('Currency engine listener err', err); }
    });
  }

  private loadPreferences(): void {
    try {
      const saved = localStorage.getItem(STORAGE_PREFERRED_CURRENCY_KEY);
      if (saved) {
        this.preferredCurrency = saved;
      }
    } catch {
      this.preferredCurrency = 'BDT';
    }
  }

  public syncCryptoRates(): void {
    const pairs = forexTradingEngine.getPairs();
    for (const p of pairs) {
      if (p.base === 'NISI') this.cryptoRatesUsd.NISI = p.currentPrice;
      if (p.base === 'SARA') this.cryptoRatesUsd.SARA = p.currentPrice;
      if (p.base === 'MUN') this.cryptoRatesUsd.MUN = p.currentPrice;
    }
  }

  public getCryptoRate(cryptoCode: string): number {
    this.syncCryptoRates();
    const code = cryptoCode.toUpperCase();
    if (code === 'USDT' || code === 'USDC') return 1.00;
    if (this.cryptoRatesUsd[code] && this.cryptoRatesUsd[code] > 0) {
      return this.cryptoRatesUsd[code];
    }
    if (code === 'NISI') return 64280.50;
    if (code === 'SARA') return 3485.20;
    if (code === 'MUN') return 154.60;
    return 1.00;
  }

  public getPreferredCurrency(): string {
    return this.preferredCurrency;
  }

  public setPreferredCurrency(currencyCode: string): void {
    const code = currencyCode.toUpperCase();
    this.preferredCurrency = code;
    try {
      localStorage.setItem(STORAGE_PREFERRED_CURRENCY_KEY, this.preferredCurrency);
    } catch {
      // ignore
    }

    // Auto-detect and switch whole app language based on selected currency
    languageEngine.autoDetectAndSetLanguage({ currency: code });

    this.notify();
  }

  /**
   * Get the current real-time TIXA coin price in USD/USDT
   */
  public getLiveTixaPriceUsd(): number {
    const pair = forexTradingEngine.getPair('TIXA_USDT');
    if (pair && pair.currentPrice > 0) {
      return pair.currentPrice;
    }
    return ledgerEngine.getTixaUsdtPrice() || 990000.00;
  }

  /**
   * List of all supported currencies (Fiat + Crypto)
   */
  public getAllCurrencies(): CurrencyRateInfo[] {
    const list: CurrencyRateInfo[] = [];

    // 1. Primary Fiat Currencies from Countries list
    const seen = new Set<string>();
    
    // Add USD first
    list.push({
      code: 'USD',
      name: 'US Dollar',
      symbol: '$',
      flag: '🇺🇸',
      type: 'FIAT',
      rateToUsd: 1.00,
      decimals: 2
    });
    seen.add('USD');

    // Add BDT next
    list.push({
      code: 'BDT',
      name: 'Bangladeshi Taka',
      symbol: '৳',
      flag: '🇧🇩',
      type: 'FIAT',
      rateToUsd: ledgerEngine.getFiatRate('BDT') || 121.50,
      decimals: 2
    });
    seen.add('BDT');

    // Major global fiats
    for (const c of COUNTRIES) {
      if (seen.has(c.currency)) continue;
      seen.add(c.currency);
      list.push({
        code: c.currency,
        name: c.name,
        symbol: c.currencySymbol,
        flag: c.flag,
        type: 'FIAT',
        rateToUsd: ledgerEngine.getFiatRate(c.currency) || c.rateToUsd,
        decimals: 2
      });
    }

    this.syncCryptoRates();
    const btcPrice = this.getCryptoRate('BTC');
    const ethPrice = this.getCryptoRate('ETH');
    const solPrice = this.getCryptoRate('SOL');

    // 2. Major Cryptos
    list.push({
      code: 'USDT',
      name: 'Tether USD',
      symbol: '₮',
      flag: '🟢',
      type: 'CRYPTO',
      rateToUsd: 1.00,
      decimals: 2
    });
    list.push({
      code: 'BTC',
      name: 'Bitcoin',
      symbol: '₿',
      flag: '🪙',
      type: 'CRYPTO',
      rateToUsd: 1 / btcPrice,
      decimals: 6
    });
    list.push({
      code: 'ETH',
      name: 'Ethereum',
      symbol: 'Ξ',
      flag: '🔷',
      type: 'CRYPTO',
      rateToUsd: 1 / ethPrice,
      decimals: 5
    });
    list.push({
      code: 'SOL',
      name: 'Solana',
      symbol: '◎',
      flag: '🟣',
      type: 'CRYPTO',
      rateToUsd: 1 / solPrice,
      decimals: 4
    });

    return list;
  }

  public getFiatCurrencies(): CurrencyRateInfo[] {
    return this.getAllCurrencies().filter(c => c.type === 'FIAT');
  }

  public convertUsdToFiat(usdAmount: number, targetCurrency: string): number {
    const cur = this.getCurrencyInfo(targetCurrency);
    if (cur.type === 'CRYPTO') {
      if (cur.code === 'USDT' || cur.code === 'USDC') return usdAmount;
      const cryptoPrice = this.getCryptoRate(cur.code);
      return cryptoPrice > 0 ? (usdAmount / cryptoPrice) : usdAmount;
    }
    return usdAmount * cur.rateToUsd;
  }

  public getCurrencyInfo(currencyCode: string): CurrencyRateInfo {
    const code = currencyCode.toUpperCase();
    const all = this.getAllCurrencies();
    const found = all.find(c => c.code === code);
    if (found) return found;

    // Fallback
    return {
      code,
      name: code,
      symbol: code,
      flag: '🌐',
      type: 'FIAT',
      rateToUsd: ledgerEngine.getFiatRate(code) || 1.00,
      decimals: 2
    };
  }

  /**
   * Convert Native TIXA amount into target currency
   */
  public convertTixaToCurrency(tixaAmount: number, targetCurrency: string): number {
    const tixaPriceUsd = this.getLiveTixaPriceUsd();
    const totalUsd = tixaAmount * tixaPriceUsd;

    const cur = this.getCurrencyInfo(targetCurrency);
    if (cur.type === 'CRYPTO') {
      if (cur.code === 'USDT' || cur.code === 'USDC') return totalUsd;
      const cryptoPriceUsd = this.cryptoRatesUsd[cur.code] || 1;
      return cryptoPriceUsd > 0 ? totalUsd / cryptoPriceUsd : totalUsd;
    }

    // Fiat conversion
    return totalUsd * cur.rateToUsd;
  }

  /**
   * Convert any currency amount into Native TIXA amount
   */
  public convertCurrencyToTixa(amount: number, sourceCurrency: string): number {
    const tixaPriceUsd = this.getLiveTixaPriceUsd();
    if (tixaPriceUsd <= 0) return 0;

    const cur = this.getCurrencyInfo(sourceCurrency);
    let amountUsd = amount;

    if (cur.type === 'CRYPTO') {
      if (cur.code === 'USDT' || cur.code === 'USDC') {
        amountUsd = amount;
      } else {
        const cryptoPriceUsd = this.cryptoRatesUsd[cur.code] || 1;
        amountUsd = amount * cryptoPriceUsd;
      }
    } else {
      // Fiat: convert to USD
      amountUsd = cur.rateToUsd > 0 ? amount / cur.rateToUsd : amount;
    }

    return amountUsd / tixaPriceUsd;
  }

  /**
   * Format converted price with symbols and separators
   */
  public formatTixaPriceInCurrency(currencyCode: string, tixaQuantity: number = 1): string {
    const cur = this.getCurrencyInfo(currencyCode);
    const converted = this.convertTixaToCurrency(tixaQuantity, currencyCode);

    if (cur.type === 'CRYPTO' && cur.code !== 'USDT') {
      return `${cur.symbol} ${converted.toLocaleString('en-US', { minimumFractionDigits: cur.decimals, maximumFractionDigits: cur.decimals })}`;
    }

    return `${cur.symbol}${converted.toLocaleString('en-US', { minimumFractionDigits: cur.decimals, maximumFractionDigits: cur.decimals })}`;
  }

  /**
   * Calculate exact real-time valuation of trader balance for the active market pair
   */
  public calculateMarketBalance(
    tixaBalance: number,
    pair: ForexPair,
    preferredCurrencyOverride?: string
  ): MarketBalanceValuation {
    const tixaPriceUsd = this.getLiveTixaPriceUsd();
    const totalUsdValue = tixaBalance * tixaPriceUsd;

    const prefCurCode = preferredCurrencyOverride || this.preferredCurrency;
    const prefInfo = this.getCurrencyInfo(prefCurCode);
    const preferredCurrencyBalance = this.convertUsdToFiat(totalUsdValue, prefCurCode);

    // Determine Quote Currency equivalent
    let marketQuoteBalance = totalUsdValue;
    if (pair.quote === 'JPY') {
      marketQuoteBalance = totalUsdValue * 154.28;
    } else if (pair.quote === 'EUR') {
      marketQuoteBalance = totalUsdValue * 0.92;
    } else if (pair.quote === 'GBP') {
      marketQuoteBalance = totalUsdValue * 0.79;
    }

    // Determine Base Currency equivalent
    let marketBaseBalance = 0;
    if (pair.base === 'TIXA') {
      marketBaseBalance = tixaBalance;
    } else if (pair.currentPrice > 0) {
      marketBaseBalance = marketQuoteBalance / pair.currentPrice;
    }

    return {
      tixaBalance,
      totalUsdValue,
      marketQuoteBalance,
      marketBaseBalance,
      quoteSymbol: pair.quote,
      baseSymbol: pair.base,
      preferredCurrency: prefInfo.code,
      preferredCurrencySymbol: prefInfo.symbol,
      preferredCurrencyBalance,
      tixaPriceUsd,
      formattedTixa: `${tixaBalance.toLocaleString('en-US', { minimumFractionDigits: 4, maximumFractionDigits: 6 })} TIXA`,
      formattedUsd: `$${totalUsdValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      formattedMarketQuote: `${marketQuoteBalance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${pair.quote}`,
      formattedPreferredFiat: `${prefInfo.symbol}${preferredCurrencyBalance.toLocaleString('en-US', { minimumFractionDigits: prefInfo.decimals, maximumFractionDigits: prefInfo.decimals })} ${prefInfo.code}`
    };
  }
}

export const currencyConversionEngine = CurrencyConversionEngine.getInstance();
