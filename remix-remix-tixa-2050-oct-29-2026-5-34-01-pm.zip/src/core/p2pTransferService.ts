import { db, auth } from '../lib/firebase';
import { doc, collection, runTransaction, serverTimestamp, query, where, getDocs } from 'firebase/firestore';

export interface P2PTransferResult {
  transferId: string;
  recipientIdentifier: string;
  amount: number;
  usdValue: number;
  timestamp: number;
}

export interface P2PTransactionRecord {
  id: string;
  type: 'P2P_SEND' | 'P2P_RECEIVE';
  senderUid?: string;
  recipientUid?: string;
  senderAddress?: string;
  recipientAddress?: string;
  recipientIdentifier?: string;
  amount: number;
  usdValue?: number;
  currency: 'TIXA';
  status: 'COMPLETED';
  timestamp: number;
  reference?: string;
  fee?: number;
}

export const p2pTransferService = {
  async lookupRecipient(recipientAddress: string): Promise<{ uid: string; identifier: string } | null> {
    const trimmed = recipientAddress.trim();
    if (!trimmed.startsWith('tx1')) return null;

    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('walletAddress', '==', trimmed));
    const querySnap = await getDocs(q);

    if (querySnap.empty) return null;

    const docSnap = querySnap.docs[0];
    const data = docSnap.data();
    const email = data.email || 'User***';
    const maskedEmail = email.replace(/(^[\w\.]{2})[\w\.]+(@[\w\.]+$)/, "$1***$2");

    return {
      uid: docSnap.id,
      identifier: maskedEmail
    };
  },

  async executeTransfer(
    recipientAddress: string, 
    amount: number, 
    memo?: string, 
    usdPrice: number = 990000
  ): Promise<P2PTransferResult> {
    const senderUser = auth.currentUser;
    if (!senderUser) throw new Error('Please login first. (Sender not authenticated.)');
    const senderUid = senderUser.uid;

    if (amount <= 0) throw new Error('Amount cannot be zero or negative. (Amount must be positive.)');

    const effectivePrice = usdPrice > 0 ? usdPrice : 990000;
    const usdValue = amount * effectivePrice;
    
    // Strict $5 USD Minimum Transfer Requirement
    if (usdValue < 4.999) {
      const minTixa = (5 / effectivePrice).toFixed(8);
      throw new Error(`Minimum transfer of $5 USD worth of TIXA Coin is required (minimum ${minTixa} TIXA based on current rate). Your selected amount: $${usdValue.toFixed(2)} USD.`);
    }

    const trimmedAddress = recipientAddress.trim();
    if (!trimmedAddress.startsWith('tx1')) {
      throw new Error('Invalid wallet address. Address must start with "tx1".');
    }

    // Resolve recipient UID
    const usersRef = collection(db, 'users');
    const q = query(usersRef, where('walletAddress', '==', trimmedAddress));
    const querySnap = await getDocs(q);

    if (querySnap.empty) {
      throw new Error('No registered user found for this wallet address.');
    }

    const recipientDocSnap = querySnap.docs[0];
    const recipientUid = recipientDocSnap.id;

    if (recipientUid === senderUid) {
      throw new Error('You cannot transfer funds to your own account.');
    }

    const recipientData = recipientDocSnap.data();
    const recipientEmail = recipientData.email || 'User***';
    const maskedEmail = recipientEmail.replace(/(^[\w\.]{2})[\w\.]+(@[\w\.]+$)/, "$1***$2");
    const transferId = `p2p_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
    const timestamp = Date.now();
    let senderWalletAddress = '';

    // Atomic Firestore transaction with Zero Admin Intervention (100% Free Instant P2P)
    await runTransaction(db, async (transaction) => {
      const senderRef = doc(db, 'users', senderUid);
      const recipientRef = doc(db, 'users', recipientUid);

      const senderSnap = await transaction.get(senderRef);
      const recipientSnap = await transaction.get(recipientRef);

      if (!senderSnap.exists()) throw new Error('Sender account not found.');
      if (!recipientSnap.exists()) throw new Error('Receiver account not found.');

      const senderData = senderSnap.data();
      senderWalletAddress = senderData.walletAddress || '';
      const senderBalance = Number(senderData.fixDipozRealWallet ?? senderData.balance ?? 0);

      if (senderBalance < amount) {
        throw new Error(`Insufficient balance. Your available balance: ${senderBalance.toFixed(8)} TIXA`);
      }

      const recipientBalance = Number(recipientSnap.data().fixDipozRealWallet ?? recipientSnap.data().balance ?? 0);

      const newSenderBalance = senderBalance - amount;
      const newRecipientBalance = recipientBalance + amount;

      // Update balances atomically
      transaction.update(senderRef, {
        fixDipozRealWallet: newSenderBalance,
        balance: newSenderBalance,
        lastUpdatedServer: serverTimestamp()
      });

      transaction.update(recipientRef, {
        fixDipozRealWallet: newRecipientBalance,
        balance: newRecipientBalance,
        lastUpdatedServer: serverTimestamp()
      });

      // Record transaction for sender
      const senderTxRef = doc(db, 'users', senderUid, 'transactions', transferId);
      transaction.set(senderTxRef, {
        id: transferId,
        type: 'P2P_SEND',
        senderUid,
        recipientUid,
        recipientAddress: trimmedAddress,
        recipientIdentifier: maskedEmail,
        amount,
        usdValue: Number(usdValue.toFixed(2)),
        fee: 0,
        currency: 'TIXA',
        status: 'COMPLETED',
        timestamp,
        reference: memo || 'Instant P2P Transfer Sent',
        createdAtServer: serverTimestamp()
      });

      // Record transaction for recipient
      const recipientTxRef = doc(db, 'users', recipientUid, 'transactions', transferId);
      transaction.set(recipientTxRef, {
        id: transferId,
        type: 'P2P_RECEIVE',
        senderUid,
        recipientUid,
        senderAddress: senderData.walletAddress || '',
        amount,
        usdValue: Number(usdValue.toFixed(2)),
        fee: 0,
        currency: 'TIXA',
        status: 'COMPLETED',
        timestamp,
        reference: memo || 'Instant P2P Transfer Received',
        createdAtServer: serverTimestamp()
      });
    });

    // In-memory synchronization for local state without refresh
    try {
      const { blockchainEngine } = await import('./blockchainEngine');
      if (senderWalletAddress) {
        blockchainEngine.deductBalance(senderWalletAddress, amount, memo || 'Instant P2P Transfer Sent');
      }
      if (recipientData.walletAddress) {
        blockchainEngine.creditBalance(recipientData.walletAddress, amount);
      }
    } catch (e) {
      console.warn('In-memory blockchain state sync note:', e);
    }

    return {
      transferId,
      recipientIdentifier: maskedEmail,
      amount,
      usdValue: Number(usdValue.toFixed(2)),
      timestamp
    };
  },

  async getP2PHistory(uid?: string): Promise<P2PTransactionRecord[]> {
    const currentUid = uid || auth.currentUser?.uid;
    if (!currentUid) return [];

    try {
      const txsRef = collection(db, 'users', currentUid, 'transactions');
      const snap = await getDocs(txsRef);
      const list: P2PTransactionRecord[] = [];

      snap.forEach(docSnap => {
        const data = docSnap.data() as any;
        if (data.type === 'P2P_SEND' || data.type === 'P2P_RECEIVE' || data.id?.startsWith('p2p_')) {
          list.push({
            id: data.id || docSnap.id,
            type: data.type || (data.recipientUid === currentUid ? 'P2P_RECEIVE' : 'P2P_SEND'),
            senderUid: data.senderUid,
            recipientUid: data.recipientUid,
            senderAddress: data.senderAddress,
            recipientAddress: data.recipientAddress,
            recipientIdentifier: data.recipientIdentifier,
            amount: Number(data.amount || 0),
            usdValue: data.usdValue ? Number(data.usdValue) : undefined,
            currency: 'TIXA',
            status: 'COMPLETED',
            timestamp: data.timestamp || Date.now(),
            reference: data.reference,
            fee: 0
          });
        }
      });

      // Sort newest first
      list.sort((a, b) => b.timestamp - a.timestamp);
      return list;
    } catch (err) {
      console.warn('Failed to load P2P history from Firestore:', err);
      return [];
    }
  }
};
