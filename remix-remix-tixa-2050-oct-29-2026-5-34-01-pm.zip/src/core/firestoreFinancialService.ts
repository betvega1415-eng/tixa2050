import { db, auth } from '../lib/firebase';
import { collection, doc, setDoc, getDocs, serverTimestamp } from 'firebase/firestore';

export interface FirestoreInvestment {
  id?: string;
  boxId: number;
  boxName: string;
  investedAt: number;
  expiresAt: number;
  amount: number;
  currentReturnRate: number;
  finalRateLocked?: number;
  claimed: boolean;
  mode: 'DEMO' | 'REAL';
}

export interface FirestoreDepositRecord {
  id: string;
  amount: number;
  currency: string;
  method: string;
  txHashOrReference: string;
  status: string;
  createdAt: number;
}

export interface FirestoreWithdrawalRecord {
  id: string;
  amount: number;
  currency: string;
  destination: string;
  status: string;
  createdAt: number;
}

export interface FirestoreTransactionRecord {
  id: string;
  type: string;
  amount: number;
  asset: string;
  status: string;
  createdAt: number;
  referenceId?: string;
  description?: string;
  boxId?: number;
  boxName?: string;
  investedAt?: string;
  completedAt?: string;
  investAmount?: number;
  returnPercentage?: number;
  profitAmount?: number;
  totalPayout?: number;
  mode?: 'DEMO' | 'REAL';
}

export const firestoreFinancialService = {
  async saveInvestment(uid: string, investment: Partial<FirestoreInvestment> & { boxId?: number; id?: string }): Promise<void> {
    if (!uid || !investment) return;
    try {
      const docId = String(investment.id || (investment.boxId !== undefined ? `box_${investment.boxId}` : `inv_${Date.now()}`));
      if (!docId || docId === 'undefined') return;
      const ref = doc(db, 'users', uid, 'investments', docId);
      await setDoc(ref, {
        ...investment,
        id: docId,
        updatedAtServer: serverTimestamp()
      }, { merge: true });
    } catch (err) {
      console.error('Error saving investment to Firestore:', err);
    }
  },

  async getInvestments(uid: string): Promise<FirestoreInvestment[]> {
    if (!uid) return [];
    try {
      const ref = collection(db, 'users', uid, 'investments');
      const snap = await getDocs(ref);
      const list: FirestoreInvestment[] = [];
      snap.forEach(d => {
        list.push(d.data() as FirestoreInvestment);
      });
      return list;
    } catch (err) {
      console.error('Error getting investments from Firestore:', err);
      return [];
    }
  },

  async saveDeposit(uid: string, deposit: Partial<FirestoreDepositRecord> & { id?: string }): Promise<void> {
    if (!uid || !deposit) return;
    try {
      const docId = String(deposit.id || `dep_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
      const ref = doc(db, 'users', uid, 'deposits', docId);
      await setDoc(ref, { ...deposit, id: docId, updatedAtServer: serverTimestamp() }, { merge: true });
    } catch (err) {
      console.error('Error saving deposit to Firestore:', err);
    }
  },

  async getDeposits(uid: string): Promise<FirestoreDepositRecord[]> {
    if (!uid) return [];
    try {
      const ref = collection(db, 'users', uid, 'deposits');
      const snap = await getDocs(ref);
      const list: FirestoreDepositRecord[] = [];
      snap.forEach(d => list.push(d.data() as FirestoreDepositRecord));
      return list;
    } catch (err) {
      console.error('Error getting deposits:', err);
      return [];
    }
  },

  async saveWithdrawal(uid: string, withdrawal: Partial<FirestoreWithdrawalRecord> & { id?: string }): Promise<void> {
    if (!uid || !withdrawal) return;
    try {
      const docId = String(withdrawal.id || `wdr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
      const ref = doc(db, 'users', uid, 'withdrawals', docId);
      await setDoc(ref, { ...withdrawal, id: docId, updatedAtServer: serverTimestamp() }, { merge: true });
    } catch (err) {
      console.error('Error saving withdrawal:', err);
    }
  },

  async getWithdrawals(uid: string): Promise<FirestoreWithdrawalRecord[]> {
    if (!uid) return [];
    try {
      const ref = collection(db, 'users', uid, 'withdrawals');
      const snap = await getDocs(ref);
      const list: FirestoreWithdrawalRecord[] = [];
      snap.forEach(d => list.push(d.data() as FirestoreWithdrawalRecord));
      return list;
    } catch (err) {
      console.error('Error getting withdrawals:', err);
      return [];
    }
  },

  async saveTransaction(uid: string, tx: Partial<FirestoreTransactionRecord> & { id?: string }): Promise<void> {
    if (!uid || !tx) return;
    try {
      const docId = String(tx.id || `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`);
      const ref = doc(db, 'users', uid, 'transactions', docId);
      await setDoc(ref, { ...tx, id: docId, updatedAtServer: serverTimestamp() }, { merge: true });
    } catch (err) {
      console.error('Error saving transaction:', err);
    }
  },

  async getTransactions(uid: string): Promise<FirestoreTransactionRecord[]> {
    if (!uid) return [];
    try {
      const ref = collection(db, 'users', uid, 'transactions');
      const snap = await getDocs(ref);
      const list: FirestoreTransactionRecord[] = [];
      snap.forEach(d => list.push(d.data() as FirestoreTransactionRecord));
      return list;
    } catch (err) {
      console.error('Error getting transactions:', err);
      return [];
    }
  },

  async updateRealWalletBalance(uid: string, balance: number): Promise<void> {
    if (!uid) return;
    try {
      const ref = doc(db, 'users', uid);
      await setDoc(ref, {
        fixDipozRealWallet: balance,
        lastUpdatedServer: serverTimestamp()
      }, { merge: true });
    } catch (err) {
      console.error('Error updating real wallet balance:', err);
    }
  }
};
