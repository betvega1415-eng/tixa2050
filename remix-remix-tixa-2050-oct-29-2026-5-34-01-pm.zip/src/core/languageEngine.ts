import { LANGUAGES_99, LanguageInfo } from '../data/languages';
import { TRANSLATIONS, TranslationDictionary } from '../data/translations';

const STORAGE_KEY = 'tixa_selected_language';

// Expanded translations for high-demand language codes
const EXTENDED_TRANSLATIONS: Record<string, Partial<TranslationDictionary>> = {
  pt: {
    nav_home: 'Início',
    nav_markets: 'Mercados',
    nav_trading: 'Negociação',
    nav_wallet: 'Carteira',
    nav_explorer: 'Blockchain',
    nav_transactions: 'Transações',
    nav_holdings: 'Top 100 & Metas 2050',
    nav_developer: 'Ferramentas Dev',
    nav_admin: 'Painel Admin',
    nav_dashboard: 'Meu Painel',
    nav_profile: 'Segurança & Perfil',
    nav_tokens: 'Tokens',
    btn_login: 'Entrar',
    btn_signup: 'Cadastrar',
    btn_logout: 'Sair',
    btn_connect_wallet: 'Conectar Cofre',
    btn_buy: 'Comprar',
    btn_sell: 'Vender',
    btn_deposit: 'Depositar',
    btn_withdraw: 'Sacar',
    btn_transfer: 'Transferir',
    btn_send: 'Enviar',
    btn_receive: 'Receber',
    btn_swap: 'Troca Instantânea',
    btn_stake: 'Staking & Ganhos',
    btn_confirm: 'Confirmar',
    btn_cancel: 'Cancelar',
    btn_close: 'Fechar',
    btn_copy: 'Copiar',
    btn_copied: 'Copiado!',
    btn_refresh: 'Atualizar',
    btn_search: 'Pesquisar...',
    btn_view_all: 'Ver Todos',
    btn_trade_now: 'Negociar Agora',
    btn_explore: 'Explorar',
    btn_select_language: 'Idioma',
    btn_save_changes: 'Salvar Alterações',
    dash_total_balance: 'Saldo Total do Cofre',
    dash_net_worth: 'Patrimônio Estimado',
    auth_signin_title: 'Entrar no Cofre TIXA',
    auth_signup_title: 'Criar Cofre Não-Custodial',
    settings_language: 'Idioma da Interface',
    settings_select_lang_title: 'Selecionar Idioma (99 Países)',
    settings_saved_success: 'Preferência de idioma salva com sucesso!'
  },
  tr: {
    nav_home: 'Ana Sayfa',
    nav_markets: 'Piyasalar',
    nav_trading: 'Ticaret',
    nav_wallet: 'Cüzdan',
    nav_explorer: 'Blokzincir',
    nav_transactions: 'İşlem Geçmişi',
    nav_holdings: 'İlk 100 ve 2050 Hedefleri',
    nav_developer: 'Geliştirici Araçları',
    nav_admin: 'Yönetici Paneli',
    nav_dashboard: 'Kontrol Paneli',
    nav_profile: 'Güvenlik & Profil',
    nav_tokens: 'Tokenlar',
    btn_login: 'Giriş Yap',
    btn_signup: 'Kayıt Ol',
    btn_logout: 'Çıkış Yap',
    btn_connect_wallet: 'Kasaya Bağlan',
    btn_buy: 'Satın Al',
    btn_sell: 'Sat',
    btn_deposit: 'Yatır',
    btn_withdraw: 'Çek',
    btn_transfer: 'Transfer',
    btn_send: 'Gönder',
    btn_receive: 'Al',
    btn_swap: 'Anında Takas',
    btn_stake: 'Staking ve Kazanç',
    btn_confirm: 'Onayla',
    btn_cancel: 'İptal',
    btn_close: 'Kapat',
    btn_copy: 'Kopyala',
    btn_copied: 'Kopyalandı!',
    btn_refresh: 'Yenile',
    btn_search: 'Ara...',
    btn_view_all: 'Hepsini Gör',
    btn_trade_now: 'Şimdi Al-Sat',
    btn_explore: 'Keşfet',
    btn_select_language: 'Dil (Language)',
    btn_save_changes: 'Değişiklikleri Kaydet',
    dash_total_balance: 'Toplam Kasa Bakiyesi',
    dash_net_worth: 'Tahmini Net Değer',
    auth_signin_title: 'TIXA Kasasına Giriş',
    auth_signup_title: 'Gözetimsiz Kasa Oluştur',
    settings_language: 'Arayüz Dili',
    settings_select_lang_title: 'Dil Seçin (99 Ülke Desteği)',
    settings_saved_success: 'Dil tercihi başarıyla kaydedildi!'
  },
  vi: {
    nav_home: 'Trang Chủ',
    nav_markets: 'Thị Trường',
    nav_trading: 'Giao Dịch',
    nav_wallet: 'Ví Tài Sản',
    nav_explorer: 'Blockchain',
    nav_transactions: 'Lịch Sử Giao Dịch',
    nav_holdings: 'Top 100 & Mục Tiêu 2050',
    nav_developer: 'Công Cụ Dev',
    nav_admin: 'Bảng Quản Trị',
    nav_dashboard: 'Bảng Điều Khiển',
    nav_profile: 'Bảo Mật & Hồ Sơ',
    nav_tokens: 'Danh Sách Token',
    btn_login: 'Đăng Nhập',
    btn_signup: 'Đăng Ký',
    btn_logout: 'Đăng Xuất',
    btn_connect_wallet: 'Kết Nối Két Sắt',
    btn_buy: 'Mua',
    btn_sell: 'Bán',
    btn_deposit: 'Nạp Tiền',
    btn_withdraw: 'Rút Tiền',
    btn_transfer: 'Chuyển Khoản',
    btn_send: 'Gửi',
    btn_receive: 'Nhận',
    btn_swap: 'Hoán Đổi Nhanh',
    btn_stake: 'Staking & Kiếm Lời',
    btn_confirm: 'Xác Nhận',
    btn_cancel: 'Hủy Bỏ',
    btn_close: 'Đóng',
    btn_copy: 'Sao Chép',
    btn_copied: 'Đã Sao Chép!',
    btn_refresh: 'Làm Mới',
    btn_search: 'Tìm Kiếm...',
    btn_view_all: 'Xem Tất Cả',
    btn_trade_now: 'Giao Dịch Ngay',
    btn_explore: 'Khám Phá',
    btn_select_language: 'Ngôn Ngữ',
    btn_save_changes: 'Lưu Thay Đổi',
    dash_total_balance: 'Tổng Số Dư Két Sắt',
    dash_net_worth: 'Giá Trị Tài Sản Ròng',
    auth_signin_title: 'Đăng Nhập Két Sắt TIXA',
    auth_signup_title: 'Tạo Két Sắt Phi Tập Trung',
    settings_language: 'Ngôn Ngữ Giao Diện',
    settings_select_lang_title: 'Chọn Ngôn Ngữ (Hỗ Trợ 99 Quốc Gia)',
    settings_saved_success: 'Đã lưu tùy chọn ngôn ngữ thành công!'
  },
  ko: {
    nav_home: '홈',
    nav_markets: '시장 시세',
    nav_trading: '거래',
    nav_wallet: '지갑',
    nav_explorer: '블록체인',
    nav_transactions: '거래 내역',
    nav_holdings: 'Top 100 및 2050 목표',
    nav_developer: '개발자 도구',
    nav_admin: '관리자 패널',
    nav_dashboard: '대시보드',
    nav_profile: '보안 및 프로필',
    nav_tokens: '토큰 목록',
    btn_login: '로그인',
    btn_signup: '회원가입',
    btn_logout: '로그아웃',
    btn_connect_wallet: '금고 연결',
    btn_buy: '매수',
    btn_sell: '매도',
    btn_deposit: '입금',
    btn_withdraw: '출금',
    btn_transfer: '이체',
    btn_send: '보내기',
    btn_receive: '받기',
    btn_swap: '즉시 스왑',
    btn_stake: '스테이킹 수익',
    btn_confirm: '확인',
    btn_cancel: '취소',
    btn_close: '닫기',
    btn_copy: '복사',
    btn_copied: '복사 완료!',
    btn_refresh: '새로고침',
    btn_search: '검색...',
    btn_view_all: '전체 보기',
    btn_trade_now: '지금 거래',
    btn_explore: '탐색',
    btn_select_language: '언어 설정',
    btn_save_changes: '변경사항 저장',
    dash_total_balance: '금고 총 잔액',
    dash_net_worth: '추정 순자산 가치',
    auth_signin_title: 'TIXA 금고 로그인',
    auth_signup_title: '비수탁형 금고 생성',
    settings_language: '인터페이스 언어',
    settings_select_lang_title: '언어 선택 (99개국 지원)',
    settings_saved_success: '언어 설정이 성공적으로 저장되었습니다!'
  },
  it: {
    nav_home: 'Home',
    nav_markets: 'Mercati',
    nav_trading: 'Trading',
    nav_wallet: 'Portafoglio',
    nav_explorer: 'Blockchain',
    nav_transactions: 'Transazioni',
    nav_holdings: 'Top 100 & Obiettivi 2050',
    nav_developer: 'Strumenti Dev',
    nav_admin: 'Pannello Admin',
    nav_dashboard: 'Dashboard',
    nav_profile: 'Sicurezza & Profilo',
    nav_tokens: 'Tokens',
    btn_login: 'Accedi',
    btn_signup: 'Registrati',
    btn_logout: 'Esci',
    btn_connect_wallet: 'Connetti Cassaforte',
    btn_buy: 'Acquista',
    btn_sell: 'Vendi',
    btn_deposit: 'Deposita',
    btn_withdraw: 'Preleva',
    btn_transfer: 'Trasferisci',
    btn_send: 'Invia',
    btn_receive: 'Ricevi',
    btn_swap: 'Scambio Istantaneo',
    btn_stake: 'Staking & Guadagni',
    btn_confirm: 'Conferma',
    btn_cancel: 'Annulla',
    btn_close: 'Chiudi',
    btn_copy: 'Copia',
    btn_copied: 'Copiato!',
    btn_refresh: 'Aggiorna',
    btn_search: 'Cerca...',
    btn_view_all: 'Mostra Tutto',
    btn_trade_now: 'Fai Trading Ora',
    btn_explore: 'Esplora',
    btn_select_language: 'Lingua',
    btn_save_changes: 'Salva Modifiche',
    dash_total_balance: 'Saldo Totale Cassaforte',
    dash_net_worth: 'Patrimonio Netto Stimato',
    auth_signin_title: 'Accedi alla Cassaforte TIXA',
    auth_signup_title: 'Crea Cassaforte Non-Custodial',
    settings_language: 'Lingua dell’Interfaccia',
    settings_select_lang_title: 'Seleziona Lingua (99 Paesi Supportati)',
    settings_saved_success: 'Preferenza di lingua salvata con successo!'
  },
  id: {
    nav_home: 'Beranda',
    nav_markets: 'Pasar',
    nav_trading: 'Perdagangan',
    nav_wallet: 'Dompet',
    nav_explorer: 'Blockchain',
    nav_transactions: 'Riwayat Transaksi',
    nav_holdings: 'Top 100 & Target 2050',
    nav_developer: 'Alat Pengembang',
    nav_admin: 'Panel Admin',
    nav_dashboard: 'Dasbor Saya',
    nav_profile: 'Keamanan & Profil',
    nav_tokens: 'Daftar Token',
    btn_login: 'Masuk',
    btn_signup: 'Daftar',
    btn_logout: 'Keluar',
    btn_connect_wallet: 'Hubungkan Brankas',
    btn_buy: 'Beli',
    btn_sell: 'Jual',
    btn_deposit: 'Setor',
    btn_withdraw: 'Tarik',
    btn_transfer: 'Transfer',
    btn_send: 'Kirim',
    btn_receive: 'Terima',
    btn_swap: 'Tukar Instan',
    btn_stake: 'Stake & Hasilkan',
    btn_confirm: 'Konfirmasi',
    btn_cancel: 'Batal',
    btn_close: 'Tutup',
    btn_copy: 'Salin',
    btn_copied: 'Disalin!',
    btn_refresh: 'Segarkan',
    btn_search: 'Cari...',
    btn_view_all: 'Lihat Semua',
    btn_trade_now: 'Trading Sekarang',
    btn_explore: 'Jelajahi',
    btn_select_language: 'Bahasa',
    btn_save_changes: 'Simpan Perubahan',
    dash_total_balance: 'Total Saldo Brankas',
    dash_net_worth: 'Estimasi Nilai Bersih',
    auth_signin_title: 'Masuk ke Brankas TIXA',
    auth_signup_title: 'Buat Brankas Non-Kustodial',
    settings_language: 'Bahasa Antarmuka',
    settings_select_lang_title: 'Pilih Bahasa (Mendukung 99 Negara)',
    settings_saved_success: 'Preferensi bahasa berhasil disimpan!'
  }
};

// Country calling code to primary language mapping
export const CALLING_CODE_TO_LANG: Record<string, string> = {
  '+880': 'bn', // Bangladesh -> Bengali
  '+1': 'en',   // USA / Canada -> English
  '+44': 'en',  // UK -> English
  '+91': 'hi',  // India -> Hindi
  '+971': 'ar', // UAE -> Arabic
  '+966': 'ar', // Saudi Arabia -> Arabic
  '+81': 'ja',  // Japan -> Japanese
  '+86': 'zh',  // China -> Chinese
  '+49': 'de',  // Germany -> German
  '+33': 'fr',  // France -> French
  '+34': 'es',  // Spain -> Spanish
  '+7': 'ru',   // Russia / Kazakhstan -> Russian
  '+90': 'tr',  // Turkey -> Turkish
  '+55': 'pt',  // Brazil -> Portuguese
  '+62': 'id',  // Indonesia -> Indonesian
  '+84': 'vi',  // Vietnam -> Vietnamese
  '+82': 'ko',  // South Korea -> Korean
  '+39': 'it',  // Italy -> Italian
  '+92': 'ur',  // Pakistan -> Urdu
  '+60': 'ms',  // Malaysia -> Malay
  '+63': 'fil', // Philippines -> Filipino
  '+66': 'th',  // Thailand -> Thai
  '+20': 'ar',  // Egypt -> Arabic
  '+98': 'fa',  // Iran -> Persian
  '+48': 'pl',  // Poland -> Polish
  '+31': 'nl',  // Netherlands -> Dutch
  '+380': 'uk', // Ukraine -> Ukrainian
  '+30': 'el',  // Greece -> Greek
  '+420': 'cs', // Czechia -> Czech
  '+46': 'sv',  // Sweden -> Swedish
  '+40': 'ro',  // Romania -> Romanian
  '+36': 'hu',  // Hungary -> Hungarian
  '+972': 'he', // Israel -> Hebrew
  '+45': 'da',  // Denmark -> Danish
  '+358': 'fi', // Finland -> Finnish
  '+47': 'no',  // Norway -> Norwegian
  '+27': 'en',  // South Africa -> English
  '+234': 'en', // Nigeria -> English
  '+254': 'sw', // Kenya -> Swahili
  '+52': 'es',  // Mexico -> Spanish
  '+54': 'es',  // Argentina -> Spanish
  '+57': 'es',  // Colombia -> Spanish
  '+61': 'en',  // Australia -> English
  '+65': 'en',  // Singapore -> English
};

// Currency code to primary language mapping
export const CURRENCY_TO_LANG: Record<string, string> = {
  BDT: 'bn', // Bangladesh Taka -> Bengali
  USD: 'en', // US Dollar -> English
  GBP: 'en', // British Pound -> English
  INR: 'hi', // Indian Rupee -> Hindi
  AED: 'ar', // UAE Dirham -> Arabic
  SAR: 'ar', // Saudi Riyal -> Arabic
  QAR: 'ar', // Qatari Riyal -> Arabic
  KWD: 'ar', // Kuwaiti Dinar -> Arabic
  EGP: 'ar', // Egyptian Pound -> Arabic
  JPY: 'ja', // Japanese Yen -> Japanese
  CNY: 'zh', // Chinese Yuan -> Chinese
  EUR: 'en', // Euro -> English (Primary fallback)
  TRY: 'tr', // Turkish Lira -> Turkish
  RUB: 'ru', // Russian Ruble -> Russian
  BRL: 'pt', // Brazilian Real -> Portuguese
  IDR: 'id', // Indonesian Rupiah -> Indonesian
  VND: 'vi', // Vietnamese Dong -> Vietnamese
  KRW: 'ko', // Korean Won -> Korean
  PKR: 'ur', // Pakistani Rupee -> Urdu
  MYR: 'ms', // Malaysian Ringgit -> Malay
  PHP: 'fil', // Philippine Peso -> Filipino
  THB: 'th', // Thai Baht -> Thai
  CAD: 'en', // Canadian Dollar -> English
  AUD: 'en', // Australian Dollar -> English
  SGD: 'en', // Singapore Dollar -> English
  ZAR: 'en', // South African Rand -> English
  NGN: 'en', // Nigerian Naira -> English
  KES: 'sw', // Kenyan Shilling -> Swahili
  MXN: 'es', // Mexican Peso -> Spanish
  ARS: 'es', // Argentine Peso -> Spanish
  COP: 'es', // Colombian Peso -> Spanish
  PLN: 'pl', // Polish Zloty -> Polish
  SEK: 'sv', // Swedish Krona -> Swedish
  CHF: 'de', // Swiss Franc -> German
};

// Country ISO alpha-2 code to language mapping
export const COUNTRY_CODE_TO_LANG: Record<string, string> = {
  BD: 'bn',
  US: 'en',
  GB: 'en',
  IN: 'hi',
  AE: 'ar',
  SA: 'ar',
  EG: 'ar',
  QA: 'ar',
  KW: 'ar',
  OM: 'ar',
  JP: 'ja',
  CN: 'zh',
  HK: 'zh',
  TW: 'zh',
  DE: 'de',
  AT: 'de',
  CH: 'de',
  FR: 'fr',
  BE: 'fr',
  ES: 'es',
  MX: 'es',
  AR: 'es',
  CO: 'es',
  CL: 'es',
  PE: 'es',
  RU: 'ru',
  BY: 'ru',
  KZ: 'ru',
  TR: 'tr',
  BR: 'pt',
  PT: 'pt',
  ID: 'id',
  VN: 'vi',
  KR: 'ko',
  PK: 'ur',
  MY: 'ms',
  PH: 'fil',
  TH: 'th',
  IR: 'fa',
  PL: 'pl',
  NL: 'nl',
  UA: 'uk',
  GR: 'el',
  CZ: 'cs',
  SE: 'sv',
  RO: 'ro',
  HU: 'hu',
  IL: 'he',
  DK: 'da',
  FI: 'fi',
  NO: 'no',
  ZA: 'en',
  NG: 'en',
  KE: 'sw',
  AU: 'en',
  CA: 'en',
  NZ: 'en',
  SG: 'en',
};

// Common cross-cutting translations across top languages
const COMMON_APP_TRANSLATIONS: Record<string, Record<string, string>> = {
  en: {
    wallet_send_asset: 'Sent Asset (P2P)',
    wallet_receive: 'Receive / QR',
    wallet_available_balance: 'AVAILABLE BALANCE',
    wallet_staked_balance: 'STAKED TO VALIDATORS',
    wallet_locked_balance: 'LOCKED / GOVERNANCE',
    p2p_min_transfer: 'Minimum transfer is $5 USD',
    p2p_zero_fee: '0.0000 TIXA (100% FREE)',
    p2p_no_admin: 'Zero Admin Intervention (Direct Instant P2P)',
    bar_live_rate: 'TIXA LIVE RATE',
    auth_login_title: 'Sign In to TIXA Vault',
    auth_register_title: 'Create Non-Custodial Vault',
    auth_email_label: 'Gmail / Email Address',
    auth_phone_label: 'Mobile Phone Number',
    auth_password_label: 'Password',
    auth_confirm_password: 'Confirm Password',
    auth_captcha_label: 'Security Verification (CAPTCHA)',
    auth_create_account_btn: 'Create Account & Activate Vault',
    auth_sign_in_btn: 'Sign In to Vault',
    auth_already_have_account: 'Already have an account?',
    auth_dont_have_account: 'Don\'t have an account?',
    auth_switch_to_login: 'Switch to Login',
    auth_switch_to_register: 'Switch to Register',
    btn_deposit: 'Deposit',
    btn_withdraw: 'Withdraw',
    btn_swap: 'Instant Trade'
  },
  bn: {
    wallet_send_asset: 'Sent Asset (P2P)',
    wallet_receive: 'Receive / QR',
    wallet_available_balance: 'AVAILABLE BALANCE',
    wallet_staked_balance: 'STAKED TO VALIDATORS',
    wallet_locked_balance: 'LOCKED / GOVERNANCE',
    p2p_min_transfer: 'Minimum transfer is $5 USD',
    p2p_zero_fee: '0.0000 TIXA (100% FREE)',
    p2p_no_admin: 'Zero Admin Intervention (Direct Instant P2P)',
    bar_live_rate: 'TIXA LIVE RATE',
    auth_login_title: 'লগইন করুন (Sign In)',
    auth_register_title: 'নতুন একাউন্ট (Create Account)',
    auth_email_label: 'জিমেইল / ইমেইল অ্যাড্রেস',
    auth_phone_label: 'মোবাইল ফোন নম্বর',
    auth_password_label: 'পাসওয়ার্ড',
    auth_confirm_password: 'কনফার্ম পাসওয়ার্ড',
    auth_captcha_label: 'সিকিউরিটি ক্যাপচা যাচাইকরণ',
    auth_create_account_btn: 'একাউন্ট তৈরি ও ভল্ট অ্যাক্টিভেট করুন',
    auth_sign_in_btn: 'ভল্টে লগইন করুন',
    auth_already_have_account: 'ইতিমধ্যে একাউন্ট আছে?',
    auth_dont_have_account: 'একাউন্ট নেই?',
    auth_switch_to_login: 'লগইন পেজে যান',
    auth_switch_to_register: 'রেজিস্ট্রেশন পেজে যান',
    btn_deposit: 'ডিপোজিট',
    btn_withdraw: 'উইথড্র',
    btn_swap: 'ইনস্ট্যান্ট ট্রেড'
  },
  es: {
    wallet_send_asset: 'Enviar Activo (P2P)',
    wallet_receive: 'Recibir / QR',
    wallet_available_balance: 'SALDO DISPONIBLE',
    wallet_staked_balance: 'EN STAKING',
    wallet_locked_balance: 'BLOQUEADO / GOBERNANZA',
    p2p_min_transfer: 'Transferencia mínima es de $5 USD',
    p2p_zero_fee: '0.0000 TIXA (100% GRATIS)',
    p2p_no_admin: 'Sin intervención admin (P2P directo)',
    bar_live_rate: 'PRECIO EN VIVO TIXA'
  },
  zh: {
    wallet_send_asset: '发送资产 (P2P)',
    wallet_receive: '接收 / 二维码',
    wallet_available_balance: '可用余额',
    wallet_staked_balance: '质押给验证节点',
    wallet_locked_balance: '锁定 / 治理',
    p2p_min_transfer: '最低转账金额为 $5 美元',
    p2p_zero_fee: '0.0000 TIXA (100% 免费)',
    p2p_no_admin: '无需管理员干预 (即时点对点)',
    bar_live_rate: 'TIXA 实时价格'
  },
  hi: {
    wallet_send_asset: 'एसेट भेजें (P2P)',
    wallet_receive: 'प्राप्त करें / QR',
    wallet_available_balance: 'उपलब्ध बैलेंस',
    wallet_staked_balance: 'सत्यापकों में स्टेक्ड',
    wallet_locked_balance: 'लॉक / गवर्नेंस',
    p2p_min_transfer: 'न्यूनतम ट्रांसफर $5 USD है',
    p2p_zero_fee: '0.0000 TIXA (100% फ्री)',
    p2p_no_admin: 'बिना किसी एडमिन हस्तक्षेप के (डायरेक्ट P2P)',
    bar_live_rate: 'TIXA लाइव दर'
  },
  ar: {
    wallet_send_asset: 'إرسال الأصول (P2P)',
    wallet_receive: 'استلام / QR',
    wallet_available_balance: 'الرصيد المتاح',
    wallet_staked_balance: 'مُرهن للمدققين',
    wallet_locked_balance: 'مُقفل / الحوكمة',
    p2p_min_transfer: 'الحد الأدنى للتحويل هو 5 دولارات',
    p2p_zero_fee: '0.0000 تيكسا (مجاني 100%)',
    p2p_no_admin: 'بدون أي تدخل من المسؤول (فوري ومباشر)',
    bar_live_rate: 'سعر TIXA المباشر'
  },
  fr: {
    wallet_send_asset: 'Envoyer Actif (P2P)',
    wallet_receive: 'Recevoir / QR',
    wallet_available_balance: 'SOLDE DISPONIBLE',
    wallet_staked_balance: 'JALONNÉ AUX VALIDATEURS',
    wallet_locked_balance: 'VERROUILLÉ / GOUVERNANCE',
    p2p_min_transfer: 'Transfert minimum de 5 $ USD',
    p2p_zero_fee: '0.0000 TIXA (100% GRATUIT)',
    p2p_no_admin: 'Zéro intervention admin (P2P direct)',
    bar_live_rate: 'COURS TIXA EN DIRECT'
  },
  de: {
    wallet_send_asset: 'Asset Senden (P2P)',
    wallet_receive: 'Empfangen / QR',
    wallet_available_balance: 'VERFÜGBARES GUTHABEN',
    wallet_staked_balance: 'GESTELLT AN VALIDATOREN',
    wallet_locked_balance: 'GESPERRT / GOVERNANCE',
    p2p_min_transfer: 'Mindestüberweisung beträgt 5 USD',
    p2p_zero_fee: '0.0000 TIXA (100% KOSTENLOS)',
    p2p_no_admin: 'Keine Admin-Intervention (Direktes P2P)',
    bar_live_rate: 'TIXA LIVE-KURS'
  },
  ja: {
    wallet_send_asset: '資産を送金 (P2P)',
    wallet_receive: '受取 / QR',
    wallet_available_balance: '利用可能残高',
    wallet_staked_balance: 'バリデータにステーキング済',
    wallet_locked_balance: 'ロック / ガバナンス',
    p2p_min_transfer: '最低送金額は $5 USD です',
    p2p_zero_fee: '0.0000 TIXA (100% 無料)',
    p2p_no_admin: '管理者介入なし (即時P2P)',
    bar_live_rate: 'TIXA リアルタイム価格'
  },
  ru: {
    wallet_send_asset: 'Отправить Актив (P2P)',
    wallet_receive: 'Получить / QR',
    wallet_available_balance: 'ДОСТУПНЫЙ БАЛАНС',
    wallet_staked_balance: 'В СТЕЙКИНГЕ ВАЛИДАТОРОВ',
    wallet_locked_balance: 'ЗАБЛОКИРОВАНО / УПРАВЛЕНИЕ',
    p2p_min_transfer: 'Минимальный перевод $5 USD',
    p2p_zero_fee: '0.0000 TIXA (100% БЕСПЛАТНО)',
    p2p_no_admin: 'Без вмешательства администратора (Прямой P2P)',
    bar_live_rate: 'КУРС TIXA ОНЛАЙН'
  },
  tr: {
    wallet_send_asset: 'Varlık Gönder (P2P)',
    wallet_receive: 'Al / QR',
    wallet_available_balance: 'MEVCUT BAKİYE',
    wallet_staked_balance: 'DOĞRULAYICILARDA STAKE EDİLDİ',
    wallet_locked_balance: 'KİLİTLİ / YÖNETİŞİM',
    p2p_min_transfer: 'Minimum transfer 5 USD',
    p2p_zero_fee: '0.0000 TIXA (100% ÜCRETSİZ)',
    p2p_no_admin: 'Yönetici müdahalesi yok (Doğrudan P2P)',
    bar_live_rate: 'TIXA CANLI FİYAT'
  },
  pt: {
    wallet_send_asset: 'Enviar Ativo (P2P)',
    wallet_receive: 'Receber / QR',
    wallet_available_balance: 'SALDO DISPONÍVEL',
    wallet_staked_balance: 'STAKING COM VALIDATORS',
    wallet_locked_balance: 'BLOQUEADO / GOVERNANÇA',
    p2p_min_transfer: 'Transferência mínima de $5 USD',
    p2p_zero_fee: '0.0000 TIXA (100% GRÁTIS)',
    p2p_no_admin: 'Sem intervenção de administrador (P2P direto)',
    bar_live_rate: 'COTAÇÃO AO VIVO TIXA'
  }
};

class LanguageEngine {
  private currentLanguageCode: string;
  private listeners: Set<() => void> = new Set();
  private lastAutoSwitchNotice: { message: string; flag: string; langCode: string; timestamp: number } | null = null;

  constructor() {
    // Primary default language across whole app is strictly English ('en')
    const saved = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEY) : null;
    if (saved && LANGUAGES_99.some(l => l.code === saved)) {
      this.currentLanguageCode = saved;
    } else {
      this.currentLanguageCode = 'en';
    }
  }

  public getLanguageCode(): string {
    return this.currentLanguageCode;
  }

  public getCurrentLanguage(): LanguageInfo {
    return (
      LANGUAGES_99.find(l => l.code === this.currentLanguageCode) ||
      LANGUAGES_99[0]
    );
  }

  public getAllLanguages(): LanguageInfo[] {
    return LANGUAGES_99;
  }

  public getLastAutoSwitchNotice() {
    return this.lastAutoSwitchNotice;
  }

  public clearAutoSwitchNotice() {
    this.lastAutoSwitchNotice = null;
    this.notify();
  }

  public setLanguage(code: string, reason?: string): boolean {
    const found = LANGUAGES_99.find(l => l.code === code);
    if (!found) return false;

    const previousCode = this.currentLanguageCode;
    this.currentLanguageCode = code;
    try {
      if (typeof window !== 'undefined') {
        localStorage.setItem(STORAGE_KEY, code);
        document.documentElement.lang = code;
        document.documentElement.dir = found.rtl ? 'rtl' : 'ltr';
      }
    } catch (e) {
      console.warn('Failed to save language to localStorage', e);
    }

    if (reason && previousCode !== code) {
      this.lastAutoSwitchNotice = {
        message: `App language switched to ${found.nativeName} (${found.name}) based on ${reason}`,
        flag: found.flag,
        langCode: code,
        timestamp: Date.now()
      };
    }

    this.notify();
    return true;
  }

  public autoDetectAndSetLanguage(params: {
    countryCode?: string;
    callingCode?: string;
    currency?: string;
    phone?: string;
  }): { switched: boolean; language: LanguageInfo; reason: string } {
    let targetLangCode: string | null = null;
    let reason = '';

    // 1. Check Calling Code (e.g. +880, +1, +91)
    if (params.callingCode) {
      const cleanCode = params.callingCode.trim().startsWith('+')
        ? params.callingCode.trim()
        : `+${params.callingCode.trim()}`;
      if (CALLING_CODE_TO_LANG[cleanCode]) {
        targetLangCode = CALLING_CODE_TO_LANG[cleanCode];
        reason = `Calling Code ${cleanCode}`;
      }
    }

    // 2. Check Country Code (e.g. BD, US, IN, SA)
    if (!targetLangCode && params.countryCode) {
      const upper = params.countryCode.trim().toUpperCase();
      if (COUNTRY_CODE_TO_LANG[upper]) {
        targetLangCode = COUNTRY_CODE_TO_LANG[upper];
        reason = `Country ${upper}`;
      }
    }

    // 3. Check Currency (e.g. BDT, USD, INR, AED, JPY)
    if (!targetLangCode && params.currency) {
      const upperCur = params.currency.trim().toUpperCase();
      if (CURRENCY_TO_LANG[upperCur]) {
        targetLangCode = CURRENCY_TO_LANG[upperCur];
        reason = `Currency ${upperCur}`;
      }
    }

    // 4. Check Phone number prefix
    if (!targetLangCode && params.phone) {
      const trimmed = params.phone.trim();
      for (const [code, lang] of Object.entries(CALLING_CODE_TO_LANG)) {
        if (trimmed.startsWith(code) || trimmed.startsWith(code.replace('+', ''))) {
          targetLangCode = lang;
          reason = `Phone prefix ${code}`;
          break;
        }
      }
    }

    if (targetLangCode) {
      const switched = this.setLanguage(targetLangCode, reason);
      const language = this.getCurrentLanguage();
      return { switched, language, reason };
    }

    return { switched: false, language: this.getCurrentLanguage(), reason: 'Default English' };
  }

  public setLanguageByCallingCode(callingCode: string): boolean {
    const res = this.autoDetectAndSetLanguage({ callingCode });
    return res.switched;
  }

  public setLanguageByCurrency(currency: string): boolean {
    const res = this.autoDetectAndSetLanguage({ currency });
    return res.switched;
  }

  public setLanguageByCountry(countryCode: string): boolean {
    const res = this.autoDetectAndSetLanguage({ countryCode });
    return res.switched;
  }

  public t(key: string, fallback?: string): string {
    // Check common app translations first
    const common = COMMON_APP_TRANSLATIONS[this.currentLanguageCode];
    if (common && common[key]) {
      return common[key];
    }

    // Check main translations
    const dict = (TRANSLATIONS as any)[this.currentLanguageCode] || (EXTENDED_TRANSLATIONS as any)[this.currentLanguageCode];
    if (dict && dict[key]) {
      return dict[key] as string;
    }

    // Check common English
    if (COMMON_APP_TRANSLATIONS['en'] && COMMON_APP_TRANSLATIONS['en'][key]) {
      return COMMON_APP_TRANSLATIONS['en'][key];
    }

    // Fallback to English main translations
    const enDict = (TRANSLATIONS as any)['en'];
    if (enDict && enDict[key]) {
      return enDict[key] as string;
    }

    return fallback || key;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    this.listeners.forEach(fn => {
      try {
        fn();
      } catch (err) {
        console.error('Error notifying language listener', err);
      }
    });
  }
}

export const languageEngine = new LanguageEngine();
