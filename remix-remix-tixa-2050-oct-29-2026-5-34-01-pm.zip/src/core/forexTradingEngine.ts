import { 
  ForexPair, 
  ForexCandle, 
  ActiveTrade, 
  SettledTrade, 
  AccountMode, 
  TradeDirection, 
  TradeDuration, 
  TimeframeId 
} from '../types/forexTrading';
import { blockchainEngine } from './blockchainEngine';
import { authEngine } from './authEngine';
import confetti from 'canvas-confetti';

const STORAGE_DEMO_BALANCE_KEY = 'tixa_forex_demo_balance_v1';
const STORAGE_ACTIVE_TRADES_KEY = 'tixa_forex_active_trades_v1';
const STORAGE_SETTLED_TRADES_KEY = 'tixa_forex_settled_trades_v1';
const INITIAL_DEMO_BALANCE = 100000.00;

export const DURATION_SECONDS_MAP: Record<TradeDuration, number> = {
  '3S': 3,
  '5S': 5,
  '10S': 10,
  '15S': 15,
  '30S': 30,
  '1M': 60,
  '5M': 300,
  '15M': 900,
  '30M': 1800,
  '1H': 3600
};

export const TIMEFRAME_SECONDS_MAP: Record<TimeframeId, number> = {
  '1s': 1,
  '5s': 5,
  '15s': 15,
  '1m': 60,
  '5m': 300,
  '15m': 900,
  '1h': 3600,
  '4h': 14400,
  '1d': 86400
};

export class ForexTradingEngine {
  private static instance: ForexTradingEngine;

  private pairs: ForexPair[] = [
    {
      id: 'TIXA_USDT',
      name: 'TIXA / USDT',
      base: 'TIXA',
      quote: 'USDT',
      type: 'CRYPTO',
      currentPrice: 990000.00,
      change24h: 12.45,
      high24h: 1045000.00,
      low24h: 942000.00,
      payoutRate: 0.88, // 88%
      priceDecimals: 2,
      spread: 0.50,
      volume24h: 148500000
    },
    {
      id: 'NISI_USDT',
      name: 'NISI / USDT',
      base: 'NISI',
      quote: 'USDT',
      type: 'CRYPTO',
      currentPrice: 64280.50,
      change24h: 3.82,
      high24h: 65400.00,
      low24h: 62800.00,
      payoutRate: 0.85,
      priceDecimals: 2,
      spread: 1.00,
      volume24h: 342000000
    },
    {
      id: 'SARA_USDT',
      name: 'SARA / USDT',
      base: 'SARA',
      quote: 'USDT',
      type: 'CRYPTO',
      currentPrice: 3485.20,
      change24h: 4.65,
      high24h: 3560.00,
      low24h: 3390.00,
      payoutRate: 0.86,
      priceDecimals: 2,
      spread: 0.20,
      volume24h: 184000000
    },
    {
      id: 'MUN_USDT',
      name: 'MUN / USDT',
      base: 'MUN',
      quote: 'USDT',
      type: 'CRYPTO',
      currentPrice: 154.60,
      change24h: 8.92,
      high24h: 161.20,
      low24h: 147.50,
      payoutRate: 0.87,
      priceDecimals: 2,
      spread: 0.05,
      volume24h: 98000000
    },
    {
      id: 'EUR_USD',
      name: 'EUR / USD',
      base: 'EUR',
      quote: 'USD',
      type: 'FOREX',
      currentPrice: 1.08450,
      change24h: 0.35,
      high24h: 1.08820,
      low24h: 1.08110,
      payoutRate: 0.90, // 90% payout on Forex majors
      priceDecimals: 5,
      spread: 0.00010,
      volume24h: 620000000
    },
    {
      id: 'GBP_USD',
      name: 'GBP / USD',
      base: 'GBP',
      quote: 'USD',
      type: 'FOREX',
      currentPrice: 1.29340,
      change24h: -0.22,
      high24h: 1.29850,
      low24h: 1.28900,
      payoutRate: 0.89,
      priceDecimals: 5,
      spread: 0.00015,
      volume24h: 410000000
    },
    {
      id: 'USD_JPY',
      name: 'USD / JPY',
      base: 'USD',
      quote: 'JPY',
      type: 'FOREX',
      currentPrice: 154.280,
      change24h: 0.54,
      high24h: 155.100,
      low24h: 153.800,
      payoutRate: 0.88,
      priceDecimals: 3,
      spread: 0.015,
      volume24h: 380000000
    },
    {
      id: 'AUD_USD',
      name: 'AUD / USD',
      base: 'AUD',
      quote: 'USD',
      type: 'FOREX',
      currentPrice: 0.65820,
      change24h: 0.18,
      high24h: 0.66200,
      low24h: 0.65400,
      payoutRate: 0.87,
      priceDecimals: 5,
      spread: 0.00012,
      volume24h: 190000000
    }
  ];

  private demoBalance: number = INITIAL_DEMO_BALANCE;
  private activeTrades: ActiveTrade[] = [];
  private settledTrades: SettledTrade[] = [];
  private candleCache: Record<string, Record<TimeframeId, ForexCandle[]>> = {};
  private listeners: Array<() => void> = [];
  private tickerInterval: any = null;
  private lastTickMap: Record<string, { delta: number; direction: 'UP' | 'DOWN' }> = {};

  private constructor() {
    this.loadState();
    this.initializeCandles();
    this.startLiveTickerEngine();
  }

  public static getInstance(): ForexTradingEngine {
    if (!ForexTradingEngine.instance) {
      ForexTradingEngine.instance = new ForexTradingEngine();
    }
    return ForexTradingEngine.instance;
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify(): void {
    this.listeners.forEach(cb => {
      try { cb(); } catch (err) { console.error('Forex listener error', err); }
    });
  }

  private loadState(): void {
    try {
      const storedBal = localStorage.getItem(STORAGE_DEMO_BALANCE_KEY);
      if (storedBal !== null) {
        this.demoBalance = parseFloat(storedBal) || INITIAL_DEMO_BALANCE;
      }

      const storedActive = localStorage.getItem(STORAGE_ACTIVE_TRADES_KEY);
      if (storedActive) {
        this.activeTrades = JSON.parse(storedActive);
      }

      const storedSettled = localStorage.getItem(STORAGE_SETTLED_TRADES_KEY);
      if (storedSettled) {
        this.settledTrades = JSON.parse(storedSettled);
      }
    } catch (e) {
      console.warn('Failed to load forex trading state', e);
    }
  }

  private saveState(): void {
    try {
      localStorage.setItem(STORAGE_DEMO_BALANCE_KEY, this.demoBalance.toString());
      localStorage.setItem(STORAGE_ACTIVE_TRADES_KEY, JSON.stringify(this.activeTrades));
      localStorage.setItem(STORAGE_SETTLED_TRADES_KEY, JSON.stringify(this.settledTrades.slice(0, 150)));
    } catch (e) {
      console.warn('Failed to save forex trading state', e);
    }
  }

  private initializeCandles(): void {
    const timeframes: TimeframeId[] = ['1s', '5s', '15s', '1m', '5m', '15m', '1h', '4h', '1d'];

    for (const pair of this.pairs) {
      this.candleCache[pair.id] = {} as Record<TimeframeId, ForexCandle[]>;
      for (const tf of timeframes) {
        this.candleCache[pair.id][tf] = this.generateHistoricalCandles(pair, tf, 60);
      }
    }
  }

  private gaussianRandom(): number {
    let u = 0, v = 0;
    while(u === 0) u = Math.random();
    while(v === 0) v = Math.random();
    return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  }

  private generateHistoricalCandles(pair: ForexPair, tf: TimeframeId, count: number): ForexCandle[] {
    const candles: ForexCandle[] = [];
    const stepSeconds = TIMEFRAME_SECONDS_MAP[tf];
    const stepMs = stepSeconds * 1000;
    const now = Date.now();
    const volatility = pair.type === 'FOREX' ? 0.0006 : 0.003;

    let price = pair.currentPrice * (1 - (volatility * 5));

    for (let i = count; i >= 0; i--) {
      const time = Math.floor((now - (i * stepMs)) / stepMs) * stepMs;
      const gaussianShock = this.gaussianRandom() * (price * volatility);
      const open = price;
      const close = Math.max(0.00001, open + gaussianShock);
      
      const wickRange = Math.abs(close - open) + (price * volatility * 0.5);
      const high = Math.max(open, close) + Math.abs(this.gaussianRandom()) * wickRange * 0.4;
      const low = Math.max(0.00001, Math.min(open, close) - Math.abs(this.gaussianRandom()) * wickRange * 0.4);
      const volume = Math.floor(Math.abs(this.gaussianRandom()) * 300) + 50;

      candles.push({
        timestamp: time,
        open: Number(open.toFixed(pair.priceDecimals)),
        high: Number(high.toFixed(pair.priceDecimals)),
        low: Number(low.toFixed(pair.priceDecimals)),
        close: Number(close.toFixed(pair.priceDecimals)),
        volume
      });

      price = close;
    }

    return candles;
  }

  // 1-Second Master Tick Loop
  private startLiveTickerEngine(): void {
    if (this.tickerInterval) clearInterval(this.tickerInterval);

    this.tickerInterval = setInterval(() => {
      const now = Date.now();

      // 1. Tick each market pair with realistic high-frequency market noise
      for (const pair of this.pairs) {
        let delta = 0;

        if (pair.id === 'TIXA_USDT') {
          // TIXA price fluctuations (±$500 to $3,500)
          delta = (Math.random() - 0.495) * 3500;
        } else if (pair.type === 'FOREX') {
          // Forex pips (e.g. ±0.00015)
          delta = (Math.random() - 0.498) * (pair.currentPrice * 0.00018);
        } else {
          // Crypto (BTC, ETH, SOL) (±0.08% to 0.2%)
          delta = (Math.random() - 0.495) * (pair.currentPrice * 0.0015);
        }

        const newPrice = Number(Math.max(0.00001, pair.currentPrice + delta).toFixed(pair.priceDecimals));
        pair.currentPrice = newPrice;
        pair.high24h = Math.max(pair.high24h, newPrice);
        pair.low24h = Math.min(pair.low24h, newPrice);

        this.lastTickMap[pair.id] = {
          delta,
          direction: delta >= 0 ? 'UP' : 'DOWN'
        };

        // Update real-time 1s candle and parent timeframes
        this.updateCandleStreams(pair, newPrice, now);
      }

      // 2. Check and settle active trades reaching expiry
      this.checkAndSettleTrades(now);

      this.notify();
    }, 1000);
  }

  private updateCandleStreams(pair: ForexPair, currentPrice: number, now: number): void {
    const pairCache = this.candleCache[pair.id];
    if (!pairCache) return;

    const timeframes: TimeframeId[] = ['1s', '5s', '15s', '1m', '5m', '15m', '1h', '4h', '1d'];

    for (const tf of timeframes) {
      const candles = pairCache[tf];
      if (!candles || candles.length === 0) continue;

      const stepMs = TIMEFRAME_SECONDS_MAP[tf] * 1000;
      const lastCandle = candles[candles.length - 1];
      const expectedTimestamp = Math.floor(now / stepMs) * stepMs;
      const isNewCandle = expectedTimestamp > lastCandle.timestamp;

      if (isNewCandle) {
        // Push a new candle
        const newCandle: ForexCandle = {
          timestamp: expectedTimestamp,
          open: lastCandle.close,
          high: Math.max(lastCandle.close, currentPrice),
          low: Math.min(lastCandle.close, currentPrice),
          close: currentPrice,
          volume: Math.floor(Math.random() * 40) + 10
        };
        candles.push(newCandle);
        if (candles.length > 120) candles.shift();
      } else {
        // Update current candle in progress with strict mathematical OHLC invariance
        lastCandle.close = currentPrice;
        lastCandle.high = Math.max(lastCandle.open, lastCandle.close, lastCandle.high, currentPrice);
        lastCandle.low = Math.max(0.00001, Math.min(lastCandle.open, lastCandle.close, lastCandle.low, currentPrice));
        lastCandle.volume += 2;
      }
    }
  }

  // Settle active trades whose countdown has expired
  private checkAndSettleTrades(now: number): void {
    const remainingActive: ActiveTrade[] = [];

    for (const trade of this.activeTrades) {
      const pair = this.getPair(trade.pairId);
      const currentPrice = pair ? pair.currentPrice : trade.entryPrice;
      trade.currentPrice = currentPrice;

      if (now >= trade.expiryTime) {
        // Settle trade
        const exitPrice = currentPrice;
        let result: 'WON' | 'LOST' | 'TIE' = 'LOST';
        let pnl = -trade.amount;
        let payout = 0;

        if (trade.direction === 'CALL') {
          if (exitPrice > trade.entryPrice) {
            result = 'WON';
            const profit = trade.amount * trade.payoutRate;
            payout = trade.amount + profit;
            pnl = profit;
          } else if (exitPrice === trade.entryPrice) {
            result = 'TIE';
            payout = trade.amount;
            pnl = 0;
          } else {
            result = 'LOST';
            payout = 0;
            pnl = -trade.amount;
          }
        } else {
          // PUT
          if (exitPrice < trade.entryPrice) {
            result = 'WON';
            const profit = trade.amount * trade.payoutRate;
            payout = trade.amount + profit;
            pnl = profit;
          } else if (exitPrice === trade.entryPrice) {
            result = 'TIE';
            payout = trade.amount;
            pnl = 0;
          } else {
            result = 'LOST';
            payout = 0;
            pnl = -trade.amount;
          }
        }

        // Apply payout to appropriate account
        if (trade.accountMode === 'DEMO') {
          if (payout > 0) {
            this.demoBalance += payout;
          }
        } else {
          // Real account settlement in TIXA coin valuation
          if (payout > 0) {
            const userAcc = blockchainEngine.getOrCreateAccount(trade.traderAddress);
            const liveTixaPrice = this.getPair('TIXA_USDT')?.currentPrice || 990000.00;
            const tixaPayout = liveTixaPrice > 0 ? payout / liveTixaPrice : 0;
            userAcc.balance += tixaPayout;
          }
        }

        if (result === 'WON') {
          try {
            confetti({
              particleCount: 50,
              spread: 60,
              origin: { y: 0.7 }
            });
          } catch (e) {
            // ignore
          }
        }

        const settled: SettledTrade = {
          id: trade.id,
          pairId: trade.pairId,
          pairName: trade.pairName,
          accountMode: trade.accountMode,
          direction: trade.direction,
          amount: trade.amount,
          entryPrice: trade.entryPrice,
          exitPrice,
          duration: trade.duration,
          durationSeconds: trade.durationSeconds,
          startTime: trade.startTime,
          settledTime: now,
          payoutRate: trade.payoutRate,
          pnl: Number(pnl.toFixed(2)),
          payout: Number(payout.toFixed(2)),
          result,
          traderAddress: trade.traderAddress,
          txHash: trade.txHash || `0xsettle_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`
        };

        this.settledTrades.unshift(settled);
      } else {
        remainingActive.push(trade);
      }
    }

    this.activeTrades = remainingActive;
    this.saveState();
  }

  // Place a new binary/forex trade
  public async placeTrade(params: {
    pairId: string;
    accountMode: AccountMode;
    direction: TradeDirection;
    amount: number;
    duration: TradeDuration;
    traderAddress?: string;
  }): Promise<ActiveTrade> {
    const pair = this.getPair(params.pairId);
    if (!pair) throw new Error('Selected trading pair not found.');

    if (params.amount <= 0 || isNaN(params.amount)) {
      throw new Error('Invalid trade amount. Minimum trade amount is $1.00.');
    }

    const durationSec = DURATION_SECONDS_MAP[params.duration] || 10;
    const now = Date.now();
    const expiryTime = now + (durationSec * 1000);
    const session = authEngine.getSession();
    const walletAddress = params.traderAddress || session?.walletAddress || 'tx1tixamainnetvaultuser';

    // Account validation
    if (params.accountMode === 'DEMO') {
      if (this.demoBalance < params.amount) {
        throw new Error('Demo Balance Exhausted. Please click [REFILL DEMO BALANCE] to restore $100,000.00 DEMO.');
      }
      this.demoBalance -= params.amount;
    } else {
      // REAL ACCOUNT
      const realAccount = blockchainEngine.getOrCreateAccount(walletAddress);
      if (realAccount.isFrozen) {
        throw new Error('Real account is frozen by security policy. Trading restricted.');
      }
      const liveTixaPrice = this.getPair('TIXA_USDT')?.currentPrice || 990000.00;
      const totalUsdValuation = realAccount.balance * liveTixaPrice;

      if (totalUsdValuation < params.amount) {
        throw new Error(`Insufficient Real Balance. Your ${realAccount.balance.toFixed(6)} TIXA is valued at $${totalUsdValuation.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT (Required: $${params.amount.toFixed(2)} USDT). Deposit TIXA coins or switch to DEMO account.`);
      }
      // Deduct exact proportional TIXA coins from real on-chain balance
      const tixaDeduction = params.amount / liveTixaPrice;
      realAccount.balance = Math.max(0, realAccount.balance - tixaDeduction);
    }

    const tradeId = `fx_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const potentialProfit = params.amount * pair.payoutRate;

    const newTrade: ActiveTrade = {
      id: tradeId,
      pairId: pair.id,
      pairName: pair.name,
      accountMode: params.accountMode,
      direction: params.direction,
      amount: params.amount,
      entryPrice: pair.currentPrice,
      currentPrice: pair.currentPrice,
      duration: params.duration,
      durationSeconds: durationSec,
      startTime: now,
      expiryTime,
      payoutRate: pair.payoutRate,
      potentialProfit: Number(potentialProfit.toFixed(2)),
      status: 'PENDING',
      traderAddress: walletAddress,
      txHash: params.accountMode === 'REAL' ? `0xtrade_mainnet_${tradeId}` : undefined
    };

    this.activeTrades.unshift(newTrade);
    this.saveState();
    this.notify();

    return newTrade;
  }

  // Refill Demo Balance
  public refillDemoBalance(amount: number = INITIAL_DEMO_BALANCE): void {
    this.demoBalance = amount;
    this.saveState();
    this.notify();
    try {
      confetti({
        particleCount: 70,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch (e) {
      // ignore
    }
  }

  public getPairs(): ForexPair[] {
    return [...this.pairs];
  }

  public getPair(pairId: string): ForexPair | undefined {
    return this.pairs.find(p => p.id === pairId);
  }

  public getDemoBalance(): number {
    return this.demoBalance;
  }

  public deductDemoBalance(amount: number): boolean {
    if (this.demoBalance < amount) return false;
    this.demoBalance -= amount;
    this.saveState();
    this.notify();
    return true;
  }

  public creditDemoBalance(amount: number): void {
    this.demoBalance += amount;
    this.saveState();
    this.notify();
  }

  public getActiveTrades(): ActiveTrade[] {
    return [...this.activeTrades];
  }

  public getSettledTrades(mode?: AccountMode): SettledTrade[] {
    if (mode) {
      return this.settledTrades.filter(t => t.accountMode === mode);
    }
    return [...this.settledTrades];
  }

  public getCandles(pairId: string, timeframe: TimeframeId): ForexCandle[] {
    const pairCache = this.candleCache[pairId];
    if (!pairCache || !pairCache[timeframe]) {
      const pair = this.getPair(pairId) || this.pairs[0];
      return this.generateHistoricalCandles(pair, timeframe, 50);
    }
    return [...pairCache[timeframe]];
  }

  public getLastTickInfo(pairId: string): { delta: number; direction: 'UP' | 'DOWN' } {
    return this.lastTickMap[pairId] || { delta: 0, direction: 'UP' };
  }
}

export const forexTradingEngine = ForexTradingEngine.getInstance();
