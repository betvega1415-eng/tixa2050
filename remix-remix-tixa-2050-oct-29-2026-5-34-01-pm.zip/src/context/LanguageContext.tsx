import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { languageEngine } from '../core/languageEngine';
import { LanguageInfo } from '../data/languages';
import { TranslationDictionary } from '../data/translations';
import { Globe, X, CheckCircle2 } from 'lucide-react';

interface LanguageContextType {
  currentLanguage: LanguageInfo;
  languageCode: string;
  setLanguage: (code: string, reason?: string) => void;
  autoDetectAndSetLanguage: (params: { countryCode?: string; callingCode?: string; currency?: string; phone?: string }) => { switched: boolean; language: LanguageInfo; reason: string };
  setLanguageByCallingCode: (callingCode: string) => boolean;
  setLanguageByCurrency: (currency: string) => boolean;
  setLanguageByCountry: (countryCode: string) => boolean;
  t: (key: keyof TranslationDictionary | string, fallback?: string) => string;
  isLanguageModalOpen: boolean;
  setIsLanguageModalOpen: (open: boolean) => void;
  openLanguageModal: () => void;
  allLanguages: LanguageInfo[];
  lastAutoSwitchedNotice: { message: string; flag: string; langCode: string; timestamp: number } | null;
  dismissNotice: () => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState<LanguageInfo>(languageEngine.getCurrentLanguage());
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const [lastNotice, setLastNotice] = useState(languageEngine.getLastAutoSwitchNotice());

  useEffect(() => {
    // Set initial document attributes
    if (typeof window !== 'undefined') {
      document.documentElement.lang = currentLanguage.code;
      document.documentElement.dir = currentLanguage.rtl ? 'rtl' : 'ltr';
    }

    const unsubscribe = languageEngine.subscribe(() => {
      const updated = languageEngine.getCurrentLanguage();
      setCurrentLanguage(updated);
      setLastNotice(languageEngine.getLastAutoSwitchNotice());
      if (typeof window !== 'undefined') {
        document.documentElement.lang = updated.code;
        document.documentElement.dir = updated.rtl ? 'rtl' : 'ltr';
      }
    });

    return () => unsubscribe();
  }, [currentLanguage.code, currentLanguage.rtl]);

  // Auto-dismiss notice after 5 seconds
  useEffect(() => {
    if (lastNotice) {
      const timer = setTimeout(() => {
        languageEngine.clearAutoSwitchNotice();
        setLastNotice(null);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [lastNotice?.timestamp]);

  const handleSetLanguage = (code: string, reason?: string) => {
    languageEngine.setLanguage(code, reason);
  };

  const autoDetectAndSetLanguage = (params: { countryCode?: string; callingCode?: string; currency?: string; phone?: string }) => {
    return languageEngine.autoDetectAndSetLanguage(params);
  };

  const setLanguageByCallingCode = (callingCode: string) => {
    return languageEngine.setLanguageByCallingCode(callingCode);
  };

  const setLanguageByCurrency = (currency: string) => {
    return languageEngine.setLanguageByCurrency(currency);
  };

  const setLanguageByCountry = (countryCode: string) => {
    return languageEngine.setLanguageByCountry(countryCode);
  };

  const t = (key: keyof TranslationDictionary | string, fallback?: string): string => {
    return languageEngine.t(key, fallback);
  };

  const dismissNotice = () => {
    languageEngine.clearAutoSwitchNotice();
    setLastNotice(null);
  };

  return (
    <LanguageContext.Provider
      value={{
        currentLanguage,
        languageCode: currentLanguage.code,
        setLanguage: handleSetLanguage,
        autoDetectAndSetLanguage,
        setLanguageByCallingCode,
        setLanguageByCurrency,
        setLanguageByCountry,
        t,
        isLanguageModalOpen,
        setIsLanguageModalOpen,
        openLanguageModal: () => setIsLanguageModalOpen(true),
        allLanguages: languageEngine.getAllLanguages(),
        lastAutoSwitchedNotice: lastNotice,
        dismissNotice
      }}
    >
      {/* Floating Auto-Switch Language Toast Banner */}
      {lastNotice && (
        <div className="fixed top-24 right-4 z-[9999] max-w-sm w-full p-3.5 rounded-2xl bg-[#09152e]/95 backdrop-blur-md border border-cyan-500/50 shadow-2xl text-slate-100 animate-in slide-in-from-top duration-300 font-sans">
          <div className="flex items-start justify-between gap-2.5">
            <div className="flex items-start gap-2.5">
              <span className="text-2xl select-none leading-none mt-0.5">{lastNotice.flag}</span>
              <div className="space-y-0.5">
                <div className="text-xs font-bold text-white flex items-center gap-1.5 font-heading">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Language Auto-Switched</span>
                </div>
                <p className="text-[11px] text-cyan-200/90 leading-tight">
                  {lastNotice.message}
                </p>
              </div>
            </div>
            <button
              onClick={dismissNotice}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
